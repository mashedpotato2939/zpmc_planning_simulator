#!/usr/bin/env python3
"""Subscribe once to /planning/scenario_planning/lane_driving/behavior_planning/path, dump to CSV,
and plot the XY polyline with vehicle footprints centered on the geometric
center of the vehicle.

Usage:
    # With the system running (launch_with_fms.sh + qturn1.json loaded):
    python3 plot_trajectory_footprint.py [out.png] [--topic TOPIC] [--step N]
"""
import argparse
import csv
import math
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from autoware_planning_msgs.msg import Trajectory, Path
from igv_planning_msgs.msg import FMSPath


VEH_LEN   = 15.0
VEH_WIDTH = 3.0


def quat_to_yaw(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def footprint(x, y, yaw):
    c, s = math.cos(yaw), math.sin(yaw)
    hl, hw = VEH_LEN / 2.0, VEH_WIDTH / 2.0
    local = [( hl,  hw), ( hl, -hw), (-hl, -hw), (-hl,  hw)]
    return [(x + c * lx - s * ly, y + s * lx + c * ly) for lx, ly in local]


MSG_TYPES = {"trajectory": Trajectory, "path": Path, "fmspath": FMSPath}


def _iter_records(msg):
    return getattr(msg, "points", None) or getattr(msg, "waypoints", None) or []


def _extract(p):
    if hasattr(p, "pose"):
        return p.pose.position.x, p.pose.position.y, quat_to_yaw(p.pose.orientation)
    return p.x, p.y, p.yaw


class Grabber(Node):
    def __init__(self, topic, msg_cls, accumulate):
        super().__init__("trajectory_footprint_grabber")
        qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.accumulate = accumulate
        self.msg = None
        self.points = {}  # (xkey,ykey) -> (x,y,yaw)  for stitching
        self.sub = self.create_subscription(msg_cls, topic, self.cb, qos)
        mode = f"accumulating for {accumulate:.1f}s" if accumulate else "waiting for one message"
        self.get_logger().info(f"{mode} on {topic}")

    def cb(self, msg):
        if self.accumulate:
            for p in _iter_records(msg):
                x, y, yaw = _extract(p)
                self.points[(round(x, 2), round(y, 2))] = (x, y, yaw)
        elif self.msg is None:
            self.msg = msg


def grab(topic, msg_cls, timeout_s=15.0, accumulate=0.0):
    rclpy.init()
    n = Grabber(topic, msg_cls, accumulate)
    t0 = n.get_clock().now()
    deadline = accumulate if accumulate > 0 else timeout_s
    while rclpy.ok():
        rclpy.spin_once(n, timeout_sec=0.1)
        elapsed = (n.get_clock().now() - t0).nanoseconds / 1e9
        if accumulate > 0:
            if elapsed > deadline:
                break
        else:
            if n.msg is not None:
                break
            if elapsed > deadline:
                n.get_logger().error(f"timed out after {deadline}s")
                break
    stitched = None
    if accumulate > 0 and n.points:
        stitched = sorted(n.points.values(), key=lambda p: (p[0], p[1]))
    msg = n.msg
    n.destroy_node()
    rclpy.shutdown()
    return msg, stitched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out", nargs="?", default="/tmp/planning_trajectory.png")
    ap.add_argument("--topic", default="/planning/scenario_planning/lane_driving/behavior_planning/path")
    ap.add_argument("--msg", choices=MSG_TYPES.keys(), default="trajectory",
                    help="trajectory = autoware Trajectory; fmspath = FMSPath")
    ap.add_argument("--step", type=int, default=0,
                    help="footprint stride (0 = auto ~20 boxes)")
    ap.add_argument("--csv", default="/tmp/planning_trajectory.csv")
    ap.add_argument("--duration", type=float, default=0.0,
                    help="seconds to accumulate+dedupe (0 = grab one msg)")
    args = ap.parse_args()

    msg_cls = MSG_TYPES[args.msg]
    msg, stitched = grab(args.topic, msg_cls, accumulate=args.duration)

    xs, ys, yaws = [], [], []
    if stitched is not None:
        for x, y, yaw in stitched:
            xs.append(x); ys.append(y); yaws.append(yaw)
    elif msg is not None:
        for p in _iter_records(msg):
            x, y, yaw = _extract(p)
            xs.append(x); ys.append(y); yaws.append(yaw)

    if not xs:
        print(f"no points received on {args.topic}", file=sys.stderr)
        sys.exit(1)

    with open(args.csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["x", "y", "yaw"])
        for x, y, yaw in zip(xs, ys, yaws):
            w.writerow([f"{x:.6f}", f"{y:.6f}", f"{yaw:.6f}"])

    step = args.step if args.step > 0 else max(1, len(xs) // 20)

    fig, ax = plt.subplots(figsize=(10, 10))
    for i in range(0, len(xs), step):
        ax.add_patch(Polygon(footprint(xs[i], ys[i], yaws[i]),
                             closed=True, fill=False,
                             edgecolor="tab:orange", linewidth=0.8, alpha=0.6))
    ax.plot(xs, ys, "-o", color="tab:orange", ms=2,
            label=f"{args.topic} ({len(xs)} pts)")
    ax.set_title(f"Planning trajectory footprints\n"
                 f"{VEH_LEN}m × {VEH_WIDTH}m (geometric center)")
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.4)
    ax.legend()

    fig.tight_layout()
    fig.savefig(args.out, dpi=120)
    print(f"wrote {args.out}  (pts={len(xs)}, step={step}, csv={args.csv})")


if __name__ == "__main__":
    main()
