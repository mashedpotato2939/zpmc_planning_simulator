#!/usr/bin/env python3
"""Plot reference (map_traj_server) vs SUT (igv_path_planner) Q_TURN
trajectories from /tmp/qturn_{ref,sut}.csv produced by qturn_compare_test."""
import csv
import sys

import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon


# IGV dimensions (fms_path_converter.param.yaml).
VEH_LEN       = 15.0
VEH_WIDTH     = 3.0
FRONT_OVERHANG = 4.5
WHEEL_BASE    = 6.0
REAR_OVERHANG = VEH_LEN - FRONT_OVERHANG - WHEEL_BASE  # 4.5 m


def load(path):
    xs, ys, yaws = [], [], []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            xs.append(float(row["x"]))
            ys.append(float(row["y"]))
            yaws.append(float(row["yaw"]))
    return xs, ys, yaws


def footprint(x, y, yaw):
    """Vehicle rectangle corners assuming (x,y) = geometric center."""
    c, s = math.cos(yaw), math.sin(yaw)
    hl = VEH_LEN / 2.0
    hw = VEH_WIDTH / 2.0
    local = [( hl,  hw), ( hl, -hw), (-hl, -hw), (-hl,  hw)]
    return [(x + c * lx - s * ly, y + s * lx + c * ly) for lx, ly in local]


def draw_footprints(ax, xs, ys, yaws, color, step):
    for i in range(0, len(xs), step):
        poly = Polygon(footprint(xs[i], ys[i], yaws[i]),
                       closed=True, fill=False, edgecolor=color,
                       linewidth=0.8, alpha=0.5)
        ax.add_patch(poly)


def main():
    ref = load("/tmp/qturn_ref.csv")
    sut = load("/tmp/qturn_sut.csv")

    fig, (ax_xy, ax_yaw) = plt.subplots(1, 2, figsize=(16, 8))

    # Footprints first (behind the polylines).
    draw_footprints(ax_xy, *ref, color="tab:blue",   step=max(1, len(ref[0]) // 12))
    draw_footprints(ax_xy, *sut, color="tab:orange", step=max(1, len(sut[0]) // 12))

    ax_xy.plot(ref[0], ref[1], "-o", color="tab:blue", ms=3, label="map_traj_server (reference)")
    ax_xy.plot(sut[0], sut[1], "-s", color="tab:orange", ms=3, label="igv_path_planner (SUT)")
    ax_xy.set_title(f"Q_TURN XY  (0,0) → (16,16), R=15.5, R_yaw=8.1\n"
                    f"footprint {VEH_LEN}m × {VEH_WIDTH}m (geometric center)")
    ax_xy.set_xlabel("x [m]")
    ax_xy.set_ylabel("y [m]")
    ax_xy.set_aspect("equal")
    ax_xy.grid(True, alpha=0.4)
    ax_xy.legend()

    ax_yaw.plot(range(len(ref[2])), ref[2], "-o", color="tab:blue", ms=3, label="reference")
    ax_yaw.plot(range(len(sut[2])), sut[2], "-s", color="tab:orange", ms=3, label="SUT")
    ax_yaw.set_title("Yaw vs sample index")
    ax_yaw.set_xlabel("sample index")
    ax_yaw.set_ylabel("yaw [rad]")
    ax_yaw.grid(True, alpha=0.4)
    ax_yaw.legend()

    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/qturn_compare.png"
    fig.tight_layout()
    fig.savefig(out, dpi=120)
    print(f"wrote {out}  (ref_pts={len(ref[0])}, sut_pts={len(sut[0])})")


if __name__ == "__main__":
    main()
