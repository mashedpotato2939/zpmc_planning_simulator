#!/usr/bin/env python3
"""Plot the *exact* footprint rendering that tier4_planning_rviz_plugin
applies in display_base.hpp, using the captured trajectory CSV.

Two panels:
  (A) Pre-patch  : top/bottom from rear_overhang (base_link == rear axle).
  (B) Post-patch : top/bottom from length/2      (base_link == geometric center).

Both panels use the exact vehicle_info values the plugin reads at runtime
(length=15, width=2.98, rear_overhang=4.5) and the exact corner winding
from display_base.hpp (lon = [top,top,bottom,bottom], lat = [left,right,right,left]).
"""
import argparse
import csv
import math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon


# From igv_vehicle_description/config/vehicle_info.param.yaml —
# read by VehicleInfoUtils in tier4_planning_rviz_plugin at runtime.
VEH_LENGTH    = 15.0
VEH_WIDTH     = 2.98
REAR_OVERHANG = 4.5


def load(path):
    xs, ys, yaws = [], [], []
    with open(path) as f:
        for row in csv.DictReader(f):
            xs.append(float(row["x"]))
            ys.append(float(row["y"]))
            yaws.append(float(row["yaw"]))
    return xs, ys, yaws


def plugin_corners(x_base, y_base, yaw, *, top, bottom, left, right):
    """Exact transcription of the corner construction in display_base.hpp:560-561.

        const std::array<float, 4> lon_offset_vec{top, top, bottom, bottom};
        const std::array<float, 4> lat_offset_vec{left, right, right, left};

    followed by the usual 2D rotation of (lon, lat) into world by yaw and
    translation to (x_base, y_base).
    """
    lon = (top,  top,    bottom, bottom)
    lat = (left, right,  right,  left)
    c, s = math.cos(yaw), math.sin(yaw)
    return [(x_base + c * l - s * a, y_base + s * l + c * a)
            for l, a in zip(lon, lat)]


def pre_patch(x, y, yaw, offset_from_baselink=0.0):
    # display_base.hpp BEFORE the patch:
    #   top    = length - rear_overhang - offset
    #   bottom = -rear_overhang         + offset
    top    = VEH_LENGTH - REAR_OVERHANG - offset_from_baselink
    bottom = -REAR_OVERHANG             + offset_from_baselink
    left   = -VEH_WIDTH / 2.0
    right  =  VEH_WIDTH / 2.0
    return plugin_corners(x, y, yaw, top=top, bottom=bottom, left=left, right=right)


def post_patch(x, y, yaw, offset_from_baselink=0.0):
    # display_base.hpp AFTER the patch (current installed code):
    #   half_length = length / 2
    #   top    =  half_length - offset
    #   bottom = -half_length - offset
    half_length = VEH_LENGTH / 2.0
    top    =  half_length - offset_from_baselink
    bottom = -half_length - offset_from_baselink
    left   = -VEH_WIDTH / 2.0
    right  =  VEH_WIDTH / 2.0
    return plugin_corners(x, y, yaw, top=top, bottom=bottom, left=left, right=right)


def draw(ax, xs, ys, yaws, corners_fn, color, step, label):
    for i in range(0, len(xs), step):
        ax.add_patch(Polygon(corners_fn(xs[i], ys[i], yaws[i]),
                             closed=True, fill=False,
                             edgecolor=color, linewidth=0.8, alpha=0.75))
    ax.plot(xs, ys, "-", color=color, lw=1.0, alpha=0.9)
    ax.plot(xs, ys, ".", color=color, ms=3)
    ax.set_title(label)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="/tmp/behavior_path.csv")
    ap.add_argument("--out", default="/igv/qturn_rviz_compare.png")
    args = ap.parse_args()

    xs, ys, yaws = load(args.csv)
    step = max(1, len(xs) // 20)

    fig, axes = plt.subplots(1, 2, figsize=(16, 8), sharex=True, sharey=True)
    draw(axes[0], xs, ys, yaws, pre_patch,  "tab:red",
         step,
         f"RViz pre-patch (tier4_planning_rviz_plugin as shipped)\n"
         f"length={VEH_LENGTH}, width={VEH_WIDTH}, rear_overhang={REAR_OVERHANG}\n"
         f"rect = [-{REAR_OVERHANG}, +{VEH_LENGTH-REAR_OVERHANG}] × ±{VEH_WIDTH/2:.3f}")
    draw(axes[1], xs, ys, yaws, post_patch, "tab:green",
         step,
         f"RViz post-patch (current installed plugin)\n"
         f"length={VEH_LENGTH}, width={VEH_WIDTH}\n"
         f"rect = [-{VEH_LENGTH/2}, +{VEH_LENGTH/2}] × ±{VEH_WIDTH/2:.3f}")

    fig.suptitle(
        f"Q_TURN footprint rendering from display_base.hpp math  "
        f"(CSV {args.csv}, {len(xs)} pts, step={step})")
    fig.tight_layout()
    fig.savefig(args.out, dpi=120)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
