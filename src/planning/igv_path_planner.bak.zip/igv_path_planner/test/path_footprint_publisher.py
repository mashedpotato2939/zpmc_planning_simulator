#!/usr/bin/env python3
"""Publish /planning/.../path footprints as a MarkerArray using the *exact*
same rectangle math as plot_trajectory_footprint.py:

    VEH_LEN = 15.0, VEH_WIDTH = 3.0
    local corners = [(+hl,+hw), (+hl,-hw), (-hl,-hw), (-hl,+hw)]
    world = (x + c*lx - s*ly, y + s*lx + c*ly)

Run it alongside the live system, then add a MarkerArray display in RViz
pointing at the publisher's topic (default /fms/path_footprints_py). The
resulting boxes are guaranteed to match the Python plot 1:1 because it's
the same formula driven by the same subscribed PathPoints.

Usage:
    ros2 run ... (not installed); invoke directly:
    python3 path_footprint_publisher.py \
        [--in-topic /planning/scenario_planning/lane_driving/behavior_planning/path] \
        [--out-topic /fms/path_footprints_py] \
        [--msg path|trajectory|fmspath] \
        [--step N]
"""
import argparse
import math

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy

from autoware_planning_msgs.msg import Path, Trajectory
from igv_planning_msgs.msg import FMSPath
from geometry_msgs.msg import Point
from std_msgs.msg import ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray


VEH_LEN = 15.0
VEH_WIDTH = 3.0

MSG_TYPES = {"path": Path, "trajectory": Trajectory, "fmspath": FMSPath}


def quat_to_yaw(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def _iter_records(msg):
    return getattr(msg, "points", None) or getattr(msg, "waypoints", None) or []


def _extract(p):
    if hasattr(p, "pose"):
        return p.pose.position.x, p.pose.position.y, quat_to_yaw(p.pose.orientation)
    return p.x, p.y, p.yaw


def footprint_world(x, y, yaw):
    c, s = math.cos(yaw), math.sin(yaw)
    hl, hw = VEH_LEN / 2.0, VEH_WIDTH / 2.0
    local = [( hl,  hw), ( hl, -hw), (-hl, -hw), (-hl,  hw)]
    return [(x + c * lx - s * ly, y + s * lx + c * ly) for lx, ly in local]


class PathFootprintPublisher(Node):
    def __init__(self, in_topic, out_topic, msg_cls, step, frame_id_override):
        super().__init__("path_footprint_publisher")
        self.step = max(1, step)
        self.frame_id_override = frame_id_override

        sub_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        pub_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.pub = self.create_publisher(MarkerArray, out_topic, pub_qos)
        self.sub = self.create_subscription(msg_cls, in_topic, self.cb, sub_qos)
        self.get_logger().info(
            f"subscribing {in_topic} ({msg_cls.__name__}), publishing MarkerArray on {out_topic}, step={self.step}")

    def cb(self, msg):
        frame_id = self.frame_id_override or getattr(msg.header, "frame_id", "map") or "map"
        stamp = self.get_clock().now().to_msg()
        arr = MarkerArray()

        delete = Marker()
        delete.header.frame_id = frame_id
        delete.header.stamp = stamp
        delete.ns = "path_footprints_py"
        delete.action = Marker.DELETEALL
        arr.markers.append(delete)

        records = list(_iter_records(msg))
        if not records:
            self.pub.publish(arr)
            return

        color = ColorRGBA(r=0.0, g=1.0, b=1.0, a=0.8)
        for i in range(0, len(records), self.step):
            x, y, yaw = _extract(records[i])
            corners = footprint_world(x, y, yaw)

            m = Marker()
            m.header.frame_id = frame_id
            m.header.stamp = stamp
            m.ns = "path_footprints_py"
            m.id = i
            m.type = Marker.LINE_STRIP
            m.action = Marker.ADD
            m.pose.orientation.w = 1.0
            m.scale.x = 0.1
            m.color = color
            for (px, py) in corners:
                pt = Point()
                pt.x, pt.y, pt.z = px, py, 0.1
                m.points.append(pt)
            pt0 = Point()
            pt0.x, pt0.y = corners[0]
            pt0.z = 0.1
            m.points.append(pt0)
            arr.markers.append(m)

        self.pub.publish(arr)
        self.get_logger().info(
            f"published {len(arr.markers) - 1} footprints ({len(records)} path pts, step={self.step})",
            throttle_duration_sec=2.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-topic",
                    default="/planning/scenario_planning/lane_driving/behavior_planning/path")
    ap.add_argument("--out-topic", default="/fms/path_footprints_py")
    ap.add_argument("--msg", choices=MSG_TYPES.keys(), default="path")
    ap.add_argument("--step", type=int, default=10,
                    help="draw a footprint every Nth path point (default 10)")
    ap.add_argument("--frame-id", default="",
                    help="override marker frame_id (default: copy from path header)")
    args = ap.parse_args()

    rclpy.init()
    node = PathFootprintPublisher(args.in_topic, args.out_topic,
                                  MSG_TYPES[args.msg], args.step, args.frame_id)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
