# fms_trajectory_converter_node

Translates incoming FMS trajectories (binary or JSON) into Autoware `Trajectory` messages, crops them around the ego pose, and republishes at a configurable rate with health status.

## Overview

This node converts FMS trajectory messages to Autoware trajectory format. Unlike `fms_path_converter_node` which outputs `Path` messages for the planning stack, this node outputs `Trajectory` messages that can be fed directly to controllers or used for trajectory switching.

## Architecture

```
                    ┌─────────────────────────────────────────┐
                    │      fms_trajectory_converter_node      │
                    │                                         │
~/input/fms_trajectory ──► fmsTrajectoryCallback()            │
        or              │        │                            │
~/input/fms_json ───────┼────────┤                            │
                        │        ▼                            │
                        │   convertFMSToAutowareTrajectory()  │
                        │        │                            │
                        │        ▼                            │
                        │   cropTrajectoryFromEgo()           │
                        │        │                            │
                        │        ▼                            │
                        │   [Store & Publish]                 │──► ~/output/trajectory
                        │                                     │
                        │   timerCallback() @ publish_rate    │──► ~/output/status
                        │     └─► Republish with fresh stamp  │
                        │                                     │
                        └─────────────────────────────────────┘
```

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `frame_id` | string | `"map"` | Reference frame for output messages |
| `default_velocity` | double | `5.0` | Default velocity when not specified (m/s) |
| `min_velocity` | double | `0.5` | Minimum velocity clamp (m/s) |
| `max_velocity` | double | `15.0` | Maximum velocity clamp (m/s) |
| `trajectory_interval` | double | `0.5` | Point spacing for interpolation (m) |
| `forward_length` | double | `100.0` | Trajectory length ahead of ego (m) |
| `backward_length` | double | `5.0` | Trajectory length behind ego (m) |
| `stale_threshold` | double | `5.0` | Time before marking FMS as disconnected (s) |
| `use_json_input` | bool | `false` | Enable JSON input subscription |
| `publish_rate` | double | `20.0` | Output republishing rate (Hz) |

## Topics

### Subscriptions

| Topic | Type | QoS | Description |
|-------|------|-----|-------------|
| `~/input/fms_trajectory` | `igv_planning_msgs/FMSTrajectory` | Default (10) | FMS trajectory input (binary) |
| `~/input/fms_json` | `std_msgs/String` | Default (10) | FMS trajectory input (JSON, if enabled) |
| `~/input/odometry` | `nav_msgs/Odometry` | Default (10) | Vehicle odometry for cropping |

### Publications

| Topic | Type | QoS | Description |
|-------|------|-----|-------------|
| `~/output/trajectory` | `autoware_planning_msgs/Trajectory` | Default (10) | Converted Autoware trajectory |
| `~/output/status` | `igv_planning_msgs/FMSStatus` | Default (10) | Conversion status |

## Conversion Process

### 1. Waypoint Conversion

Each FMS waypoint is converted to an Autoware `TrajectoryPoint`:

| FMS Field | Autoware Field | Notes |
|-----------|---------------|-------|
| `x`, `y`, `z` | `pose.position` | Direct copy |
| `yaw` | `pose.orientation` | Converted to quaternion. If yaw ~0, calculated from next point direction |
| `velocity` | `longitudinal_velocity_mps` | Clamped to [min, max] or default if ≤0 |
| `acceleration` | `acceleration_mps2` | Direct copy |
| `time_from_start` | `time_from_start` | Split into sec/nanosec |
| `waypoint_type` | (velocity) | STOP/GOAL types set velocity to 0 |

### 2. Trajectory Cropping

Crops trajectory around ego position:

1. Find nearest point to ego using Euclidean distance
2. Accumulate points backward until `backward_length` reached
3. Accumulate points forward until `forward_length` reached
4. Extract cropped segment

### 3. Goal Handling

- Last point always has `velocity = 0` (goal stop)
- STOP and GOAL waypoint types force `velocity = 0`

## Staleness Detection

The node tracks FMS connectivity:

- `last_fms_message_time_` updated on each FMS message
- Timer checks if `(now - last_time) > stale_threshold`
- If stale, `fms_connected_ = false`
- Stale trajectories are not republished

## JSON Input Format

When `use_json_input` is enabled:

```json
{
  "trajectory_id": "traj_001",
  "waypoints": [
    {
      "x": 100.0,
      "y": 50.0,
      "z": 0.0,
      "yaw": 0.0,
      "velocity": 5.0,
      "acceleration": 0.0,
      "time_from_start": 0.0,
      "type": 0
    }
  ]
}
```

## Usage Examples

### Basic Launch

```bash
ros2 run igv_path_planner igv_trajectory_converter
```

### With JSON Input

```bash
ros2 run igv_path_planner igv_trajectory_converter --ros-args \
  -p use_json_input:=true \
  -p publish_rate:=30.0
```

### Monitor Output

```bash
# Watch trajectory
ros2 topic echo ~/output/trajectory

# Check status
ros2 topic echo ~/output/status
```

## Comparison with fms_path_converter_node

| Feature | fms_trajectory_converter | fms_path_converter |
|---------|--------------------------|-------------------|
| Output type | `Trajectory` | `Path` + `LaneletRoute` |
| Intelligent path gen | No | Yes (Bezier curves) |
| Reverse driving | No | Yes |
| Drivable bounds | No | Yes (curvature-based) |
| Velocity profile | Basic | Deceleration profile |
| Use case | Direct to controller | Through planning stack |

## FMSStatus Output

Same status message format as `fms_path_converter_node`:

| Field | Description |
|-------|-------------|
| `fms_connected` | True if messages received within threshold |
| `trajectory_valid` | True if output trajectory has points |
| `trajectory_stale` | True if FMS disconnected |
| `distance_to_goal` | Distance from ego to trajectory end |

## Related Nodes

- **fms_path_converter_node**: Path conversion with intelligent generation
- **trajectory_switch_node**: Switch between FMS and Autoware trajectories
- **fms_velocity_shaper_node**: Replaces trajectory_relay + obstacle_cruise_planner in FMS mode (Phase 3 of velocity_planner_simplification_plan.md)
