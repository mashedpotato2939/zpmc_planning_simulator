// Copyright 2024 ZPMC
// Licensed under the Apache License, Version 2.0

#ifndef FMS_TRAJECTORY_BRIDGE__MAP_PATH_GENERATOR_HPP_
#define FMS_TRAJECTORY_BRIDGE__MAP_PATH_GENERATOR_HPP_

#include <hdmap/hd_map.h>

#include <autoware_planning_msgs/msg/path_point.hpp>
#include <geometry_msgs/msg/point.hpp>

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace igv_path_planner
{

// Forward declaration to avoid circular includes
class PathGenerator;

/// Generates dense Autoware paths by snapping FMS waypoints to HD Map lane centerlines.
/// Falls back to linear interpolation for waypoints that don't snap to any lane.
class MapPathGenerator
{
public:
  struct Parameters {
    double snap_distance_threshold = 5.0;  // Max distance (m) from waypoint to lane
    double path_interval = 1.0;            // Output spacing (m)
    bool use_lane_speed_limits = false;    // Override FMS speed with lane speed limits
    double default_velocity = 5.0;         // Fallback velocity (m/s)
  };

  /// Per-input-waypoint snap outcome (1:1 with sparse_points).
  /// For valid entries, (x,y,z) is the cartesian projection onto the lane centerline
  /// (lateral = 0). For invalid entries (no lane within snap_distance_threshold),
  /// (x,y,z) copies the raw waypoint position and lane_id is 0.
  struct InputProjection {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    uint64_t lane_id = 0;
    float snap_dist = 0.0f;
    bool valid = false;
  };

  struct SnapResult {
    std::vector<autoware_planning_msgs::msg::PathPoint> points;
    std::vector<geometry_msgs::msg::Point> left_bound;
    std::vector<geometry_msgs::msg::Point> right_bound;
    std::vector<InputProjection> input_projections;
    bool fully_snapped = false;  // True if all waypoints were map-snapped
  };

  explicit MapPathGenerator(const Parameters & params);

  /// Generate a map-snapped dense path from sparse FMS waypoints.
  /// Returns empty result if snapping fails entirely.
  /// If path_gen is provided, lane-change segments use oblique arc generation
  /// instead of linear interpolation.
  SnapResult generateMapSnappedPath(
    const std::vector<autoware_planning_msgs::msg::PathPoint> & sparse_points,
    const std::vector<uint8_t> & lane_change_types,
    hdmap::HdMap & map,
    bool is_reverse,
    PathGenerator * path_gen = nullptr);

private:
  using LaneNeighborProvider = std::function<std::vector<hdmap::LaneID>(hdmap::LaneID)>;

  friend class MapPathGeneratorTestAccess;

  struct WaypointProjection {
    hdmap::LaneID lane_id = 0;
    hdmap::ProjectionResult proj{};
    bool valid = false;
  };

  /// Project a single waypoint to the nearest lane.
  WaypointProjection projectWaypoint(float x, float y, hdmap::HdMap & map) const;

  /// BFS through lane topology to find an ordered lane sequence, then tries a
  /// direct endpoint-continuity fallback for maps with one missing edge.
  /// Returns empty if no path found (triggers geometric interpolation fallback).
  /// On return, *follows_successors (if non-null) is true when the result was
  /// found by forward (successor) BFS — every lane in the sequence is traversed
  /// in its natural s-ascending direction — and false when found by predecessor
  /// BFS (the returned sequence is still from_lane -> ... -> to_lane, but every
  /// lane is traversed s-descending).
  std::vector<hdmap::LaneID> findLaneSequence(
    hdmap::LaneID from_lane, float from_s,
    hdmap::LaneID to_lane, float to_s,
    hdmap::HdMap & map,
    bool * follows_successors = nullptr) const;

  /// Topology-only implementation for findLaneSequence(). Kept separate so the
  /// lane-order contract can be unit-tested without constructing an HdMap.
  static std::vector<hdmap::LaneID> findLaneSequenceByTopology(
    hdmap::LaneID from_lane, hdmap::LaneID to_lane,
    const LaneNeighborProvider & get_successors,
    const LaneNeighborProvider & get_predecessors,
    bool * follows_successors = nullptr);

  /// Direct fallback for maps with a missing topology edge but continuous
  /// lane endpoints. Returns from_lane -> to_lane when endpoint geometry is
  /// close enough to define an unambiguous two-lane sequence.
  static std::vector<hdmap::LaneID> findLaneSequenceByEndpointContinuity(
    hdmap::LaneID from_lane,
    const hdmap::Vec3f & from_first,
    const hdmap::Vec3f & from_last,
    hdmap::LaneID to_lane,
    const hdmap::Vec3f & to_first,
    const hdmap::Vec3f & to_last,
    float max_endpoint_distance_m,
    bool * follows_successors = nullptr);

  /// Extract centerline points between s_lo and s_hi on a single lane.
  /// Resamples at path_interval. Emits points in **motion order**: s-ascending when
  /// fms_matches_lane (FMS travel direction aligns with the lane's natural s direction),
  /// s-descending otherwise. Orientation is the vehicle-facing yaw — derived from
  /// consecutive output positions (motion direction) with a +π flip when is_reverse.
  void extractCenterlineSegment(
    hdmap::LaneID lane_id, float s_lo, float s_hi,
    bool fms_matches_lane, bool is_reverse, double velocity,
    hdmap::HdMap & map,
    std::vector<autoware_planning_msgs::msg::PathPoint> & out_points) const;

  /// Extract left/right boundary points for a lane segment.
  /// When !fms_matches_lane, the segment is iterated in s-descending order AND
  /// left/right are swapped (lane-left is on the right of the motion direction when
  /// traversing the lane against its natural direction).
  void extractBoundarySegment(
    hdmap::LaneID lane_id, float s_lo, float s_hi,
    bool fms_matches_lane, hdmap::HdMap & map,
    std::vector<geometry_msgs::msg::Point> & left_out,
    std::vector<geometry_msgs::msg::Point> & right_out) const;

  /// Linear interpolation fallback between two points. is_reverse selects the
  /// body-frame yaw convention (vehicle-facing = motion direction + π for reverse).
  void interpolateSegment(
    const autoware_planning_msgs::msg::PathPoint & from,
    const autoware_planning_msgs::msg::PathPoint & to,
    bool is_reverse,
    std::vector<autoware_planning_msgs::msg::PathPoint> & out_points) const;

public:
  /// Resample a centerline slice (already restricted to the lane's s_lo..s_hi range,
  /// in s-ascending order) into evenly-spaced path points carrying motion-order
  /// positions and vehicle-facing yaws. Exposed as a static helper so the orientation
  /// and ordering logic can be unit-tested without an HdMap dependency.
  static void resampleAndOrient(
    const std::vector<hdmap::Vec3f> & centerline_slice,
    double path_interval,
    bool fms_matches_lane,
    bool is_reverse,
    double seg_velocity,
    std::vector<autoware_planning_msgs::msg::PathPoint> & out);

private:

  /// Create quaternion from yaw angle.
  static geometry_msgs::msg::Quaternion quaternionFromYaw(double yaw);

  Parameters params_;
};

}  // namespace igv_path_planner

#endif  // FMS_TRAJECTORY_BRIDGE__MAP_PATH_GENERATOR_HPP_
