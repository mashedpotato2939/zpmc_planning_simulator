// Copyright 2024 ZPMC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef FMS_TRAJECTORY_BRIDGE__FMS_PATH_CONVERTER_NODE_HPP_
#define FMS_TRAJECTORY_BRIDGE__FMS_PATH_CONVERTER_NODE_HPP_

#include <rclcpp/rclcpp.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#include <autoware/freespace_planning_algorithms/astar_search.hpp>
#include <autoware/motion_utils/trajectory/trajectory.hpp>
#include <autoware_planning_msgs/msg/path.hpp>
#include <autoware_planning_msgs/msg/path_point.hpp>
#include <autoware_planning_msgs/msg/lanelet_route.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/msg/u_int8.hpp>
#include <unique_identifier_msgs/msg/uuid.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include "igv_planning_msgs/msg/fms_path.hpp"
#include "igv_planning_msgs/msg/fms_status.hpp"
#include "igv_planning_msgs/msg/fms_route_window.hpp"
#include "igv_planning_msgs/msg/fms_stop_point.hpp"
#include "igv_planning_msgs/msg/adapter_status.hpp"
#include "igv_path_planner/path_generator.hpp"
#include "igv_path_planner/map_path_generator.hpp"
#include "igv_path_planner/fms_protocol.hpp"
#include "zpmc_map_loader/zpmc_map_client.hpp"

// Reverse driving support
#include "reverse_vehicle_msg/msg/vehicle_reversed.hpp"
#include "reverse_vehicle_msg/srv/set_vehicle_reverse_state.hpp"

#include <cstddef>
#include <memory>
#include <string>
#include <vector>
#include <optional>
#include <mutex>
#include <utility>

namespace igv_path_planner
{

bool truncatePathFromEgoPose(
  autoware_planning_msgs::msg::Path & path,
  const geometry_msgs::msg::Pose & ego_pose,
  double nearest_dist_threshold,
  double nearest_yaw_threshold,
  double back_buffer_length = 0.0,
  double min_projection_distance = 0.3);

void shiftResolvedRangesAfterReplacement(
  std::vector<std::pair<size_t, size_t>> & ranges,
  size_t replaced_end_idx,
  std::ptrdiff_t delta);

class FMSPathConverterNode : public rclcpp::Node
{
public:
  explicit FMSPathConverterNode(const rclcpp::NodeOptions & options);
  ~FMSPathConverterNode() = default;

private:
  // === Protocol plugin callbacks (unified entry points) ===
  void onRouteWindow(const igv_planning_msgs::msg::FMSRouteWindow::SharedPtr msg);
  void onStopPoint(const igv_planning_msgs::msg::FMSStopPoint::SharedPtr msg);

  // === Legacy callbacks (kept for backward compatibility, used by LegacyProtocol internally) ===
  void odometryCallback(const nav_msgs::msg::Odometry::SharedPtr msg);
  void timerCallback();

  // === Route window path conversion ===
  autoware_planning_msgs::msg::Path convertRouteWindowToAutowarePath(
    const igv_planning_msgs::msg::FMSRouteWindow & window);
  void connectEgoToPath(autoware_planning_msgs::msg::Path & path);
  void recomputeHeadingFromGeometry(autoware_planning_msgs::msg::Path & path);

  // === Legacy path conversion (used internally by LegacyProtocol via FMSPath→RouteWindow) ===
  autoware_planning_msgs::msg::Path convertFMSPathToAutowarePath(
    const igv_planning_msgs::msg::FMSPath & fms_path);

  std::optional<igv_planning_msgs::msg::FMSPath> parseJsonPath(const std::string & json_str);

  geometry_msgs::msg::Quaternion createQuaternionFromYaw(double yaw);
  double getYaw(const geometry_msgs::msg::Quaternion & q);

  // === Path processing pipeline ===
  bool publishPathFromReference();
  void truncatePathFromEgo(autoware_planning_msgs::msg::Path & path);
  void cropPathFromEgo(autoware_planning_msgs::msg::Path & path);
  void extendPathToEgo(autoware_planning_msgs::msg::Path & path);
  void prependEgoProjection(autoware_planning_msgs::msg::Path & path);
  void interpolatePath(autoware_planning_msgs::msg::Path & path);
  void addVelocityProfile(autoware_planning_msgs::msg::Path & path);
  void addVelocityProfileForWindow(autoware_planning_msgs::msg::Path & path);
  // Appends a short zero-velocity tail past the destination so the downstream
  // elastic_band_smoother never has to decide whether the v=0 stop falls
  // inside or just outside its last output segment (its is_stop_point_inside_trajectory
  // boundary check otherwise drops the stop intermittently as ego advances).
  void extendPathBeyondGoal(autoware_planning_msgs::msg::Path & path);
  void smoothPath(autoware_planning_msgs::msg::Path & path);
  void generateDrivableBounds(autoware_planning_msgs::msg::Path & path);
  void cropDrivableBounds(autoware_planning_msgs::msg::Path & path);
  void applyStopPoint(autoware_planning_msgs::msg::Path & path);

  // Curvature-based drivable area expansion helpers
  double computeCurvatureAtIndex(
    const std::vector<autoware_planning_msgs::msg::PathPoint> & points,
    size_t index) const;
  double calculateMinimumLaneWidth(double curvature) const;
  void smoothDrivableBounds(autoware_planning_msgs::msg::Path & path);

  // === Route generation ===
  void publishRouteFromFMSPath(const igv_planning_msgs::msg::FMSPath & fms_path);
  void publishRouteFromWindow(const igv_planning_msgs::msg::FMSRouteWindow & window);
  unique_identifier_msgs::msg::UUID generateUUID();

  // === Uplink reporting (protocol plugin sends these to FMS) ===
  void reportVehicleStatusToFMS();
  void reportTrajectoryToFMS();
  void checkArrivalAndReport();

  // === Status ===
  void publishStatus();
  void publishAdapterStatus();

  // Publish per-input-waypoint projection markers (authoritative snap result from
  // MapPathGenerator). Separate topic so RViz can display it independently of
  // the raw waypoint markers emitted by the RViz panel.
  void publishProjectedWaypointMarkers(
    const std::vector<autoware_planning_msgs::msg::PathPoint> & raw_points,
    const MapPathGenerator::SnapResult & snap);

  // === Utility ===
  size_t findNearestIndex(
    const autoware_planning_msgs::msg::Path & path,
    const geometry_msgs::msg::Point & point);
  double calcDistance2D(
    const geometry_msgs::msg::Point & p1,
    const geometry_msgs::msg::Point & p2);
  double computeLateralDeviationFromCachedPath() const;

  // === A* Local Planning (for POINT_LOCAL_PLAN_START/END zones) ===
  void initAstarPlanner();
  nav_msgs::msg::OccupancyGrid createSyntheticCostmap(
    const geometry_msgs::msg::Pose & start, const geometry_msgs::msg::Pose & goal,
    double margin) const;
  std::vector<autoware_planning_msgs::msg::PathPoint> planLocalPath(
    const geometry_msgs::msg::Pose & start, const geometry_msgs::msg::Pose & goal,
    double forward_vel, double reverse_vel);
  // resolved_ranges (optional output): inclusive [start, end] index ranges,
  // in the updated sparse_points, of the points produced by LOCAL_PLAN zone
  // resolution (Q_TURN clothoid or A* freespace). Returned in ascending
  // order so callers can walk the complement left-to-right.
  void resolveLocalPlanZones(
    std::vector<autoware_planning_msgs::msg::PathPoint> & sparse_points,
    std::vector<uint8_t> & lane_change_types,
    std::vector<uint8_t> & point_types,
    std::vector<std::pair<size_t, size_t>> * resolved_ranges = nullptr);
  void updateReverseStateFromPath(const autoware_planning_msgs::msg::Path & path);

  // === Reverse driving detection and control ===
  bool detectReverseFromFMSPath(const igv_planning_msgs::msg::FMSPath & fms_path);
  void updateReverseState(bool is_reverse, bool force_publish = false);
  void publishReverseState();
  void handleReverseStateService(
    const std::shared_ptr<reverse_vehicle_msg::srv::SetVehicleReverseState::Request> request,
    std::shared_ptr<reverse_vehicle_msg::srv::SetVehicleReverseState::Response> response);

  // === FMS Protocol Plugin ===
  std::unique_ptr<FMSProtocol> protocol_;

  // === Subscribers ===
  // Note: fms_path_sub_ and fms_json_sub_ are now managed by LegacyProtocol internally.
  // In default protocol mode, route_window/stop_point subscriptions are managed by DefaultProtocol.
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;

  // === Publishers ===
  rclcpp::Publisher<autoware_planning_msgs::msg::Path>::SharedPtr path_pub_;
  rclcpp::Publisher<autoware_planning_msgs::msg::LaneletRoute>::SharedPtr route_pub_;
  rclcpp::Publisher<igv_planning_msgs::msg::FMSStatus>::SharedPtr status_pub_;
  rclcpp::Publisher<igv_planning_msgs::msg::AdapterStatus>::SharedPtr adapter_status_pub_;
  rclcpp::Publisher<reverse_vehicle_msg::msg::VehicleReversed>::SharedPtr reverse_state_pub_;
  rclcpp::Publisher<std_msgs::msg::UInt8>::SharedPtr maneuver_type_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr projected_waypoints_marker_pub_;

  rclcpp::Service<reverse_vehicle_msg::srv::SetVehicleReverseState>::SharedPtr reverse_state_service_;

  // Timer
  rclcpp::TimerBase::SharedPtr timer_;

  // TF
  tf2_ros::Buffer tf_buffer_;
  tf2_ros::TransformListener tf_listener_;

  // === State ===
  std::mutex mutex_;
  nav_msgs::msg::Odometry::SharedPtr current_odom_;
  igv_planning_msgs::msg::FMSPath::SharedPtr last_fms_path_;                   // Legacy mode
  igv_planning_msgs::msg::FMSRouteWindow::SharedPtr last_window_;              // Default/unified mode
  autoware_planning_msgs::msg::Path::SharedPtr last_reference_path_;
  autoware_planning_msgs::msg::Path::SharedPtr last_output_path_;
  rclcpp::Time last_fms_message_time_;
  bool fms_connected_;
  std::string last_error_;
  std::string last_published_path_id_;   // Track which path ID we published route for (legacy)
  std::string last_published_route_id_;  // Full route_id (incl. "#p<n>" partition) — rebuild trigger
  std::string last_published_base_route_id_;  // Base route_id (suffix stripped) — job-level identity
  bool current_reverse_state_;           // Current reverse driving state
  bool last_reverse_state_;              // Previous reverse state (for change detection)

  // Stop point (from FMSStopPoint messages)
  std::optional<igv_planning_msgs::msg::FMSStopPoint> active_stop_;

  // Arrival tracking
  bool arrival_reported_{false};

  // Original goal tracking (preserved across cropping for proper deceleration)
  geometry_msgs::msg::Point original_goal_position_;
  bool has_original_goal_;  // True if original FMS path has a stop/goal at end

  // Uplink timer counter
  int timer_counter_{0};

  // Job tracking from last route window
  std::string current_job_id_;
  std::string current_job_task_id_;
  std::string current_route_id_;
  std::string vehicle_id_;

  // === Parameters ===
  std::string frame_id_;
  double default_velocity_;
  double min_velocity_;
  double max_velocity_;
  double path_interval_;
  double forward_path_length_;
  double backward_path_length_;
  double stale_threshold_;
  double ego_nearest_dist_threshold_;  // Distance threshold for finding ego on path
  double ego_nearest_yaw_threshold_;   // Yaw threshold for finding ego on path
  double replan_lateral_deviation_threshold_;  // [m] trigger rebuild when ego deviates this far from cached path
  bool enable_path_smoothing_;
  bool enable_velocity_profile_;
  bool enable_goal_tail_;       // append v=0 tail past destination (workaround for elastic_band stop-boundary jitter)
  double goal_tail_length_;     // total length of the tail past the destination [m]
  double goal_tail_step_;       // spacing of tail points [m]
  bool use_json_input_;
  double publish_rate_;
  double arrival_threshold_;

  // Path generator for lane changes, turns, curves
  bool enable_intelligent_path_generation_;
  std::unique_ptr<PathGenerator> path_generator_;

  // HD Map snapping (ZPMC HD Map)
  std::unique_ptr<zpmc_map_loader::ZpmcMapClient> map_client_;
  std::unique_ptr<MapPathGenerator> map_path_generator_;
  double map_snap_distance_threshold_;

  // Path generator parameters
  double lane_change_lateral_threshold_;
  double turn_yaw_threshold_;
  double min_lane_change_length_;
  double lane_change_velocity_ratio_;
  double turn_speed_;
  double qturn_speed_limit_;
  double oblique_speed_limit_;

  // Drivable area parameters
  bool generate_drivable_area_;
  double lane_width_;           // Total lane width (meters)
  double left_bound_offset_;    // Left bound offset from center (meters)
  double right_bound_offset_;   // Right bound offset from center (meters)

  // Curvature-based drivable area expansion (for large vehicles like IGV)
  bool enable_curvature_expansion_;
  double vehicle_length_;         // Total vehicle length (meters)
  double vehicle_width_;          // Total vehicle width (meters)
  double vehicle_front_overhang_; // Distance from front axle to front bumper (meters)
  double vehicle_wheel_base_;     // Distance between front and rear axles (meters)
  double min_bound_margin_;       // Minimum clearance from vehicle edge to bound (meters)

  // A* local planner (for POINT_LOCAL_PLAN zones)
  std::unique_ptr<autoware::freespace_planning_algorithms::AstarSearch> astar_planner_;
  double astar_costmap_resolution_;
  double astar_costmap_margin_;
  double vehicle_max_steer_angle_;

  // 4WS parameters - enables path to signal 4WS steering via lateral_velocity
  bool enable_4ws_;               // Enable 4WS lateral velocity calculation
  double max_lateral_velocity_;   // Maximum lateral velocity (m/s)
  double curvature_threshold_;    // Curvature threshold below which 4WS is not used (1/m)
  double lateral_velocity_gain_;  // Gain factor for lateral velocity calculation
};

}  // namespace igv_path_planner

#endif  // FMS_TRAJECTORY_BRIDGE__FMS_PATH_CONVERTER_NODE_HPP_
