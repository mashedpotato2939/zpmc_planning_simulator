// Copyright 2024 ZPMC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <rclcpp/rclcpp.hpp>
#include <tf2/utils.h>
#include <nlohmann/json.hpp>

#include <autoware_planning_msgs/msg/trajectory.hpp>
#include <autoware_planning_msgs/msg/trajectory_point.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <std_msgs/msg/string.hpp>

#include "igv_planning_msgs/msg/fms_trajectory.hpp"
#include "igv_planning_msgs/msg/fms_status.hpp"
#include "reverse_vehicle_msg/msg/vehicle_reversed.hpp"

#include <memory>
#include <string>
#include <vector>
#include <mutex>
#include <cmath>

namespace igv_path_planner
{

class FMSTrajectoryConverterNode : public rclcpp::Node
{
public:
  explicit FMSTrajectoryConverterNode(const rclcpp::NodeOptions & options)
  : Node("fms_trajectory_converter", options),
    fms_connected_(false)
  {
    // Declare parameters
    frame_id_ = declare_parameter<std::string>("frame_id", "map");
    default_velocity_ = declare_parameter<double>("default_velocity", 5.0);
    min_velocity_ = declare_parameter<double>("min_velocity", 0.5);
    max_velocity_ = declare_parameter<double>("max_velocity", 15.0);
    trajectory_interval_ = declare_parameter<double>("trajectory_interval", 0.5);
    forward_length_ = declare_parameter<double>("forward_length", 100.0);
    backward_length_ = declare_parameter<double>("backward_length", 5.0);
    stale_threshold_ = declare_parameter<double>("stale_threshold", 5.0);
    use_json_input_ = declare_parameter<bool>("use_json_input", false);
    publish_rate_ = declare_parameter<double>("publish_rate", 20.0);

    // 4WS parameters - enables trajectory to signal 4WS steering via lateral_velocity
    enable_4ws_ = declare_parameter<bool>("enable_4ws", true);
    vehicle_wheel_base_ = declare_parameter<double>("vehicle_wheel_base", 6.0);  // IGV wheelbase
    vehicle_length_ = declare_parameter<double>("vehicle_length", 15.0);         // IGV total length
    vehicle_front_overhang_ = declare_parameter<double>("vehicle_front_overhang", 4.5);
    max_lateral_velocity_ = declare_parameter<double>("max_lateral_velocity", 0.5);  // m/s (~2-3° sideslip)
    curvature_threshold_ = declare_parameter<double>("curvature_threshold", 0.01);   // 1/m, ignore below this

    if (enable_4ws_) {
      RCLCPP_INFO(get_logger(), "4WS support enabled: wheelbase=%.1fm, max_lat_vel=%.2fm/s",
        vehicle_wheel_base_, max_lateral_velocity_);
    }

    // Create subscribers
    fms_traj_sub_ = create_subscription<igv_planning_msgs::msg::FMSTrajectory>(
      "~/input/fms_trajectory", rclcpp::QoS(10),
      std::bind(&FMSTrajectoryConverterNode::fmsTrajectoryCallback, this, std::placeholders::_1));

    if (use_json_input_) {
      fms_json_sub_ = create_subscription<std_msgs::msg::String>(
        "~/input/fms_json", rclcpp::QoS(10),
        std::bind(&FMSTrajectoryConverterNode::fmsJsonCallback, this, std::placeholders::_1));
    }

    odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
      "~/input/odometry", rclcpp::QoS(10),
      std::bind(&FMSTrajectoryConverterNode::odometryCallback, this, std::placeholders::_1));

    // Create publishers
    traj_pub_ = create_publisher<autoware_planning_msgs::msg::Trajectory>(
      "~/output/trajectory", rclcpp::QoS(10));

    status_pub_ = create_publisher<igv_planning_msgs::msg::FMSStatus>(
      "~/output/status", rclcpp::QoS(10));

    // 倒车状态发布（latched）。与 fms_path_converter / fms_goal_path_generator 共用同一 topic，
    // 由 vehicle_cmd_gate 订阅以决定是否反转转向。
    reverse_state_pub_ = create_publisher<reverse_vehicle_msg::msg::VehicleReversed>(
      "/planning/reverse_state", rclcpp::QoS(1).reliable().transient_local());
    {
      reverse_vehicle_msg::msg::VehicleReversed init;
      init.is_reversed = false;
      reverse_state_pub_->publish(init);
    }

    // Create timer
    const auto period = std::chrono::duration<double>(1.0 / publish_rate_);
    timer_ = create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(period),
      std::bind(&FMSTrajectoryConverterNode::timerCallback, this));

    last_fms_message_time_ = this->now();

    RCLCPP_INFO(get_logger(), "FMS Trajectory Converter Node initialized");
  }

private:
  void fmsTrajectoryCallback(const igv_planning_msgs::msg::FMSTrajectory::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);

    last_fms_traj_ = msg;
    last_fms_message_time_ = this->now();
    fms_connected_ = true;

    try {
      auto autoware_traj = convertFMSToAutowareTrajectory(*msg);

      if (current_odom_) {
        cropTrajectoryFromEgo(autoware_traj);
      }

      last_output_traj_ = std::make_shared<autoware_planning_msgs::msg::Trajectory>(autoware_traj);
      traj_pub_->publish(autoware_traj);
      last_error_.clear();

    } catch (const std::exception & e) {
      last_error_ = e.what();
      RCLCPP_ERROR(get_logger(), "Failed to convert FMS trajectory: %s", e.what());
    }
  }

  void fmsJsonCallback(const std_msgs::msg::String::SharedPtr msg)
  {
    try {
      auto json = nlohmann::json::parse(msg->data);

      igv_planning_msgs::msg::FMSTrajectory fms_traj;
      fms_traj.header.stamp = this->now();
      fms_traj.header.frame_id = frame_id_;

      if (json.contains("trajectory_id")) {
        fms_traj.trajectory_id = json["trajectory_id"].get<std::string>();
      }

      if (json.contains("waypoints") && json["waypoints"].is_array()) {
        for (const auto & wp : json["waypoints"]) {
          igv_planning_msgs::msg::FMSWaypoint waypoint;
          waypoint.x = wp.value("x", 0.0);
          waypoint.y = wp.value("y", 0.0);
          waypoint.z = wp.value("z", 0.0);
          waypoint.yaw = wp.value("yaw", 0.0);
          waypoint.velocity = wp.value("velocity", -1.0);
          waypoint.acceleration = wp.value("acceleration", 0.0);
          waypoint.time_from_start = wp.value("time_from_start", 0.0);
          waypoint.waypoint_type = wp.value("type", 0);

          fms_traj.waypoints.push_back(waypoint);
        }
      }

      auto fms_traj_msg = std::make_shared<igv_planning_msgs::msg::FMSTrajectory>(fms_traj);
      fmsTrajectoryCallback(fms_traj_msg);

    } catch (const nlohmann::json::exception & e) {
      RCLCPP_ERROR(get_logger(), "Failed to parse JSON trajectory: %s", e.what());
      last_error_ = std::string("JSON parse error: ") + e.what();
    }
  }

  void odometryCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    std::lock_guard<std::mutex> lock(mutex_);
    current_odom_ = msg;
  }

  void timerCallback()
  {
    std::lock_guard<std::mutex> lock(mutex_);

    const double time_since_last = (this->now() - last_fms_message_time_).seconds();
    if (time_since_last > stale_threshold_) {
      fms_connected_ = false;
    }

    if (last_output_traj_ && fms_connected_) {
      last_output_traj_->header.stamp = this->now();
      traj_pub_->publish(*last_output_traj_);
    }

    publishStatus();
  }

  autoware_planning_msgs::msg::Trajectory convertFMSToAutowareTrajectory(
    const igv_planning_msgs::msg::FMSTrajectory & fms_traj)
  {
    autoware_planning_msgs::msg::Trajectory autoware_traj;
    autoware_traj.header.stamp = this->now();
    autoware_traj.header.frame_id = frame_id_;

    // 整段轨迹是否处于倒车（任一航点 is_reverse 为真）。约定：FMSWaypoint.yaw / 输出 pose
    // 的 orientation 表示车头朝向；倒车时 atan2(next-cur) 给出运动方向，需要再翻转 180° 才是车头朝向。
    bool traj_has_reverse = false;
    for (const auto & wp : fms_traj.waypoints) {
      if (wp.is_reverse) { traj_has_reverse = true; break; }
    }

    for (size_t i = 0; i < fms_traj.waypoints.size(); ++i) {
      const auto & wp = fms_traj.waypoints[i];

      autoware_planning_msgs::msg::TrajectoryPoint point;

      // Position
      point.pose.position.x = wp.x;
      point.pose.position.y = wp.y;
      point.pose.position.z = wp.z;

      // Orientation: 取 wp.yaw（车头朝向）。如未填写则由相邻点推算，倒车时翻转 180°。
      double yaw = wp.yaw;
      if (std::abs(yaw) < 1e-6 && i + 1 < fms_traj.waypoints.size()) {
        const auto & next_wp = fms_traj.waypoints[i + 1];
        yaw = std::atan2(next_wp.y - wp.y, next_wp.x - wp.x);
        if (wp.is_reverse) {
          yaw += M_PI;
        }
      }
      point.pose.orientation = createQuaternionFromYaw(yaw);

      // Velocity: 倒车段速度为负。wp.velocity ≤ 0 表示“使用默认值”。
      double speed_mag = (wp.velocity > 0)
        ? std::clamp(static_cast<double>(wp.velocity), min_velocity_, max_velocity_)
        : default_velocity_;
      point.longitudinal_velocity_mps = static_cast<float>(
        wp.is_reverse ? -speed_mag : speed_mag);

      // Handle stop points
      if (wp.waypoint_type == igv_planning_msgs::msg::FMSWaypoint::TYPE_STOP ||
          wp.waypoint_type == igv_planning_msgs::msg::FMSWaypoint::TYPE_GOAL)
      {
        point.longitudinal_velocity_mps = 0.0;
      }

      // Calculate lateral velocity for 4WS support
      // By allowing small v_y, the controller will automatically use counter-phase 4WS
      // which keeps the rear axle on the path and reduces swept area
      if (enable_4ws_ && std::abs(wp.curvature) > curvature_threshold_ &&
          std::abs(point.longitudinal_velocity_mps) > 0.1)
      {
        // Calculate rear overhang: vehicle_length - front_overhang - wheelbase
        const double rear_overhang = vehicle_length_ - vehicle_front_overhang_ - vehicle_wheel_base_;
        // Factor to keep rear axle on path: rear_overhang / wheelbase
        const double rear_factor = rear_overhang / vehicle_wheel_base_;
        // lateral_velocity = curvature * v_x * rear_factor
        const double v_x = static_cast<double>(point.longitudinal_velocity_mps);
        double lat_vel = wp.curvature * v_x * rear_factor;
        // Clamp to max lateral velocity (limits sideslip angle to ~2-3°)
        lat_vel = std::clamp(lat_vel, -max_lateral_velocity_, max_lateral_velocity_);
        point.lateral_velocity_mps = static_cast<float>(lat_vel);
      } else {
        point.lateral_velocity_mps = 0.0;
      }

      point.acceleration_mps2 = wp.acceleration;
      point.heading_rate_rps = 0.0;

      // Time from start
      point.time_from_start.sec = static_cast<int32_t>(wp.time_from_start);
      point.time_from_start.nanosec = static_cast<uint32_t>(
        (wp.time_from_start - point.time_from_start.sec) * 1e9);

      autoware_traj.points.push_back(point);
    }

    // Ensure last point has zero velocity
    if (!autoware_traj.points.empty()) {
      autoware_traj.points.back().longitudinal_velocity_mps = 0.0;
    }

    // 在状态翻转时刷新 /planning/reverse_state，使下游 vehicle_cmd_gate 反转转向。
    if (traj_has_reverse != last_reverse_state_) {
      reverse_vehicle_msg::msg::VehicleReversed msg_out;
      msg_out.is_reversed = traj_has_reverse;
      reverse_state_pub_->publish(msg_out);
      last_reverse_state_ = traj_has_reverse;
      RCLCPP_INFO(get_logger(), "Reverse state -> %s", traj_has_reverse ? "REVERSE" : "FORWARD");
    }

    return autoware_traj;
  }

  void cropTrajectoryFromEgo(autoware_planning_msgs::msg::Trajectory & traj)
  {
    if (traj.points.empty() || !current_odom_) {
      return;
    }

    const auto & ego_pos = current_odom_->pose.pose.position;
    size_t nearest_idx = findNearestIndex(traj, ego_pos);

    double accumulated_backward = 0.0;
    size_t start_idx = nearest_idx;

    for (size_t i = nearest_idx; i > 0; --i) {
      accumulated_backward += calcDistance2D(
        traj.points[i].pose.position,
        traj.points[i - 1].pose.position);
      if (accumulated_backward > backward_length_) {
        break;
      }
      start_idx = i - 1;
    }

    double accumulated_forward = 0.0;
    size_t end_idx = nearest_idx;

    for (size_t i = nearest_idx; i + 1 < traj.points.size(); ++i) {
      accumulated_forward += calcDistance2D(
        traj.points[i].pose.position,
        traj.points[i + 1].pose.position);
      end_idx = i + 1;
      if (accumulated_forward > forward_length_) {
        break;
      }
    }

    std::vector<autoware_planning_msgs::msg::TrajectoryPoint> cropped_points(
      traj.points.begin() + start_idx,
      traj.points.begin() + end_idx + 1);

    traj.points = cropped_points;
  }

  size_t findNearestIndex(
    const autoware_planning_msgs::msg::Trajectory & traj,
    const geometry_msgs::msg::Point & point)
  {
    size_t nearest_idx = 0;
    double min_dist = std::numeric_limits<double>::max();

    for (size_t i = 0; i < traj.points.size(); ++i) {
      const double dist = calcDistance2D(traj.points[i].pose.position, point);
      if (dist < min_dist) {
        min_dist = dist;
        nearest_idx = i;
      }
    }

    return nearest_idx;
  }

  double calcDistance2D(
    const geometry_msgs::msg::Point & p1,
    const geometry_msgs::msg::Point & p2)
  {
    return std::hypot(p2.x - p1.x, p2.y - p1.y);
  }

  geometry_msgs::msg::Quaternion createQuaternionFromYaw(double yaw)
  {
    geometry_msgs::msg::Quaternion q;
    q.w = std::cos(yaw / 2.0);
    q.x = 0.0;
    q.y = 0.0;
    q.z = std::sin(yaw / 2.0);
    return q;
  }

  void publishStatus()
  {
    igv_planning_msgs::msg::FMSStatus status;
    status.header.stamp = this->now();
    status.fms_connected = fms_connected_;
    status.last_message_time = (this->now() - last_fms_message_time_).seconds();

    if (last_fms_traj_) {
      status.current_trajectory_id = last_fms_traj_->trajectory_id;
      status.current_task_id = last_fms_traj_->task_id;
      status.waypoints_remaining = last_fms_traj_->waypoints.size();
    }

    status.current_mode = igv_planning_msgs::msg::FMSStatus::MODE_FMS_ONLY;
    status.trajectory_valid = (last_output_traj_ != nullptr && !last_output_traj_->points.empty());
    status.trajectory_stale = !fms_connected_;
    status.last_error = last_error_;

    if (last_output_traj_ && !last_output_traj_->points.empty() && current_odom_) {
      status.distance_to_goal = calcDistance2D(
        current_odom_->pose.pose.position,
        last_output_traj_->points.back().pose.position);
    }

    status_pub_->publish(status);
  }

  // Subscribers
  rclcpp::Subscription<igv_planning_msgs::msg::FMSTrajectory>::SharedPtr fms_traj_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr fms_json_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;

  // Publishers
  rclcpp::Publisher<autoware_planning_msgs::msg::Trajectory>::SharedPtr traj_pub_;
  rclcpp::Publisher<igv_planning_msgs::msg::FMSStatus>::SharedPtr status_pub_;
  rclcpp::Publisher<reverse_vehicle_msg::msg::VehicleReversed>::SharedPtr reverse_state_pub_;
  bool last_reverse_state_ = false;

  // Timer
  rclcpp::TimerBase::SharedPtr timer_;

  // State
  std::mutex mutex_;
  nav_msgs::msg::Odometry::SharedPtr current_odom_;
  igv_planning_msgs::msg::FMSTrajectory::SharedPtr last_fms_traj_;
  autoware_planning_msgs::msg::Trajectory::SharedPtr last_output_traj_;
  rclcpp::Time last_fms_message_time_;
  bool fms_connected_;
  std::string last_error_;

  // Parameters
  std::string frame_id_;
  double default_velocity_;
  double min_velocity_;
  double max_velocity_;
  double trajectory_interval_;
  double forward_length_;
  double backward_length_;
  double stale_threshold_;
  bool use_json_input_;
  double publish_rate_;

  // 4WS parameters
  bool enable_4ws_;
  double vehicle_wheel_base_;
  double vehicle_length_;
  double vehicle_front_overhang_;
  double max_lateral_velocity_;
  double curvature_threshold_;
};

}  // namespace igv_path_planner

#include <rclcpp_components/register_node_macro.hpp>
RCLCPP_COMPONENTS_REGISTER_NODE(igv_path_planner::FMSTrajectoryConverterNode)
