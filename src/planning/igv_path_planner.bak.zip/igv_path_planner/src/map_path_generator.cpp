// Copyright 2024 ZPMC
// Licensed under the Apache License, Version 2.0

#include "igv_path_planner/map_path_generator.hpp"
#include "igv_path_planner/path_generator.hpp"

#include <hdmap/lane.h>
#include <hdmap/projection.h>

#include <algorithm>
#include <cmath>
#include <queue>
#include <unordered_set>

namespace igv_path_planner
{

MapPathGenerator::MapPathGenerator(const Parameters & params)
: params_(params)
{
}

MapPathGenerator::SnapResult MapPathGenerator::generateMapSnappedPath(
  const std::vector<autoware_planning_msgs::msg::PathPoint> & sparse_points,
  const std::vector<uint8_t> & lane_change_types,
  hdmap::HdMap & map,
  bool is_reverse,
  PathGenerator * path_gen)
{
  SnapResult result;
  if (sparse_points.size() < 2) return result;

  // Step 1: Project all waypoints to nearest lanes
  std::vector<WaypointProjection> projections;
  projections.reserve(sparse_points.size());
  result.input_projections.reserve(sparse_points.size());
  int snapped_count = 0;

  for (const auto & pt : sparse_points) {
    auto proj = projectWaypoint(
      static_cast<float>(pt.pose.position.x),
      static_cast<float>(pt.pose.position.y),
      map);
    projections.push_back(proj);

    // Record per-input-waypoint projection for downstream visualization
    InputProjection ip;
    ip.snap_dist = std::sqrt(static_cast<double>(proj.proj.distance_sq));
    if (proj.valid) {
      hdmap::LaneView lane = map.getLane(proj.lane_id);
      if (lane.valid()) {
        hdmap::Vec3f sp = hdmap::projection::frenetToCartesian(
          lane, proj.proj.frenet.s, 0.0f);
        ip.x = static_cast<double>(sp.x);
        ip.y = static_cast<double>(sp.y);
        ip.z = static_cast<double>(sp.z);
        ip.lane_id = static_cast<uint64_t>(proj.lane_id);
        ip.valid = true;
      }
    }
    if (!ip.valid) {
      ip.x = pt.pose.position.x;
      ip.y = pt.pose.position.y;
      ip.z = pt.pose.position.z;
    }
    result.input_projections.push_back(ip);

    if (proj.valid) snapped_count++;
  }

  // If no waypoints snapped, return empty points (caller falls back to geometric).
  // Note: input_projections is still populated (all invalid) so the visualizer
  // can show which waypoints were rejected.
  if (snapped_count == 0) {
    result.points.clear();
    return result;
  }

  result.fully_snapped = (snapped_count == static_cast<int>(sparse_points.size()));

  // Step 2: Generate dense path segment by segment.
  // LC spans (consecutive lc_type!=0 waypoints) are merged into ONE oblique call so that
  // a single smooth arc covers LC_START → LC_END rather than one arc per sub-segment.
  size_t i = 0;
  while (i + 1 < sparse_points.size()) {
    bool is_lane_change = (i < lane_change_types.size() && lane_change_types[i] != 0);

    if (is_lane_change) {
      // Find the full LC span end: first index where lc_type returns to 0
      size_t lc_end = i + 1;
      while (lc_end < sparse_points.size() - 1 &&
             lc_end < lane_change_types.size() &&
             lane_change_types[lc_end] != 0) {
        lc_end++;
      }

      // Generate ONE oblique segment covering the full span [i .. lc_end]
      const auto & from_proj = projections[i];
      const auto & to_proj   = projections[lc_end];
      const auto & from_pt   = sparse_points[i];
      const auto & to_pt     = sparse_points[lc_end];

      if (from_proj.valid && to_proj.valid) {
        hdmap::LaneView from_lane = map.getLane(from_proj.lane_id);
        hdmap::LaneView to_lane   = map.getLane(to_proj.lane_id);
        if (from_lane.valid() && to_lane.valid()) {
          // Snap both endpoints to their respective lane centerlines (lateral = 0)
          hdmap::Vec3f sp0 = hdmap::projection::frenetToCartesian(
            from_lane, from_proj.proj.frenet.s, 0.0f);
          hdmap::Vec3f sp1 = hdmap::projection::frenetToCartesian(
            to_lane,   to_proj.proj.frenet.s,   0.0f);

          auto snapped_from = from_pt;
          snapped_from.pose.position.x = static_cast<double>(sp0.x);
          snapped_from.pose.position.y = static_cast<double>(sp0.y);
          snapped_from.pose.position.z = static_cast<double>(sp0.z);

          auto snapped_to = to_pt;
          snapped_to.pose.position.x = static_cast<double>(sp1.x);
          snapped_to.pose.position.y = static_cast<double>(sp1.y);
          snapped_to.pose.position.z = static_cast<double>(sp1.z);

          if (path_gen) {
            auto lc_pts = path_gen->generateObliqueLaneChangeSegment(snapped_from, snapped_to);
            for (size_t pi = result.points.empty() ? 0 : 1; pi < lc_pts.size(); ++pi) {
              result.points.push_back(lc_pts[pi]);
            }
          } else {
            interpolateSegment(snapped_from, snapped_to, is_reverse, result.points);
          }
        } else {
          interpolateSegment(from_pt, to_pt, is_reverse, result.points);
        }
      } else {
        interpolateSegment(from_pt, to_pt, is_reverse, result.points);
      }

      i = lc_end;  // skip all intermediate LC waypoints

    } else {
      // Non-LC segment: use map centerlines or fallback interpolation
      const auto & from_proj = projections[i];
      const auto & to_proj   = projections[i + 1];
      const auto & from_pt   = sparse_points[i];
      const auto & to_pt     = sparse_points[i + 1];

      double velocity = std::abs(from_pt.longitudinal_velocity_mps);
      if (velocity < 0.1) velocity = params_.default_velocity;

      if (from_proj.valid && to_proj.valid) {
        if (from_proj.lane_id == to_proj.lane_id) {
          // Same lane: extract centerline between s values.
          // The order (s_start vs s_end) tells us which way FMS travels through this
          // lane — keep that info before canonicalizing to s_lo/s_hi.
          const float s_start = from_proj.proj.frenet.s;
          const float s_end   = to_proj.proj.frenet.s;
          const bool fms_matches_lane = (s_start <= s_end);
          const float s_lo = std::min(s_start, s_end);
          const float s_hi = std::max(s_start, s_end);

          extractCenterlineSegment(
            from_proj.lane_id, s_lo, s_hi,
            fms_matches_lane, is_reverse, velocity, map, result.points);

          extractBoundarySegment(
            from_proj.lane_id, s_lo, s_hi,
            fms_matches_lane, map, result.left_bound, result.right_bound);
        } else {
          // Different lanes: find lane sequence via BFS.
          // follows_successors=true means every lane in the sequence is traversed
          // in its natural s-ascending direction (FMS travel aligns with the lane).
          // false means s-descending (FMS travels against the lane direction).
          bool follows_successors = true;
          auto lane_seq = findLaneSequence(
            from_proj.lane_id, from_proj.proj.frenet.s,
            to_proj.lane_id,   to_proj.proj.frenet.s,
            map, &follows_successors);

          if (!lane_seq.empty()) {
            for (size_t li = 0; li < lane_seq.size(); ++li) {
              hdmap::LaneView lane = map.getLane(lane_seq[li]);
              if (!lane.valid()) continue;

              // Each lane's [s_lo, s_hi] in natural coordinates depends on BFS direction
              // and whether this is the first/middle/last lane in the sequence.
              float s_lo, s_hi;
              if (follows_successors) {
                // Motion: from_proj.s → end of lane[0] → start of lane[1] → ... → to_proj.s
                if (li == 0) {
                  s_lo = from_proj.proj.frenet.s;
                  s_hi = lane.totalLength();
                } else if (li == lane_seq.size() - 1) {
                  s_lo = 0.0f;
                  s_hi = to_proj.proj.frenet.s;
                } else {
                  s_lo = 0.0f;
                  s_hi = lane.totalLength();
                }
              } else {
                // Motion: from_proj.s → start of lane[0] → end of lane[1] → ... → to_proj.s
                if (li == 0) {
                  s_lo = 0.0f;
                  s_hi = from_proj.proj.frenet.s;
                } else if (li == lane_seq.size() - 1) {
                  s_lo = to_proj.proj.frenet.s;
                  s_hi = lane.totalLength();
                } else {
                  s_lo = 0.0f;
                  s_hi = lane.totalLength();
                }
              }

              extractCenterlineSegment(
                lane_seq[li], s_lo, s_hi,
                follows_successors, is_reverse, velocity, map, result.points);

              extractBoundarySegment(
                lane_seq[li], s_lo, s_hi,
                follows_successors, map, result.left_bound, result.right_bound);
            }
          } else {
            interpolateSegment(from_pt, to_pt, is_reverse, result.points);
          }
        }
      } else {
        interpolateSegment(from_pt, to_pt, is_reverse, result.points);
      }

      i++;
    }
  }

  // Add final point
  if (!result.points.empty()) {
    result.points.back().is_final = true;
  }

  return result;
}

MapPathGenerator::WaypointProjection MapPathGenerator::projectWaypoint(
  float x, float y, hdmap::HdMap & map) const
{
  WaypointProjection wp;
  hdmap::ProjectionResult proj;

  if (map.findNearestLane(x, y, proj)) {
    double dist = std::sqrt(static_cast<double>(proj.distance_sq));
    if (dist <= params_.snap_distance_threshold) {
      wp.lane_id = proj.lane_id;
      wp.proj = proj;
      wp.valid = true;
    }
  }

  return wp;
}

std::vector<hdmap::LaneID> MapPathGenerator::findLaneSequence(
  hdmap::LaneID from_lane, float /*from_s*/,
  hdmap::LaneID to_lane, float /*to_s*/,
  hdmap::HdMap & map,
  bool * follows_successors) const
{
  auto sequence = findLaneSequenceByTopology(
    from_lane, to_lane,
    [&map](const hdmap::LaneID id) { return map.getSuccessors(id); },
    [&map](const hdmap::LaneID id) { return map.getPredecessors(id); },
    follows_successors);

  if (!sequence.empty()) return sequence;

  hdmap::LaneView from_view = map.getLane(from_lane);
  hdmap::LaneView to_view = map.getLane(to_lane);
  if (!from_view.valid() || !to_view.valid()) return {};

  const auto from_centerline = from_view.centerline();
  const auto to_centerline = to_view.centerline();
  if (from_centerline.empty() || to_centerline.empty()) return {};

  constexpr float kEndpointContinuityThresholdM = 1.0f;
  return findLaneSequenceByEndpointContinuity(
    from_lane,
    from_centerline[0],
    from_centerline[from_centerline.size() - 1],
    to_lane,
    to_centerline[0],
    to_centerline[to_centerline.size() - 1],
    kEndpointContinuityThresholdM,
    follows_successors);
}

std::vector<hdmap::LaneID> MapPathGenerator::findLaneSequenceByTopology(
  hdmap::LaneID from_lane,
  hdmap::LaneID to_lane,
  const LaneNeighborProvider & get_successors,
  const LaneNeighborProvider & get_predecessors,
  bool * follows_successors)
{
  if (from_lane == to_lane) {
    if (follows_successors) *follows_successors = true;
    return {from_lane};
  }

  // BFS through successor topology
  constexpr uint32_t max_depth = 20;
  std::queue<std::vector<hdmap::LaneID>> queue;
  std::unordered_set<hdmap::LaneID> visited;

  queue.push({from_lane});
  visited.insert(from_lane);

  while (!queue.empty()) {
    auto path = queue.front();
    queue.pop();

    if (path.size() > max_depth) continue;

    hdmap::LaneID current = path.back();
    auto successors = get_successors(current);

    for (hdmap::LaneID succ : successors) {
      if (succ == to_lane) {
        path.push_back(succ);
        if (follows_successors) *follows_successors = true;
        return path;
      }
      if (visited.count(succ) == 0) {
        visited.insert(succ);
        auto new_path = path;
        new_path.push_back(succ);
        queue.push(new_path);
      }
    }
  }

  // Forward BFS failed, try predecessors (reverse route)
  queue = {};
  visited.clear();
  queue.push({from_lane});
  visited.insert(from_lane);

  while (!queue.empty()) {
    auto path = queue.front();
    queue.pop();

    if (path.size() > max_depth) continue;

    hdmap::LaneID current = path.back();
    auto predecessors = get_predecessors(current);

    for (hdmap::LaneID pred : predecessors) {
      if (pred == to_lane) {
        path.push_back(pred);
        // Keep travel order: from_lane -> ... -> to_lane. The false
        // follows_successors flag tells extraction to traverse each lane in
        // s-descending order.
        if (follows_successors) *follows_successors = false;
        return path;
      }
      if (visited.count(pred) == 0) {
        visited.insert(pred);
        auto new_path = path;
        new_path.push_back(pred);
        queue.push(new_path);
      }
    }
  }

  return {};  // No path found
}

std::vector<hdmap::LaneID> MapPathGenerator::findLaneSequenceByEndpointContinuity(
  hdmap::LaneID from_lane,
  const hdmap::Vec3f & from_first,
  const hdmap::Vec3f & from_last,
  hdmap::LaneID to_lane,
  const hdmap::Vec3f & to_first,
  const hdmap::Vec3f & to_last,
  float max_endpoint_distance_m,
  bool * follows_successors)
{
  const auto close_enough =
    [max_dist2 = max_endpoint_distance_m * max_endpoint_distance_m](
      const hdmap::Vec3f & a, const hdmap::Vec3f & b) {
      const float dx = a.x - b.x;
      const float dy = a.y - b.y;
      return dx * dx + dy * dy <= max_dist2;
    };

  if (close_enough(from_last, to_first)) {
    if (follows_successors) *follows_successors = true;
    return {from_lane, to_lane};
  }

  if (close_enough(from_first, to_last)) {
    if (follows_successors) *follows_successors = false;
    return {from_lane, to_lane};
  }

  return {};
}

void MapPathGenerator::resampleAndOrient(
  const std::vector<hdmap::Vec3f> & centerline_slice,
  double path_interval,
  bool fms_matches_lane,
  bool is_reverse,
  double seg_velocity,
  std::vector<autoware_planning_msgs::msg::PathPoint> & out)
{
  out.clear();
  if (centerline_slice.size() < 2) {
    // With 0 or 1 input points there's no direction to orient on.
    return;
  }

  // Step 1: resample the slice at path_interval, walking it in s-ascending order.
  // Always emit the first and last input points so the segment endpoints are honored.
  std::vector<hdmap::Vec3f> resampled;
  resampled.reserve(centerline_slice.size());
  resampled.push_back(centerline_slice.front());
  double accumulated = 0.0;
  for (size_t k = 1; k < centerline_slice.size(); ++k) {
    const auto & a = centerline_slice[k - 1];
    const auto & b = centerline_slice[k];
    accumulated += std::hypot(b.x - a.x, b.y - a.y);
    const bool is_last = (k == centerline_slice.size() - 1);
    if (accumulated >= path_interval || is_last) {
      // Avoid emitting a duplicate when the last input point is < 0.05 m from the
      // previously emitted point.
      const auto & prev = resampled.back();
      if (std::hypot(b.x - prev.x, b.y - prev.y) >= 0.05 || is_last) {
        resampled.push_back(b);
        accumulated = 0.0;
      }
    }
  }

  // Step 2: motion order — reverse if FMS travels against the lane.
  if (!fms_matches_lane) {
    std::reverse(resampled.begin(), resampled.end());
  }

  // Step 3: build PathPoints with motion-direction-derived yaw + reverse flip.
  out.reserve(resampled.size());
  for (const auto & v : resampled) {
    autoware_planning_msgs::msg::PathPoint pt;
    pt.pose.position.x = v.x;
    pt.pose.position.y = v.y;
    pt.pose.position.z = v.z;
    pt.longitudinal_velocity_mps =
      static_cast<float>(is_reverse ? -seg_velocity : seg_velocity);
    pt.lateral_velocity_mps = 0.0f;
    pt.heading_rate_rps = 0.0f;
    pt.is_final = false;
    out.push_back(pt);
  }

  // Step 4: yaws — atan2 of the next-point delta (motion direction), +π if reverse
  // (body-frame vehicle-facing). The last point inherits the previous orientation.
  for (size_t i = 0; i + 1 < out.size(); ++i) {
    const double dx = out[i + 1].pose.position.x - out[i].pose.position.x;
    const double dy = out[i + 1].pose.position.y - out[i].pose.position.y;
    double yaw = std::atan2(dy, dx);
    if (is_reverse) yaw += M_PI;
    while (yaw >  M_PI) yaw -= 2.0 * M_PI;
    while (yaw < -M_PI) yaw += 2.0 * M_PI;
    out[i].pose.orientation = quaternionFromYaw(yaw);
  }
  if (out.size() >= 2) {
    out.back().pose.orientation = out[out.size() - 2].pose.orientation;
  }
}

void MapPathGenerator::extractCenterlineSegment(
  hdmap::LaneID lane_id, float s_lo, float s_hi,
  bool fms_matches_lane, bool is_reverse, double velocity,
  hdmap::HdMap & map,
  std::vector<autoware_planning_msgs::msg::PathPoint> & out_points) const
{
  hdmap::LaneView lane = map.getLane(lane_id);
  if (!lane.valid()) return;

  auto cl = lane.centerline();
  auto cum_s = lane.cumulativeS();
  if (cl.size() == 0 || cum_s.size() == 0) return;

  double seg_velocity = velocity;
  if (params_.use_lane_speed_limits && lane.speedLimit() > 0.1f) {
    seg_velocity = static_cast<double>(lane.speedLimit());
  }

  // Copy the centerline slice covering [s_lo, s_hi] into a std::vector so the
  // orientation/order logic can live in resampleAndOrient (and be unit-tested
  // without an HdMap dependency).
  uint32_t idx_start = 0;
  uint32_t idx_end = cl.size() - 1;
  for (uint32_t k = 0; k < cum_s.size(); ++k) {
    if (cum_s[k] >= s_lo) { idx_start = k; break; }
  }
  for (uint32_t k = cum_s.size(); k > 0; --k) {
    if (cum_s[k - 1] <= s_hi) { idx_end = k - 1; break; }
  }
  if (idx_end < idx_start) return;

  std::vector<hdmap::Vec3f> slice;
  slice.reserve(idx_end - idx_start + 1);
  for (uint32_t k = idx_start; k <= idx_end; ++k) {
    slice.push_back(cl[k]);
  }

  std::vector<autoware_planning_msgs::msg::PathPoint> segment_points;
  resampleAndOrient(
    slice, params_.path_interval, fms_matches_lane, is_reverse, seg_velocity,
    segment_points);

  // Append, skipping a near-duplicate at the seam with the previous segment.
  for (const auto & pt : segment_points) {
    if (!out_points.empty()) {
      const auto & last = out_points.back();
      const double d = std::hypot(
        pt.pose.position.x - last.pose.position.x,
        pt.pose.position.y - last.pose.position.y);
      if (d < 0.05) continue;
    }
    out_points.push_back(pt);
  }
}

void MapPathGenerator::extractBoundarySegment(
  hdmap::LaneID lane_id, float s_lo, float s_hi,
  bool fms_matches_lane, hdmap::HdMap & map,
  std::vector<geometry_msgs::msg::Point> & left_out,
  std::vector<geometry_msgs::msg::Point> & right_out) const
{
  hdmap::LaneView lane = map.getLane(lane_id);
  if (!lane.valid()) return;

  auto lb = lane.leftBoundary();
  auto rb = lane.rightBoundary();
  auto cum_s = lane.cumulativeS();

  if (lb.size() == 0 || rb.size() == 0 || cum_s.size() == 0) return;

  uint32_t idx_start = 0;
  uint32_t idx_end = cum_s.size() - 1;
  for (uint32_t k = 0; k < cum_s.size(); ++k) {
    if (cum_s[k] >= s_lo) { idx_start = k; break; }
  }
  for (uint32_t k = cum_s.size(); k > 0; --k) {
    if (cum_s[k - 1] <= s_hi) { idx_end = k - 1; break; }
  }
  if (idx_end < idx_start) return;

  // Resample boundaries at path_interval in s-ascending order.
  std::vector<geometry_msgs::msg::Point> seg_left, seg_right;
  float next_s = s_lo;
  for (uint32_t k = idx_start; k <= idx_end; ++k) {
    if (cum_s[k] < next_s && k != idx_start && k != idx_end) continue;

    if (k < lb.size()) {
      geometry_msgs::msg::Point lp;
      lp.x = lb[k].x; lp.y = lb[k].y; lp.z = lb[k].z;
      seg_left.push_back(lp);
    }
    if (k < rb.size()) {
      geometry_msgs::msg::Point rp;
      rp.x = rb[k].x; rp.y = rb[k].y; rp.z = rb[k].z;
      seg_right.push_back(rp);
    }
    next_s = cum_s[k] + static_cast<float>(params_.path_interval);
  }

  // When FMS traverses the lane against its natural direction, both bound arrays
  // need to be reversed AND swapped: lane-left is on the right of the motion
  // direction when iterating against the lane.
  if (!fms_matches_lane) {
    std::reverse(seg_left.begin(),  seg_left.end());
    std::reverse(seg_right.begin(), seg_right.end());
    seg_left.swap(seg_right);
  }

  left_out.insert(left_out.end(),   seg_left.begin(),  seg_left.end());
  right_out.insert(right_out.end(), seg_right.begin(), seg_right.end());
}

void MapPathGenerator::interpolateSegment(
  const autoware_planning_msgs::msg::PathPoint & from,
  const autoware_planning_msgs::msg::PathPoint & to,
  bool is_reverse,
  std::vector<autoware_planning_msgs::msg::PathPoint> & out_points) const
{
  double dx = to.pose.position.x - from.pose.position.x;
  double dy = to.pose.position.y - from.pose.position.y;
  double dz = to.pose.position.z - from.pose.position.z;
  double dist = std::hypot(dx, dy);

  if (dist < 0.1) {
    out_points.push_back(from);
    return;
  }

  int num_points = std::max(1, static_cast<int>(dist / params_.path_interval));
  double yaw = std::atan2(dy, dx);  // motion direction
  if (is_reverse) {
    yaw += M_PI;
    while (yaw >  M_PI) yaw -= 2.0 * M_PI;
    while (yaw < -M_PI) yaw += 2.0 * M_PI;
  }

  for (int j = 0; j < num_points; ++j) {
    double ratio = static_cast<double>(j) / num_points;

    autoware_planning_msgs::msg::PathPoint pt;
    pt.pose.position.x = from.pose.position.x + ratio * dx;
    pt.pose.position.y = from.pose.position.y + ratio * dy;
    pt.pose.position.z = from.pose.position.z + ratio * dz;
    pt.pose.orientation = quaternionFromYaw(yaw);
    pt.longitudinal_velocity_mps = from.longitudinal_velocity_mps +
      static_cast<float>(ratio) * (to.longitudinal_velocity_mps - from.longitudinal_velocity_mps);
    pt.lateral_velocity_mps = 0.0f;
    pt.heading_rate_rps = 0.0f;
    pt.is_final = false;

    if (!out_points.empty()) {
      const auto & last = out_points.back();
      double d = std::hypot(
        pt.pose.position.x - last.pose.position.x,
        pt.pose.position.y - last.pose.position.y);
      if (d < 0.05) continue;
    }

    out_points.push_back(pt);
  }
}

geometry_msgs::msg::Quaternion MapPathGenerator::quaternionFromYaw(double yaw)
{
  geometry_msgs::msg::Quaternion q;
  q.w = std::cos(yaw / 2.0);
  q.x = 0.0;
  q.y = 0.0;
  q.z = std::sin(yaw / 2.0);
  return q;
}

}  // namespace igv_path_planner
