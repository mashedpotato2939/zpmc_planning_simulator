// Copyright 2024 ZPMC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "igv_path_planner/fms_path_converter_node.hpp"

#include <std_msgs/msg/u_int8.hpp>

// Include protocol headers so static registration runs
#include "igv_path_planner/protocols/default_protocol.hpp"
#include "igv_path_planner/protocols/legacy_protocol.hpp"

#include "igv_planning_msgs/msg/vehicle_status.hpp"
#include "igv_planning_msgs/msg/trajectory_report.hpp"
#include "igv_planning_msgs/msg/trajectory_point.hpp"
#include "igv_planning_msgs/msg/job_event.hpp"

#include <autoware/motion_utils/trajectory/trajectory.hpp>
#include <autoware/universe_utils/geometry/geometry.hpp>

#include <tf2/utils.h>
#include <nlohmann/json.hpp>

#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <random>

namespace igv_path_planner
{

namespace
{
double distance2D(const geometry_msgs::msg::Point & a, const geometry_msgs::msg::Point & b)
{
  return std::hypot(a.x - b.x, a.y - b.y);
}

// route_bridge stamps the rolling short-route partition as "<base>#p<index>".
// Strip the partition suffix to recover the FMS-issued base route_id for
// job-level identity (arrival tracking, scenario-route publish, uplink reporting).
std::string baseRouteId(const std::string & route_id)
{
  const auto pos = route_id.find('#');
  return (pos == std::string::npos) ? route_id : route_id.substr(0, pos);
}

geometry_msgs::msg::Point interpolatePoint(
  const geometry_msgs::msg::Point & start, const geometry_msgs::msg::Point & end,
  const double ratio)
{
  const double t = std::clamp(ratio, 0.0, 1.0);
  geometry_msgs::msg::Point out;
  out.x = start.x + t * (end.x - start.x);
  out.y = start.y + t * (end.y - start.y);
  out.z = start.z + t * (end.z - start.z);
  return out;
}

autoware_planning_msgs::msg::PathPoint interpolatePathPoint(
  const autoware_planning_msgs::msg::PathPoint & start,
  const autoware_planning_msgs::msg::PathPoint & end,
  const double ratio)
{
  const double t = std::clamp(ratio, 0.0, 1.0);

  auto out = start;
  out.pose.position.x = start.pose.position.x +
    t * (end.pose.position.x - start.pose.position.x);
  out.pose.position.y = start.pose.position.y +
    t * (end.pose.position.y - start.pose.position.y);
  out.pose.position.z = start.pose.position.z +
    t * (end.pose.position.z - start.pose.position.z);

  const double yaw0 = tf2::getYaw(start.pose.orientation);
  const double yaw1 = tf2::getYaw(end.pose.orientation);
  double yaw_diff = yaw1 - yaw0;
  while (yaw_diff > M_PI) yaw_diff -= 2.0 * M_PI;
  while (yaw_diff < -M_PI) yaw_diff += 2.0 * M_PI;
  const double yaw = yaw0 + t * yaw_diff;
  out.pose.orientation = geometry_msgs::msg::Quaternion{};
  out.pose.orientation.w = std::cos(yaw / 2.0);
  out.pose.orientation.z = std::sin(yaw / 2.0);

  out.longitudinal_velocity_mps = static_cast<float>(
    start.longitudinal_velocity_mps +
    t * (end.longitudinal_velocity_mps - start.longitudinal_velocity_mps));
  out.lateral_velocity_mps = static_cast<float>(
    start.lateral_velocity_mps +
    t * (end.lateral_velocity_mps - start.lateral_velocity_mps));
  out.heading_rate_rps = static_cast<float>(
    start.heading_rate_rps + t * (end.heading_rate_rps - start.heading_rate_rps));
  out.is_final = false;
  return out;
}
}  // namespace

void shiftResolvedRangesAfterReplacement(
  std::vector<std::pair<size_t, size_t>> & ranges,
  const size_t replaced_end_idx,
  const std::ptrdiff_t delta)
{
  if (delta == 0) {
    return;
  }

  const auto shift_index = [delta](const size_t idx) {
    if (delta < 0) {
      const auto magnitude = static_cast<size_t>(-delta);
      return idx > magnitude ? idx - magnitude : static_cast<size_t>(0);
    }
    return idx + static_cast<size_t>(delta);
  };

  for (auto & range : ranges) {
    if (range.first <= replaced_end_idx) {
      continue;
    }
    range.first = shift_index(range.first);
    range.second = shift_index(range.second);
  }
}

bool truncatePathFromEgoPose(
  autoware_planning_msgs::msg::Path & path,
  const geometry_msgs::msg::Pose & ego_pose,
  const double nearest_dist_threshold,
  const double nearest_yaw_threshold,
  const double back_buffer_length,
  const double min_projection_distance)
{
  if (path.points.size() < 2) return false;

  size_t ego_seg_idx = autoware::motion_utils::findFirstNearestSegmentIndexWithSoftConstraints(
    path.points, ego_pose, nearest_dist_threshold, nearest_yaw_threshold);
  ego_seg_idx = std::min(ego_seg_idx, path.points.size() - 2);

  const auto & seg_start = path.points[ego_seg_idx];
  const auto & seg_end = path.points[ego_seg_idx + 1];
  const auto & p0 = seg_start.pose.position;
  const auto & p1 = seg_end.pose.position;
  const double dx = p1.x - p0.x;
  const double dy = p1.y - p0.y;
  const double dz = p1.z - p0.z;
  const double seg_len_sq = dx * dx + dy * dy + dz * dz;
  const bool have_bounds =
    path.left_bound.size() == path.points.size() &&
    path.right_bound.size() == path.points.size();

  if (seg_len_sq < 1e-6) {
    if (ego_seg_idx == 0) return false;
    path.points.erase(path.points.begin(), path.points.begin() + ego_seg_idx);
    if (have_bounds) {
      path.left_bound.erase(path.left_bound.begin(), path.left_bound.begin() + ego_seg_idx);
      path.right_bound.erase(path.right_bound.begin(), path.right_bound.begin() + ego_seg_idx);
    } else {
      path.left_bound.clear();
      path.right_bound.clear();
    }
    return true;
  }

  const auto & ego = ego_pose.position;
  const double raw_ratio =
    ((ego.x - p0.x) * dx + (ego.y - p0.y) * dy + (ego.z - p0.z) * dz) / seg_len_sq;
  const double ratio = std::clamp(raw_ratio, 0.0, 1.0);
  const double back_buffer = std::max(0.0, back_buffer_length);
  const double ego_segment_len = distance2D(p0, p1);

  size_t start_seg_idx = ego_seg_idx;
  double start_ratio = ratio;
  if (back_buffer > 0.0 && ego_segment_len > 1e-6) {
    double remaining_back = back_buffer;
    const double dist_from_seg_start_to_ego = ratio * ego_segment_len;

    if (remaining_back <= dist_from_seg_start_to_ego || ego_seg_idx == 0) {
      start_ratio = std::clamp(
        (dist_from_seg_start_to_ego - remaining_back) / ego_segment_len, 0.0, 1.0);
    } else {
      remaining_back -= dist_from_seg_start_to_ego;
      bool found_start = false;
      size_t candidate_seg = ego_seg_idx;
      while (candidate_seg > 0) {
        const auto & prev = path.points[candidate_seg - 1].pose.position;
        const auto & curr = path.points[candidate_seg].pose.position;
        const double seg_len = distance2D(prev, curr);
        --candidate_seg;
        if (seg_len < 1e-6) continue;

        if (remaining_back <= seg_len) {
          start_seg_idx = candidate_seg;
          start_ratio = std::clamp((seg_len - remaining_back) / seg_len, 0.0, 1.0);
          found_start = true;
          break;
        }
        remaining_back -= seg_len;
      }

      if (!found_start) {
        start_seg_idx = 0;
        start_ratio = 0.0;
      }
    }
  }

  const auto start_point =
    interpolatePathPoint(path.points[start_seg_idx], path.points[start_seg_idx + 1], start_ratio);

  const double min_dist = std::max(0.0, min_projection_distance);
  const auto & start_seg_start = path.points[start_seg_idx].pose.position;
  const auto & start_seg_end = path.points[start_seg_idx + 1].pose.position;
  const double dist_to_start = distance2D(start_point.pose.position, start_seg_start);
  const double dist_to_end = distance2D(start_point.pose.position, start_seg_end);

  std::vector<autoware_planning_msgs::msg::PathPoint> truncated;
  std::vector<geometry_msgs::msg::Point> truncated_left;
  std::vector<geometry_msgs::msg::Point> truncated_right;
  truncated.reserve(path.points.size() - start_seg_idx + 1);
  if (have_bounds) {
    truncated_left.reserve(path.left_bound.size() - start_seg_idx + 1);
    truncated_right.reserve(path.right_bound.size() - start_seg_idx + 1);
  }

  if (dist_to_start <= min_dist) {
    truncated.insert(truncated.end(), path.points.begin() + start_seg_idx, path.points.end());
    if (have_bounds) {
      truncated_left.insert(
        truncated_left.end(), path.left_bound.begin() + start_seg_idx, path.left_bound.end());
      truncated_right.insert(
        truncated_right.end(), path.right_bound.begin() + start_seg_idx, path.right_bound.end());
    }
  } else if (dist_to_end <= min_dist) {
    truncated.insert(truncated.end(), path.points.begin() + start_seg_idx + 1, path.points.end());
    if (have_bounds) {
      truncated_left.insert(
        truncated_left.end(), path.left_bound.begin() + start_seg_idx + 1, path.left_bound.end());
      truncated_right.insert(
        truncated_right.end(), path.right_bound.begin() + start_seg_idx + 1, path.right_bound.end());
    }
  } else {
    truncated.push_back(start_point);
    truncated.insert(truncated.end(), path.points.begin() + start_seg_idx + 1, path.points.end());
    if (have_bounds) {
      truncated_left.push_back(
        interpolatePoint(
          path.left_bound[start_seg_idx], path.left_bound[start_seg_idx + 1], start_ratio));
      truncated_left.insert(
        truncated_left.end(), path.left_bound.begin() + start_seg_idx + 1, path.left_bound.end());
      truncated_right.push_back(
        interpolatePoint(
          path.right_bound[start_seg_idx], path.right_bound[start_seg_idx + 1], start_ratio));
      truncated_right.insert(
        truncated_right.end(), path.right_bound.begin() + start_seg_idx + 1, path.right_bound.end());
    }
  }

  if (truncated.empty()) {
    truncated.push_back(path.points.back());
    if (have_bounds) {
      truncated_left.push_back(path.left_bound.back());
      truncated_right.push_back(path.right_bound.back());
    }
  }

  const bool changed =
    truncated.size() != path.points.size() ||
    distance2D(truncated.front().pose.position, path.points.front().pose.position) > 1e-6;
  path.points = std::move(truncated);
  if (have_bounds) {
    path.left_bound = std::move(truncated_left);
    path.right_bound = std::move(truncated_right);
  } else {
    path.left_bound.clear();
    path.right_bound.clear();
  }
  return changed;
}

FMSPathConverterNode::FMSPathConverterNode(const rclcpp::NodeOptions & options)
: Node("fms_path_converter", options),
  tf_buffer_(this->get_clock()),
  tf_listener_(tf_buffer_),
  fms_connected_(false),
  has_original_goal_(false)
{
  // Declare parameters
  frame_id_ = declare_parameter<std::string>("frame_id", "map");
  default_velocity_ = declare_parameter<double>("default_velocity", 5.0);  // m/s
  min_velocity_ = declare_parameter<double>("min_velocity", 0.5);          // m/s
  max_velocity_ = declare_parameter<double>("max_velocity", 15.0);         // m/s
  path_interval_ = declare_parameter<double>("path_interval", 1.0);        // meters
  forward_path_length_ = declare_parameter<double>("forward_path_length", 100.0);
  backward_path_length_ = declare_parameter<double>("backward_path_length", 5.0);
  stale_threshold_ = declare_parameter<double>("stale_threshold", 5.0);    // seconds
  ego_nearest_dist_threshold_ = declare_parameter<double>("ego_nearest_dist_threshold", 3.0);  // meters
  ego_nearest_yaw_threshold_ = declare_parameter<double>("ego_nearest_yaw_threshold", 1.57);   // radians (~90 deg)
  // Ego-off-route re-anchor trigger only — horizon rolling is driven by route_id
  // re-partition (route_bridge bumps route_id every repartition_step_m meters),
  // not by this gate. See onRouteWindow().
  replan_lateral_deviation_threshold_ =
    declare_parameter<double>("replan_lateral_deviation_threshold", 1.0);  // meters
  enable_path_smoothing_ = declare_parameter<bool>("enable_path_smoothing", true);
  enable_velocity_profile_ = declare_parameter<bool>("enable_velocity_profile", true);
  enable_goal_tail_ = declare_parameter<bool>("enable_goal_tail", true);
  goal_tail_length_ = declare_parameter<double>("goal_tail_length", 3.0);  // m past destination
  goal_tail_step_ = declare_parameter<double>("goal_tail_step", 0.5);      // m between tail points
  use_json_input_ = declare_parameter<bool>("use_json_input", false);
  publish_rate_ = declare_parameter<double>("publish_rate", 10.0);         // Hz

  // Intelligent path generation parameters (for sparse FMS waypoints)
  enable_intelligent_path_generation_ = declare_parameter<bool>(
    "enable_intelligent_path_generation", true);
  lane_change_lateral_threshold_ = declare_parameter<double>(
    "lane_change_lateral_threshold", 1.5);  // meters
  turn_yaw_threshold_ = declare_parameter<double>(
    "turn_yaw_threshold", 0.3);  // radians (~17 deg)
  min_lane_change_length_ = declare_parameter<double>(
    "min_lane_change_length", 10.0);  // meters
  lane_change_velocity_ratio_ = declare_parameter<double>(
    "lane_change_velocity_ratio", 0.8);
  turn_speed_ = declare_parameter<double>("turn_speed", 3.0);  // m/s
  qturn_speed_limit_ = declare_parameter<double>("qturn_speed_limit", 3.0);  // m/s
  oblique_speed_limit_ = declare_parameter<double>("oblique_speed_limit", 3.0);  // m/s

  // Initialize path generator
  PathGenerator::Parameters gen_params;
  gen_params.lane_change_lateral_threshold = lane_change_lateral_threshold_;
  gen_params.turn_yaw_threshold = turn_yaw_threshold_;
  gen_params.path_interval = path_interval_;
  gen_params.min_lane_change_length = min_lane_change_length_;
  gen_params.lane_change_velocity_ratio = lane_change_velocity_ratio_;
  gen_params.turn_speed = turn_speed_;
  gen_params.qturn_speed_limit = qturn_speed_limit_;
  gen_params.oblique_speed_limit = oblique_speed_limit_;
  gen_params.default_velocity = default_velocity_;
  gen_params.debug = declare_parameter<bool>("path_generator_debug", false);
  // Q_TURN clothoid radii — must be read from params so vehicle_info.param.yaml
  // can override per vehicle model (scale_igv needs much smaller R than IGV).
  gen_params.qturn_min_radius =
    declare_parameter<double>("qturn_min_radius", gen_params.qturn_min_radius);
  gen_params.qturn_yaw_min_radius =
    declare_parameter<double>("qturn_yaw_min_radius", gen_params.qturn_yaw_min_radius);
  // 4WS parameters for path generator (will be set after enable_4ws is declared)
  path_generator_ = std::make_unique<PathGenerator>(gen_params);

  // Drivable area parameters - generates synthetic left/right bounds for downstream planning
  generate_drivable_area_ = declare_parameter<bool>("generate_drivable_area", true);
  lane_width_ = declare_parameter<double>("lane_width", 3.5);  // meters (typical lane)
  left_bound_offset_ = declare_parameter<double>("left_bound_offset", -1.0);  // negative = use lane_width/2
  right_bound_offset_ = declare_parameter<double>("right_bound_offset", -1.0);  // negative = use lane_width/2

  // If offsets not specified, use symmetric lane width
  if (left_bound_offset_ < 0) {
    left_bound_offset_ = lane_width_ / 2.0;
  }
  if (right_bound_offset_ < 0) {
    right_bound_offset_ = lane_width_ / 2.0;
  }

  RCLCPP_INFO(get_logger(), "Drivable area generation: %s, lane_width: %.2f m",
    generate_drivable_area_ ? "enabled" : "disabled", lane_width_);

  // Curvature-based drivable area expansion parameters (for large vehicles like IGV)
  enable_curvature_expansion_ = declare_parameter<bool>("enable_curvature_expansion", true);
  vehicle_length_ = declare_parameter<double>("vehicle_length", 15.0);       // IGV total length
  vehicle_width_ = declare_parameter<double>("vehicle_width", 3.0);          // IGV width
  vehicle_front_overhang_ = declare_parameter<double>("vehicle_front_overhang", 4.5);
  vehicle_wheel_base_ = declare_parameter<double>("vehicle_wheel_base", 6.0);
  min_bound_margin_ = declare_parameter<double>("min_bound_margin", 0.5);

  if (enable_curvature_expansion_) {
    RCLCPP_INFO(get_logger(), "Curvature-based drivable area expansion: enabled");
    RCLCPP_INFO(get_logger(), "  Vehicle: length=%.1fm, width=%.1fm, wheelbase=%.1fm, front_overhang=%.1fm",
      vehicle_length_, vehicle_width_, vehicle_wheel_base_, vehicle_front_overhang_);
  }

  // 4WS parameters - enables path to signal 4WS steering via lateral_velocity
  enable_4ws_ = declare_parameter<bool>("enable_4ws", true);
  max_lateral_velocity_ = declare_parameter<double>("max_lateral_velocity", 2.0);  // m/s (allows ~34° sideslip at 3m/s)
  curvature_threshold_ = declare_parameter<double>("curvature_4ws_threshold", 0.01);   // 1/m, ignore below this
  lateral_velocity_gain_ = declare_parameter<double>("lateral_velocity_gain", 5.0);  // Gain for lat_vel calculation

  // Update path generator with 4WS parameters
  if (path_generator_) {
    PathGenerator::Parameters updated_params;
    updated_params.lane_change_lateral_threshold = lane_change_lateral_threshold_;
    updated_params.turn_yaw_threshold = turn_yaw_threshold_;
    updated_params.path_interval = path_interval_;
    updated_params.min_lane_change_length = min_lane_change_length_;
    updated_params.lane_change_velocity_ratio = lane_change_velocity_ratio_;
    updated_params.turn_speed = turn_speed_;
    updated_params.qturn_speed_limit = qturn_speed_limit_;
    updated_params.oblique_speed_limit = oblique_speed_limit_;
    updated_params.default_velocity = default_velocity_;
    updated_params.debug = get_parameter("path_generator_debug").as_bool();
    // Carry Q_TURN radii (declared above) through the rebuild — otherwise the
    // struct defaults (15.5 / 8.1) overwrite the vehicle_info-driven values.
    updated_params.qturn_min_radius = get_parameter("qturn_min_radius").as_double();
    updated_params.qturn_yaw_min_radius = get_parameter("qturn_yaw_min_radius").as_double();
    // 4WS parameters
    updated_params.enable_4ws = enable_4ws_;
    updated_params.vehicle_wheel_base = vehicle_wheel_base_;
    updated_params.vehicle_length = vehicle_length_;
    updated_params.vehicle_front_overhang = vehicle_front_overhang_;
    updated_params.max_lateral_velocity = max_lateral_velocity_;
    updated_params.curvature_4ws_threshold = curvature_threshold_;
    updated_params.lateral_velocity_gain = lateral_velocity_gain_;
    // Oblique (crab-walking) lane change parameters
    updated_params.oblique_max_lateral_distance = declare_parameter<double>(
      "oblique_max_lateral_distance", 8.0);
    updated_params.crab_dymax = declare_parameter<double>(
      "crab_dymax", 30.0 * M_PI / 180.0);
    updated_params.crab_ddymax = declare_parameter<double>(
      "crab_ddymax", 30.0 * M_PI / 180.0);
    updated_params.crab_ddymin = declare_parameter<double>(
      "crab_ddymin", 0.0);
    updated_params.rear_steer_ratio = declare_parameter<double>(
      "rear_steer_ratio", 0.5);
    path_generator_ = std::make_unique<PathGenerator>(updated_params);
  }

  if (enable_4ws_) {
    RCLCPP_INFO(get_logger(), "4WS support enabled: max_lat_vel=%.2fm/s, gain=%.1f, curvature_threshold=%.3f",
      max_lateral_velocity_, lateral_velocity_gain_, curvature_threshold_);
  }

  // HD Map snapping parameters
  map_snap_distance_threshold_ = declare_parameter<double>("map_snap_distance_threshold", 5.0);
  bool use_lane_speed_limits = declare_parameter<bool>("use_lane_speed_limits", false);

  // Initialize ZPMC Map Client (subscribes to /map/zpmc_map_info)
  map_client_ = std::make_unique<zpmc_map_loader::ZpmcMapClient>(
    *this,
    [this, use_lane_speed_limits](hdmap::HdMap & map) {
      MapPathGenerator::Parameters map_gen_params;
      map_gen_params.snap_distance_threshold = map_snap_distance_threshold_;
      map_gen_params.path_interval = path_interval_;
      map_gen_params.use_lane_speed_limits = use_lane_speed_limits;
      map_gen_params.default_velocity = default_velocity_;
      map_path_generator_ = std::make_unique<MapPathGenerator>(map_gen_params);
      RCLCPP_INFO(get_logger(), "HD Map loaded — map-snapped path generation enabled");
      (void)map;
    });

  // Initialize A* local planner (for POINT_LOCAL_PLAN zones)
  initAstarPlanner();

  // Protocol and vehicle identification parameters
  vehicle_id_ = declare_parameter<std::string>("vehicle_id", "v001");
  arrival_threshold_ = declare_parameter<double>("arrival_threshold", 3.0);

  // --- Initialize FMS Protocol Plugin ---
  auto protocol_type = declare_parameter<std::string>("fms_protocol.type", "default");

  ProtocolCallbacks callbacks;
  callbacks.on_route_window = [this](const igv_planning_msgs::msg::FMSRouteWindow::SharedPtr m) {
    onRouteWindow(m);
  };
  callbacks.on_stop_point = [this](const igv_planning_msgs::msg::FMSStopPoint::SharedPtr m) {
    onStopPoint(m);
  };

  protocol_ = FMSProtocolFactory::instance().create(protocol_type);
  if (!protocol_) {
    RCLCPP_ERROR(get_logger(), "Unknown FMS protocol type '%s'. Available protocols:",
      protocol_type.c_str());
    for (const auto & name : FMSProtocolFactory::instance().availableProtocols()) {
      RCLCPP_ERROR(get_logger(), "  - %s", name.c_str());
    }
    throw std::runtime_error("Unknown FMS protocol type: " + protocol_type);
  }
  protocol_->initialize(*this, callbacks);
  RCLCPP_INFO(get_logger(), "FMS protocol: '%s'", protocol_->name().c_str());

  // Odometry subscriber (shared by all protocols)
  odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
    "~/input/odometry", rclcpp::SensorDataQoS(),
    std::bind(&FMSPathConverterNode::odometryCallback, this, std::placeholders::_1));

  // Create publishers
  path_pub_ = create_publisher<autoware_planning_msgs::msg::Path>(
    "~/output/path", rclcpp::QoS(10));

  // Route publisher with TRANSIENT_LOCAL durability (required by scenario selector)
  rclcpp::QoS route_qos(1);
  route_qos.reliable();
  route_qos.transient_local();
  route_pub_ = create_publisher<autoware_planning_msgs::msg::LaneletRoute>(
    "~/output/route", route_qos);

  status_pub_ = create_publisher<igv_planning_msgs::msg::FMSStatus>(
    "~/output/status", rclcpp::QoS(10));
  adapter_status_pub_ = create_publisher<igv_planning_msgs::msg::AdapterStatus>(
    "~/output/adapter_status", rclcpp::QoS(10));

  // Maneuver type publisher — velocity smoother uses this to preserve lateral_velocity_mps
  // 0=STRAIGHT, 2=OBLIQUE_LANE_CHANGE (matches autoware_velocity_smoother convention)
  maneuver_type_pub_ = create_publisher<std_msgs::msg::UInt8>(
    "/fms/maneuver_type", rclcpp::QoS(10).transient_local());

  // Projected-waypoint visualization (authoritative per-input-waypoint snap result).
  // Transient-local so late-joining RViz picks up the current markers.
  projected_waypoints_marker_pub_ = create_publisher<visualization_msgs::msg::MarkerArray>(
    "~/output/projected_waypoint_markers", rclcpp::QoS(1).transient_local().reliable());

  // Reverse driving support - publisher and service server
  reverse_state_pub_ = create_publisher<reverse_vehicle_msg::msg::VehicleReversed>(
    "/planning/reverse_state", rclcpp::QoS(10).transient_local());
  reverse_state_service_ = create_service<reverse_vehicle_msg::srv::SetVehicleReverseState>(
    "/set_reverse_vehicle_state_service",
    std::bind(
      &FMSPathConverterNode::handleReverseStateService, this, std::placeholders::_1,
      std::placeholders::_2));
  current_reverse_state_ = false;
  last_reverse_state_ = false;
  publishReverseState();

  // Create timer for periodic publishing
  const auto period = std::chrono::duration<double>(1.0 / publish_rate_);
  timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(period),
    std::bind(&FMSPathConverterNode::timerCallback, this));

  last_fms_message_time_ = this->now();

  RCLCPP_INFO(get_logger(), "FMS Path Converter Node initialized");
  RCLCPP_INFO(get_logger(), "  Protocol: %s", protocol_->name().c_str());
  RCLCPP_INFO(get_logger(), "  Vehicle ID: %s", vehicle_id_.c_str());
  RCLCPP_INFO(get_logger(), "  Default velocity: %.2f m/s", default_velocity_);
  RCLCPP_INFO(get_logger(), "  Path interval: %.2f m", path_interval_);
  RCLCPP_INFO(get_logger(), "  Intelligent path generation: %s",
    enable_intelligent_path_generation_ ? "enabled" : "disabled");
}

// ============================================================================
// Protocol plugin callbacks (unified entry points)
// ============================================================================

void FMSPathConverterNode::onRouteWindow(const igv_planning_msgs::msg::FMSRouteWindow::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(mutex_);

  last_window_ = msg;
  last_fms_message_time_ = this->now();
  fms_connected_ = true;

  // Track job identification from route window
  if (!msg->vehicle_id.empty()) vehicle_id_ = msg->vehicle_id;
  current_job_id_ = msg->job_id;
  current_job_task_id_ = msg->job_task_id;
  current_route_id_ = msg->route_id;

  // Reset arrival tracking when the BASE route changes (a route_id partition bump
  // on the same base route is not a new job and must not reset arrival).
  const std::string base_route_id = baseRouteId(msg->route_id);
  if (base_route_id != last_published_base_route_id_) {
    arrival_reported_ = false;
  }

  // Once the vehicle has arrived at the destination for this base route, stay
  // idle: do not rebuild or republish the path on subsequent route windows
  // carrying the same base route. checkArrivalAndReport() has already reset
  // the cached paths, and the timerCallback guard keeps path_pub_ silent.
  // A new base route will clear arrival_reported_ above and resume normal flow.
  if (arrival_reported_ && base_route_id == last_published_base_route_id_) {
    return;
  }

  RCLCPP_DEBUG(get_logger(), "Received FMSRouteWindow: %zu segments, route=%s, status=%d",
    msg->segments.size(), msg->route_id.c_str(), msg->status);

  if (msg->segments.empty()) {
    RCLCPP_WARN(get_logger(), "Route window has no segments");
    return;
  }

  // Deviation-gated replanning: while the ego is tracking the cached reference
  // path within replan_lateral_deviation_threshold_, reuse that reference
  // geometry. The published view is still re-truncated from current ego each
  // cycle so traversed points do not remain at the front of the output path.
  const bool same_route = (msg->route_id == last_published_route_id_);
  const bool have_cached = (last_reference_path_ && !last_reference_path_->points.empty());
  if (same_route && have_cached && current_odom_) {
    const double lat_dev = computeLateralDeviationFromCachedPath();
    if (lat_dev < replan_lateral_deviation_threshold_) {
      RCLCPP_DEBUG(get_logger(),
        "[onRouteWindow] ego on reference path (|lat|=%.2f m < %.2f m); reusing geometry",
        lat_dev, replan_lateral_deviation_threshold_);
      publishPathFromReference();
      return;
    }
  }

  // Note: reverse state update is deferred to after path generation (position-aware).
  // See updateReverseStateFromPath() call below.

  try {
    // Detect oblique LC in the window before path generation (used for maneuver type)
    bool has_oblique_lc = false;
    for (const auto & seg : msg->segments) {
      for (const auto & wp : seg.points) {
        if (wp.point_type == igv_planning_msgs::msg::SegmentWaypoint::POINT_LC_START) {
          has_oblique_lc = true;
          break;
        }
      }
      if (has_oblique_lc) break;
    }

    // Detect Q_TURN (~90° elbow) by walking the route_window waypoints in order
    // and looking at the cumulative heading change. This catches FMS routes that
    // contain a sharp turn without an explicit LOCAL_PLAN marker — observed in
    // bag planning_control_20260527_052142 where a ~90° forward elbow ran with
    // maneuver_type=STRAIGHT, so fms_kinematic_smoother re-derived per-point
    // yaw from the chord and lost the body-yaw signal through the corner.
    bool has_qturn = false;
    {
      const double qturn_min = path_generator_
        ? path_generator_->getParameters().qturn_yaw_min_threshold
        : 1.3;  // ~75°
      double acc_yaw = 0.0;
      double prev_heading = 0.0;
      bool have_prev = false;
      for (const auto & seg : msg->segments) {
        for (const auto & wp : seg.points) {
          if (!have_prev) {
            prev_heading = wp.heading;
            have_prev = true;
            continue;
          }
          double dh = wp.heading - prev_heading;
          while (dh > M_PI) dh -= 2.0 * M_PI;
          while (dh < -M_PI) dh += 2.0 * M_PI;
          acc_yaw += std::abs(dh);
          prev_heading = wp.heading;
          if (acc_yaw >= qturn_min) {
            has_qturn = true;
            break;
          }
        }
        if (has_qturn) break;
      }
    }

    // Publish maneuver type BEFORE path generation so velocity smoother is ready.
    // 0=STRAIGHT, 2=OBLIQUE_LANE_CHANGE, 6=Q_TURN (matches the
    // fms_kinematic_smoother body-yaw re-injection switch).
    {
      constexpr uint8_t MANEUVER_STRAIGHT = 0;
      constexpr uint8_t MANEUVER_OBLIQUE  = 2;
      constexpr uint8_t MANEUVER_Q_TURN   = 6;
      std_msgs::msg::UInt8 maneuver_msg;
      // OBLIQUE marker takes precedence — an LC_START point is a stronger
      // explicit signal than a heuristic yaw-change accumulator.
      if (has_oblique_lc) {
        maneuver_msg.data = MANEUVER_OBLIQUE;
      } else if (has_qturn) {
        maneuver_msg.data = MANEUVER_Q_TURN;
      } else {
        maneuver_msg.data = MANEUVER_STRAIGHT;
      }
      maneuver_type_pub_->publish(maneuver_msg);
    }

    auto autoware_path = convertRouteWindowToAutowarePath(*msg);

    if (current_odom_) {
      connectEgoToPath(autoware_path);
    }

    if (enable_velocity_profile_) {
      addVelocityProfileForWindow(autoware_path);
    }

    if (enable_path_smoothing_) {
      smoothPath(autoware_path);
    }

    last_reference_path_ = std::make_shared<autoware_planning_msgs::msg::Path>(autoware_path);
    publishPathFromReference();

    // Advance the full route_id every rebuild (incl. partition bumps) so the
    // same_route rebuild trigger fires on the next partition. Publish the route to
    // the scenario selector only when the BASE route changes — not on every 50 m
    // partition bump within the same job.
    last_published_route_id_ = msg->route_id;
    if (base_route_id != last_published_base_route_id_) {
      publishRouteFromWindow(*msg);
      last_published_base_route_id_ = base_route_id;
      RCLCPP_INFO(get_logger(), "Published route for window: %s", base_route_id.c_str());
    }

    last_error_.clear();

  } catch (const std::exception & e) {
    last_error_ = e.what();
    RCLCPP_ERROR(get_logger(), "Failed to convert route window: %s", e.what());
  }
}

void FMSPathConverterNode::onStopPoint(const igv_planning_msgs::msg::FMSStopPoint::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(mutex_);

  if (msg->clear) {
    RCLCPP_INFO(get_logger(), "Stop point cleared");
    active_stop_ = std::nullopt;
  } else {
    RCLCPP_INFO(get_logger(), "Stop point set at (%.2f, %.2f)", msg->x, msg->y);
    active_stop_ = *msg;
  }

  publishPathFromReference();
}

bool FMSPathConverterNode::publishPathFromReference()
{
  if (!last_reference_path_ || last_reference_path_->points.empty()) {
    return false;
  }

  auto path = *last_reference_path_;
  path.header.stamp = this->now();

  if (current_odom_) {
    truncatePathFromEgo(path);
    updateReverseStateFromPath(path);
  }

  if (active_stop_) {
    applyStopPoint(path);
  }

  generateDrivableBounds(path);

  // Must run AFTER generateDrivableBounds so we can mirror the trailing
  // bound vertices to match the appended tail points.
  extendPathBeyondGoal(path);

  last_output_path_ = std::make_shared<autoware_planning_msgs::msg::Path>(path);
  path_pub_->publish(path);
  return true;
}

autoware_planning_msgs::msg::Path FMSPathConverterNode::convertRouteWindowToAutowarePath(
  const igv_planning_msgs::msg::FMSRouteWindow & window)
{
  autoware_planning_msgs::msg::Path autoware_path;
  autoware_path.header.stamp = this->now();
  autoware_path.header.frame_id = frame_id_;

  // Flatten all segments into sparse path points
  std::vector<autoware_planning_msgs::msg::PathPoint> sparse_points;
  std::vector<uint8_t> lane_change_types;
  std::vector<uint8_t> point_types;  // Track SegmentWaypoint::point_type per sparse point

  // Find the last destination point across all segments for goal tracking
  has_original_goal_ = false;

  for (const auto & segment : window.segments) {
    const bool is_reverse = (segment.orientation == igv_planning_msgs::msg::FMSPathSegment::ORIENT_REVERSE);
    bool in_lc_span = false;  // tracks all waypoints from LC_START up to (not incl.) LC_END

    for (size_t i = 0; i < segment.points.size(); ++i) {
      const auto & wp = segment.points[i];

      autoware_planning_msgs::msg::PathPoint point;
      point.pose.position.x = wp.x;
      point.pose.position.y = wp.y;
      point.pose.position.z = wp.z;

      // Heading: for reverse segments, logical heading is travel direction.
      // Vehicle physical heading = logical heading + pi (vehicle faces opposite to travel)
      double physical_heading = wp.heading;
      if (is_reverse) {
        physical_heading = wp.heading + M_PI;
        // Normalize
        while (physical_heading > M_PI) physical_heading -= 2.0 * M_PI;
        while (physical_heading < -M_PI) physical_heading += 2.0 * M_PI;
      }
      point.pose.orientation = createQuaternionFromYaw(physical_heading);

      // Velocity
      double speed = wp.speed_limit;
      if (speed < 0.1) {
        speed = default_velocity_;
      }
      speed = std::clamp(speed, min_velocity_, max_velocity_);
      point.longitudinal_velocity_mps = static_cast<float>(is_reverse ? -speed : speed);

      // Handle destination points (stop)
      if (wp.point_type == igv_planning_msgs::msg::SegmentWaypoint::POINT_DESTINATION) {
        point.longitudinal_velocity_mps = 0.0;
        has_original_goal_ = true;
        original_goal_position_ = point.pose.position;
      }

      point.lateral_velocity_mps = 0.0f;
      point.heading_rate_rps = 0.0f;
      point.is_final = false;

      sparse_points.push_back(point);

      // Mark the full LC span (LC_START through last point before LC_END) as oblique.
      // LC_END itself transitions back to normal — its outgoing segment snaps to target centerline.
      if (wp.point_type == igv_planning_msgs::msg::SegmentWaypoint::POINT_LC_START) {
        in_lc_span = true;
      } else if (wp.point_type == igv_planning_msgs::msg::SegmentWaypoint::POINT_LC_END) {
        in_lc_span = false;
      }
      lane_change_types.push_back(in_lc_span ? 1 : 0);
      point_types.push_back(wp.point_type);
    }
  }

  if (sparse_points.empty()) {
    RCLCPP_WARN(get_logger(), "Route window produced no path points");
    return autoware_path;
  }

  // Mark last point as final
  sparse_points.back().is_final = true;

  // Resolve LOCAL_PLAN zones with A* freespace planner (forward+reverse maneuvers)
  std::vector<std::pair<size_t, size_t>> resolved_ranges;  // ascending, inclusive indices into sparse_points
  if (astar_planner_) {
    resolveLocalPlanZones(sparse_points, lane_change_types, point_types, &resolved_ranges);
  }

  // Step 1: Try map-snapped path generation if HD Map is loaded. Snap the
  // outer slices (between LOCAL_PLAN-resolved ranges) so lane-following stays
  // intact, but pass the resolved ranges through verbatim — that geometry
  // (Q_TURN clothoid / A* freespace) is the explicit maneuver FMS specified
  // and must not be clipped back onto the lane centerline.
  if (map_client_ && map_client_->isMapLoaded() && map_path_generator_ &&
      sparse_points.size() >= 2) {
    bool has_reverse = false;
    for (const auto & seg : window.segments) {
      if (seg.orientation == igv_planning_msgs::msg::FMSPathSegment::ORIENT_REVERSE) {
        has_reverse = true;
        break;
      }
    }

    // generateObliqueLaneChangeSegment reads PathGenerator::is_reverse_ to
    // build its motion-aligned local frame (motion_yaw = start_yaw + π for
    // reverse). Without this, dx_local comes out negative for reverse LC
    // spans and the oblique solver silently falls back to the Bézier
    // lane-change, which emits orientations from the path tangent with no
    // reverse flip — yielding "vehicle facing = travel direction" inside
    // the LC span and breaking constant-heading reverse crab driving.
    // The window-level setReverseState() in updateReverseStateFromPath()
    // fires AFTER path generation, so set it here before snap_slice runs.
    // Mirrors the Q_TURN prologue in resolveLocalPlanZones().
    if (path_generator_) {
      path_generator_->setReverseState(has_reverse);
    }

    std::vector<autoware_planning_msgs::msg::PathPoint> combined;
    std::vector<geometry_msgs::msg::Point> combined_left, combined_right;
    // Only outer-slice points are offered to the snapper, so they're also the
    // only ones that should appear in the projection visualization. Keep a
    // matched raw_points vector so indices align with input_projections.
    std::vector<autoware_planning_msgs::msg::PathPoint> marker_raw_points;
    MapPathGenerator::SnapResult agg_for_markers;
    agg_for_markers.input_projections.reserve(sparse_points.size());
    marker_raw_points.reserve(sparse_points.size());
    bool snap_ok = true;

    auto snap_slice = [&](size_t lo, size_t hi_exclusive) -> bool {
      if (hi_exclusive <= lo) return true;
      if (hi_exclusive - lo < 2) {
        combined.push_back(sparse_points[lo]);
        MapPathGenerator::InputProjection ip;
        ip.x = sparse_points[lo].pose.position.x;
        ip.y = sparse_points[lo].pose.position.y;
        ip.z = sparse_points[lo].pose.position.z;
        ip.valid = false;
        agg_for_markers.input_projections.push_back(ip);
        marker_raw_points.push_back(sparse_points[lo]);
        return true;
      }
      std::vector<autoware_planning_msgs::msg::PathPoint> slice(
        sparse_points.begin() + lo, sparse_points.begin() + hi_exclusive);
      std::vector<uint8_t> slice_lct(
        lane_change_types.begin() + lo, lane_change_types.begin() + hi_exclusive);
      auto sr = map_path_generator_->generateMapSnappedPath(
        slice, slice_lct, map_client_->map(), has_reverse, path_generator_.get());
      agg_for_markers.input_projections.insert(
        agg_for_markers.input_projections.end(),
        sr.input_projections.begin(), sr.input_projections.end());
      marker_raw_points.insert(
        marker_raw_points.end(), slice.begin(), slice.end());
      if (sr.points.empty()) return false;
      combined.insert(combined.end(), sr.points.begin(), sr.points.end());
      combined_left.insert(combined_left.end(),
        sr.left_bound.begin(), sr.left_bound.end());
      combined_right.insert(combined_right.end(),
        sr.right_bound.begin(), sr.right_bound.end());
      return true;
    };

    size_t cursor = 0;
    for (const auto & rng : resolved_ranges) {
      if (rng.first > rng.second || rng.first >= sparse_points.size() ||
          rng.second >= sparse_points.size())
      {
        RCLCPP_WARN(get_logger(),
          "Skipping invalid LOCAL_PLAN resolved range [%zu,%zu] for %zu sparse points",
          rng.first, rng.second, sparse_points.size());
        continue;
      }
      if (rng.first < cursor) {
        RCLCPP_WARN(get_logger(),
          "Skipping overlapping LOCAL_PLAN resolved range [%zu,%zu] (cursor=%zu)",
          rng.first, rng.second, cursor);
        continue;
      }
      if (rng.first > cursor) {
        if (!snap_slice(cursor, rng.first)) { snap_ok = false; break; }
      }
      // Inner (LOCAL_PLAN-resolved) range passes through verbatim. These
      // points weren't offered to the snapper, so they aren't added to
      // marker_raw_points — no "REJECTED" labels on resolved geometry.
      combined.insert(combined.end(),
        sparse_points.begin() + rng.first,
        sparse_points.begin() + rng.second + 1);
      cursor = rng.second + 1;
    }
    if (snap_ok && cursor < sparse_points.size()) {
      if (!snap_slice(cursor, sparse_points.size())) snap_ok = false;
    }

    if (snap_ok && !combined.empty()) {
      publishProjectedWaypointMarkers(marker_raw_points, agg_for_markers);
      autoware_path.points = std::move(combined);
      if (!combined_left.empty()) {
        autoware_path.left_bound  = std::move(combined_left);
        autoware_path.right_bound = std::move(combined_right);
      }
      autoware_path.points.back().is_final = true;
      RCLCPP_DEBUG(get_logger(),
        "Map-snapped path: %zu points, %zu LOCAL_PLAN range(s) preserved",
        autoware_path.points.size(), resolved_ranges.size());
      return autoware_path;
    }
    RCLCPP_DEBUG(get_logger(), "Map snapping (sliced) failed, falling back to geometric generation");
  }

  // Step 2: Geometric path generation (existing behavior)
  if (enable_intelligent_path_generation_ && path_generator_ && sparse_points.size() >= 2) {
    autoware_path.points = path_generator_->generatePath(sparse_points, lane_change_types);
  } else {
    autoware_path.points = sparse_points;
    interpolatePath(autoware_path);

    if (enable_4ws_ && path_generator_) {
      path_generator_->apply4WSLateralVelocity(autoware_path.points);
    }
  }

  return autoware_path;
}

void FMSPathConverterNode::connectEgoToPath(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.empty() || !current_odom_) {
    return;
  }

  const auto & ego_pos = current_odom_->pose.pose.position;
  const auto & first_pt = path.points.front().pose.position;
  const double dist_to_first = std::hypot(ego_pos.x - first_pt.x, ego_pos.y - first_pt.y);

  // If ego is far from path start, insert a connection point
  if (dist_to_first > 2.0) {
    autoware_planning_msgs::msg::PathPoint ego_point = path.points.front();
    ego_point.pose.position = ego_pos;

    // Direction from ego toward the first path point (travel direction).
    const double travel_dir = std::atan2(first_pt.y - ego_pos.y, first_pt.x - ego_pos.x);

    // Connector orientation = body yaw, which faces opposite travel in reverse.
    double heading = travel_dir;
    if (path.points.front().longitudinal_velocity_mps < 0) {
      heading += M_PI;
      while (heading > M_PI) heading -= 2.0 * M_PI;
    }

    // Guard: reject the connector when it points in a wildly inconsistent
    // direction from the existing path. Observed failure (bag
    // planning_control_20260527_052142): ego had drifted ~1.9 m off a Q-turn
    // mid-corner; the next non-cropped path point happened to be ~3 m NORTH of
    // ego while the path itself was heading SOUTH-WEST. The connector came out
    // ≈135° off the path tangent, and once that landed in the trajectory the
    // controller's eyaw inverted to ±180° and the operator had to disengage.
    // Compare travel_dir (ego→first_pt, NOT the body-yaw `heading`) against the
    // path tangent — both in the travel-direction sense — so reverse driving,
    // where body yaw is intentionally ~180° from travel, is not falsely
    // rejected.
    if (path.points.size() >= 2) {
      const auto & second_pt = path.points[1].pose.position;
      const double path_tangent =
        std::atan2(second_pt.y - first_pt.y, second_pt.x - first_pt.x);
      double tan_diff = travel_dir - path_tangent;
      while (tan_diff > M_PI) tan_diff -= 2.0 * M_PI;
      while (tan_diff < -M_PI) tan_diff += 2.0 * M_PI;
      constexpr double kMaxConnectorTangentDeviation = M_PI / 4.0;  // 45 deg
      if (std::abs(tan_diff) > kMaxConnectorTangentDeviation) {
        RCLCPP_WARN_THROTTLE(
          get_logger(), *get_clock(), 1000,
          "[connectEgoToPath] Skipping connector: travel_dir=%.1f° vs path tangent=%.1f° "
          "(|diff|=%.1f° > 45°). Ego is %.2f m from path start — likely off-path; "
          "waiting for replan rather than inserting a misaligned segment.",
          travel_dir * 180.0 / M_PI, path_tangent * 180.0 / M_PI,
          std::abs(tan_diff) * 180.0 / M_PI, dist_to_first);
        return;
      }
    }

    ego_point.pose.orientation = createQuaternionFromYaw(heading);

    // Don't copy zero velocity from a destination/goal point — the ego connection
    // segment needs a driving velocity so the vehicle can reach the goal.
    if (std::abs(ego_point.longitudinal_velocity_mps) < 0.1) {
      // Find the first non-zero velocity in the path, or use default
      float drive_vel = static_cast<float>(default_velocity_);
      for (const auto & pt : path.points) {
        if (std::abs(pt.longitudinal_velocity_mps) > 0.1) {
          drive_vel = pt.longitudinal_velocity_mps;
          break;
        }
      }
      ego_point.longitudinal_velocity_mps = drive_vel;
    }

    path.points.insert(path.points.begin(), ego_point);
  }
}

void FMSPathConverterNode::recomputeHeadingFromGeometry(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2) return;

  bool is_reverse = (path.points.front().longitudinal_velocity_mps < -0.01);

  for (size_t i = 0; i + 1 < path.points.size(); ++i) {
    const double dx = path.points[i + 1].pose.position.x - path.points[i].pose.position.x;
    const double dy = path.points[i + 1].pose.position.y - path.points[i].pose.position.y;

    if (std::hypot(dx, dy) < 0.01) continue;

    double yaw = std::atan2(dy, dx);
    if (is_reverse) {
      yaw += M_PI;
      while (yaw > M_PI) yaw -= 2.0 * M_PI;
      while (yaw < -M_PI) yaw += 2.0 * M_PI;
    }
    path.points[i].pose.orientation = createQuaternionFromYaw(yaw);
  }

  if (path.points.size() >= 2) {
    path.points.back().pose.orientation = path.points[path.points.size() - 2].pose.orientation;
  }
}

double FMSPathConverterNode::getYaw(const geometry_msgs::msg::Quaternion & q)
{
  return tf2::getYaw(q);
}

void FMSPathConverterNode::addVelocityProfileForWindow(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2 || !has_original_goal_) {
    return;
  }

  // Detect driving direction
  bool is_reverse = false;
  for (const auto & pt : path.points) {
    if (std::abs(pt.longitudinal_velocity_mps) > 0.1) {
      is_reverse = (pt.longitudinal_velocity_mps < 0);
      break;
    }
  }

  const double base_velocity = is_reverse ? -default_velocity_ : default_velocity_;
  const double decel_distance = 10.0;

  for (size_t i = 0; i < path.points.size(); ++i) {
    const double dist_to_goal = calcDistance2D(
      path.points[i].pose.position, original_goal_position_);

    if (dist_to_goal < decel_distance) {
      const double ratio = dist_to_goal / decel_distance;
      const double min_approach_vel = is_reverse ? -1.0 : 1.0;
      const double target_vel = min_approach_vel + ratio * (base_velocity - min_approach_vel);

      if (is_reverse) {
        path.points[i].longitudinal_velocity_mps = std::max(
          path.points[i].longitudinal_velocity_mps, static_cast<float>(target_vel));
      } else {
        path.points[i].longitudinal_velocity_mps = std::min(
          path.points[i].longitudinal_velocity_mps, static_cast<float>(target_vel));
      }
    }
  }

  // Set zero velocity at goal if it's in the path
  const double last_point_dist = calcDistance2D(
    path.points.back().pose.position, original_goal_position_);
  if (last_point_dist < 2.0) {
    path.points.back().longitudinal_velocity_mps = 0.0;
  }
}

void FMSPathConverterNode::extendPathBeyondGoal(autoware_planning_msgs::msg::Path & path)
{
  // Downstream, elastic_band_smoother.cpp::applyInputVelocity() inserts the
  // input's zero-velocity stop into its output trajectory only if the stop's
  // projection lies inside the LAST output segment (~output_delta_arc_length,
  // 0.5 m). Because the smoother re-resamples every cycle and the destination
  // is the LAST point of our published path, the projection sometimes lands
  // just past that last segment and the stop is silently dropped — flipping
  // the trajectory's terminal velocity from 0 to ~cruise and back. The result
  // is the ~10 s ego-speed dip pattern.
  //
  // Fix: append a few zero-velocity points along the destination's heading so
  // the destination is no longer the path's last point. The first zero-velocity
  // point in the input (still the destination) remains the stop the smoother
  // finds, but now it projects well inside the output trajectory and the
  // boundary check no longer flips.
  if (!enable_goal_tail_) return;
  if (!has_original_goal_) return;
  if (path.points.size() < 2) return;
  if (goal_tail_length_ <= 0.0 || goal_tail_step_ <= 0.0) return;

  // Only extend when the path actually terminates at (or very near) the goal.
  const auto & last_pos = path.points.back().pose.position;
  const double dist_to_goal = calcDistance2D(last_pos, original_goal_position_);
  if (dist_to_goal > 1.0) return;

  // Travel direction inferred from the last segment of the existing path
  // (the path's orientation field is the *vehicle facing* heading, which is
  //  opposite to travel direction when reversing — using positions avoids
  //  having to special-case forward vs reverse).
  const auto & p_prev = path.points[path.points.size() - 2].pose.position;
  const double dx = last_pos.x - p_prev.x;
  const double dy = last_pos.y - p_prev.y;
  const double seg_len = std::hypot(dx, dy);
  if (seg_len < 1e-3) return;
  const double ux = dx / seg_len;
  const double uy = dy / seg_len;

  // Ensure the destination point itself is v=0 (it should already be — addVelocityProfileForWindow
  // sets this — but be defensive in case the velocity profile step is disabled).
  path.points.back().longitudinal_velocity_mps = 0.0;
  path.points.back().lateral_velocity_mps = 0.0;
  path.points.back().is_final = false;

  // Template the tail points from the destination so we inherit any fields
  // (e.g. drivable bounds metadata) populated upstream.
  autoware_planning_msgs::msg::PathPoint tail_template = path.points.back();
  tail_template.longitudinal_velocity_mps = 0.0;
  tail_template.lateral_velocity_mps = 0.0;
  tail_template.heading_rate_rps = 0.0;
  tail_template.is_final = false;
  // Preserve the destination's vehicle-facing orientation for every tail point.
  // (Don't recompute from dx,dy — for reverse driving the orientation differs
  //  from travel direction by π and that's set correctly on the destination.)

  const int n = std::max(1, static_cast<int>(std::ceil(goal_tail_length_ / goal_tail_step_)));
  for (int i = 1; i <= n; ++i) {
    auto pt = tail_template;
    pt.pose.position.x = last_pos.x + ux * (goal_tail_step_ * i);
    pt.pose.position.y = last_pos.y + uy * (goal_tail_step_ * i);
    pt.pose.position.z = last_pos.z;
    pt.is_final = (i == n);
    path.points.push_back(pt);
  }

  // Mirror the trailing bounds so downstream consumers don't see a path whose
  // points outlast the drivable corridor. Each new tail point reuses the
  // last bound vertex; this is fine because the tail extends in a straight
  // line and the vehicle never actually drives past the destination.
  if (!path.left_bound.empty()) {
    const auto last_left = path.left_bound.back();
    for (int i = 0; i < n; ++i) path.left_bound.push_back(last_left);
  }
  if (!path.right_bound.empty()) {
    const auto last_right = path.right_bound.back();
    for (int i = 0; i < n; ++i) path.right_bound.push_back(last_right);
  }
}

void FMSPathConverterNode::applyStopPoint(autoware_planning_msgs::msg::Path & path)
{
  if (!active_stop_ || path.points.empty()) {
    return;
  }

  geometry_msgs::msg::Point stop_pos;
  stop_pos.x = active_stop_->x;
  stop_pos.y = active_stop_->y;
  stop_pos.z = 0.0;

  // Find nearest index to stop point
  size_t stop_idx = findNearestIndex(path, stop_pos);

  // Apply deceleration ramp (5m before stop) and zero velocity from stop onward
  const double decel_ramp = 5.0;
  for (size_t i = 0; i < path.points.size(); ++i) {
    if (i >= stop_idx) {
      path.points[i].longitudinal_velocity_mps = 0.0;
      path.points[i].lateral_velocity_mps = 0.0;
    } else {
      // Ramp down velocity approaching the stop
      double dist_to_stop = 0.0;
      for (size_t k = i; k < stop_idx; ++k) {
        dist_to_stop += calcDistance2D(
          path.points[k].pose.position, path.points[k + 1].pose.position);
      }
      if (dist_to_stop < decel_ramp) {
        float ratio = static_cast<float>(dist_to_stop / decel_ramp);
        path.points[i].longitudinal_velocity_mps *= ratio;
        path.points[i].lateral_velocity_mps *= ratio;
      }
    }
  }

  RCLCPP_DEBUG(get_logger(), "Applied stop point at idx %zu (%.2f, %.2f)",
    stop_idx, stop_pos.x, stop_pos.y);
}

void FMSPathConverterNode::publishRouteFromWindow(const igv_planning_msgs::msg::FMSRouteWindow & window)
{
  // Find start and goal from the window segments
  if (window.segments.empty()) return;

  const auto & first_seg = window.segments.front();
  const auto & last_seg = window.segments.back();

  if (first_seg.points.empty() || last_seg.points.empty()) return;

  const auto & start_wp = first_seg.points.front();
  const auto & goal_wp = last_seg.points.back();

  autoware_planning_msgs::msg::LaneletRoute route;
  route.header.stamp = this->now();
  route.header.frame_id = frame_id_;

  route.start_pose.position.x = start_wp.x;
  route.start_pose.position.y = start_wp.y;
  route.start_pose.position.z = start_wp.z;
  route.start_pose.orientation = createQuaternionFromYaw(start_wp.heading);

  route.goal_pose.position.x = goal_wp.x;
  route.goal_pose.position.y = goal_wp.y;
  route.goal_pose.position.z = goal_wp.z;
  route.goal_pose.orientation = createQuaternionFromYaw(goal_wp.heading);

  route.uuid = generateUUID();
  route.allow_modification = true;

  route_pub_->publish(route);
}

// ============================================================================
// Uplink reporting methods
// ============================================================================

void FMSPathConverterNode::reportVehicleStatusToFMS()
{
  if (!protocol_ || !current_odom_) return;

  igv_planning_msgs::msg::VehicleStatus status;
  status.header.stamp = this->now();
  status.vehicle_id = vehicle_id_;

  const auto & pose = current_odom_->pose.pose;
  status.pos_x = pose.position.x;
  status.pos_y = pose.position.y;
  status.altitude = pose.position.z;

  double yaw = getYaw(pose.orientation);
  status.heading_angle = yaw;
  status.physical_angle = yaw;
  status.speed = std::hypot(
    current_odom_->twist.twist.linear.x,
    current_odom_->twist.twist.linear.y);

  // Gear/control mode
  status.gear_mode = current_reverse_state_
    ? igv_planning_msgs::msg::VehicleStatus::GEAR_REVERSE
    : igv_planning_msgs::msg::VehicleStatus::GEAR_FORWARD;
  status.control_mode = igv_planning_msgs::msg::VehicleStatus::CONTROL_AUTO;

  // Job tracking — report the FMS-issued base route_id, never the locally
  // synthesized "#p<n>" partition suffix added by route_bridge.
  status.job_id = current_job_id_;
  status.job_task_id = current_job_task_id_;
  status.route_id = baseRouteId(current_route_id_);
  status.route_task_state = last_window_
    ? igv_planning_msgs::msg::VehicleStatus::ROUTE_EXECUTING
    : igv_planning_msgs::msg::VehicleStatus::ROUTE_UNKNOWN;

  protocol_->reportVehicleStatus(status);
}

void FMSPathConverterNode::reportTrajectoryToFMS()
{
  if (!protocol_ || !current_odom_ || !last_output_path_) return;
  if (last_output_path_->points.empty()) return;

  igv_planning_msgs::msg::TrajectoryReport report;
  report.header.stamp = this->now();
  report.vehicle_id = vehicle_id_;

  const auto & pose = current_odom_->pose.pose;
  report.pos_x = pose.position.x;
  report.pos_y = pose.position.y;
  report.heading_angle = getYaw(pose.orientation);
  report.speed = std::hypot(
    current_odom_->twist.twist.linear.x,
    current_odom_->twist.twist.linear.y);

  // Build trajectory points (up to 100m ahead from ego)
  double accum_dist = 0.0;
  const auto & pts = last_output_path_->points;
  auto now_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
    std::chrono::system_clock::now().time_since_epoch()).count();

  for (size_t i = 0; i < pts.size(); ++i) {
    igv_planning_msgs::msg::TrajectoryPoint tp;
    tp.x = pts[i].pose.position.x;
    tp.y = pts[i].pose.position.y;
    tp.heading = getYaw(pts[i].pose.orientation);
    tp.velocity = static_cast<double>(pts[i].longitudinal_velocity_mps);
    tp.timestamp_ms = now_ms;
    report.points.push_back(tp);

    if (i > 0) {
      accum_dist += calcDistance2D(pts[i - 1].pose.position, pts[i].pose.position);
      if (accum_dist > 100.0) break;
    }
  }

  // Stop flag
  report.stop_flag = active_stop_.has_value();
  if (active_stop_) {
    report.stop_reason = "FMS stop point active";
  }

  protocol_->reportTrajectory(report);
}

void FMSPathConverterNode::checkArrivalAndReport()
{
  if (!protocol_ || !current_odom_ || !has_original_goal_ || arrival_reported_) return;

  const double dist = calcDistance2D(
    current_odom_->pose.pose.position, original_goal_position_);

  if (dist < arrival_threshold_) {
    igv_planning_msgs::msg::JobEvent event;
    event.header.stamp = this->now();
    event.vehicle_id = vehicle_id_;
    event.job_id = current_job_id_;
    event.job_task_id = current_job_task_id_;
    event.event_type = igv_planning_msgs::msg::JobEvent::EVENT_ARRIVED;

    protocol_->reportJobEvent(event);
    arrival_reported_ = true;

    RCLCPP_INFO(get_logger(), "Arrival reported: job=%s, task=%s, dist=%.2fm",
      current_job_id_.c_str(), current_job_task_id_.c_str(), dist);

    // Stop publishing the completed path. The timerCallback guard will then
    // skip path_pub_, letting the downstream planning chain go quiet. The
    // vehicle is already physically stopped because the final path point
    // carries v=0.
    //
    // State for the next job is reset in onRouteWindow() when a new route_id
    // arrives (arrival_reported_ cleared there).
    last_reference_path_.reset();
    last_output_path_.reset();
  }
}

void FMSPathConverterNode::publishProjectedWaypointMarkers(
  const std::vector<autoware_planning_msgs::msg::PathPoint> & raw_points,
  const MapPathGenerator::SnapResult & snap)
{
  if (!projected_waypoints_marker_pub_) return;

  using visualization_msgs::msg::Marker;
  using visualization_msgs::msg::MarkerArray;

  MarkerArray array;
  const auto stamp = this->now();
  const std::string ns = "fms_projected_waypoints";

  // DELETEALL to wipe stale markers
  {
    Marker clear;
    clear.header.frame_id = frame_id_;
    clear.header.stamp = stamp;
    clear.ns = ns;
    clear.action = Marker::DELETEALL;
    array.markers.push_back(clear);
  }

  // Polyline through valid snapped positions
  Marker line;
  line.header.frame_id = frame_id_;
  line.header.stamp = stamp;
  line.ns = ns;
  line.id = 9000;
  line.type = Marker::LINE_STRIP;
  line.action = Marker::ADD;
  line.scale.x = 0.08;
  line.color.r = 1.0f;
  line.color.g = 0.5f;
  line.color.b = 0.0f;
  line.color.a = 0.9f;
  line.pose.orientation.w = 1.0;

  const size_t n = std::min(raw_points.size(), snap.input_projections.size());
  for (size_t i = 0; i < n; ++i) {
    const auto & raw = raw_points[i];
    const auto & ip = snap.input_projections[i];

    if (ip.valid) {
      // Orange sphere at snapped position
      Marker sphere;
      sphere.header.frame_id = frame_id_;
      sphere.header.stamp = stamp;
      sphere.ns = ns;
      sphere.id = static_cast<int>(100 + i);
      sphere.type = Marker::SPHERE;
      sphere.action = Marker::ADD;
      sphere.pose.position.x = ip.x;
      sphere.pose.position.y = ip.y;
      sphere.pose.position.z = ip.z;
      sphere.pose.orientation.w = 1.0;
      sphere.scale.x = 0.4;
      sphere.scale.y = 0.4;
      sphere.scale.z = 0.4;
      sphere.color.r = 1.0f;
      sphere.color.g = 0.5f;
      sphere.color.b = 0.0f;
      sphere.color.a = 1.0f;
      array.markers.push_back(sphere);

      // Leader line raw → snapped
      Marker leader;
      leader.header.frame_id = frame_id_;
      leader.header.stamp = stamp;
      leader.ns = ns;
      leader.id = static_cast<int>(1000 + i);
      leader.type = Marker::LINE_LIST;
      leader.action = Marker::ADD;
      leader.scale.x = 0.05;
      leader.color.r = 1.0f;
      leader.color.g = 0.5f;
      leader.color.b = 0.0f;
      leader.color.a = 0.8f;
      leader.pose.orientation.w = 1.0;
      geometry_msgs::msg::Point raw_p;
      raw_p.x = raw.pose.position.x;
      raw_p.y = raw.pose.position.y;
      raw_p.z = raw.pose.position.z;
      geometry_msgs::msg::Point snap_p;
      snap_p.x = ip.x;
      snap_p.y = ip.y;
      snap_p.z = ip.z;
      leader.points.push_back(raw_p);
      leader.points.push_back(snap_p);
      array.markers.push_back(leader);

      line.points.push_back(snap_p);

      // Text label showing snap distance
      Marker text;
      text.header.frame_id = frame_id_;
      text.header.stamp = stamp;
      text.ns = ns;
      text.id = static_cast<int>(2000 + i);
      text.type = Marker::TEXT_VIEW_FACING;
      text.action = Marker::ADD;
      text.pose.position.x = ip.x;
      text.pose.position.y = ip.y;
      text.pose.position.z = ip.z + 0.5;
      text.pose.orientation.w = 1.0;
      text.scale.z = 0.4;
      text.color.r = 1.0f;
      text.color.g = 0.8f;
      text.color.b = 0.2f;
      text.color.a = 1.0f;
      char buf[64];
      std::snprintf(buf, sizeof(buf), "#%zu d=%.2fm lane=%lu", i, ip.snap_dist,
        static_cast<unsigned long>(ip.lane_id));
      text.text = buf;
      array.markers.push_back(text);
    } else {
      // Red sphere at raw position — waypoint rejected by snap threshold
      Marker reject;
      reject.header.frame_id = frame_id_;
      reject.header.stamp = stamp;
      reject.ns = ns;
      reject.id = static_cast<int>(100 + i);
      reject.type = Marker::SPHERE;
      reject.action = Marker::ADD;
      reject.pose.position.x = raw.pose.position.x;
      reject.pose.position.y = raw.pose.position.y;
      reject.pose.position.z = raw.pose.position.z;
      reject.pose.orientation.w = 1.0;
      reject.scale.x = 0.5;
      reject.scale.y = 0.5;
      reject.scale.z = 0.5;
      reject.color.r = 1.0f;
      reject.color.g = 0.1f;
      reject.color.b = 0.1f;
      reject.color.a = 0.8f;
      array.markers.push_back(reject);

      // Label shows why
      Marker text;
      text.header.frame_id = frame_id_;
      text.header.stamp = stamp;
      text.ns = ns;
      text.id = static_cast<int>(2000 + i);
      text.type = Marker::TEXT_VIEW_FACING;
      text.action = Marker::ADD;
      text.pose.position.x = raw.pose.position.x;
      text.pose.position.y = raw.pose.position.y;
      text.pose.position.z = raw.pose.position.z + 0.6;
      text.pose.orientation.w = 1.0;
      text.scale.z = 0.4;
      text.color.r = 1.0f;
      text.color.g = 0.3f;
      text.color.b = 0.3f;
      text.color.a = 1.0f;
      char buf[64];
      std::snprintf(buf, sizeof(buf), "#%zu REJECTED d=%.2fm", i, ip.snap_dist);
      text.text = buf;
      array.markers.push_back(text);
    }
  }

  if (line.points.size() >= 2) {
    array.markers.push_back(line);
  }

  projected_waypoints_marker_pub_->publish(array);
}

void FMSPathConverterNode::publishAdapterStatus()
{
  igv_planning_msgs::msg::AdapterStatus status;
  status.header.stamp = this->now();
  status.route_active = (last_window_ != nullptr || last_fms_path_ != nullptr);
  status.current_route_id = current_route_id_;
  status.current_job_id = current_job_id_;
  status.stop_active = active_stop_.has_value();
  status.last_error = last_error_;

  if (fms_connected_) {
    status.state = igv_planning_msgs::msg::AdapterStatus::STATE_ACTIVE;
  } else if (!last_error_.empty()) {
    status.state = igv_planning_msgs::msg::AdapterStatus::STATE_ERROR;
  } else {
    status.state = igv_planning_msgs::msg::AdapterStatus::STATE_IDLE;
  }

  adapter_status_pub_->publish(status);
}

std::optional<igv_planning_msgs::msg::FMSPath> FMSPathConverterNode::parseJsonPath(const std::string & json_str)
{
  try {
    auto json = nlohmann::json::parse(json_str);

    igv_planning_msgs::msg::FMSPath fms_path;
    fms_path.header.stamp = this->now();
    fms_path.header.frame_id = frame_id_;

    if (json.contains("path_id")) {
      fms_path.path_id = json["path_id"].get<std::string>();
    }
    if (json.contains("task_id")) {
      fms_path.task_id = json["task_id"].get<std::string>();
    }

    // Parse waypoints
    if (json.contains("waypoints") && json["waypoints"].is_array()) {
      for (const auto & wp : json["waypoints"]) {
        igv_planning_msgs::msg::FMSWaypoint waypoint;
        waypoint.x = wp.value("x", 0.0);
        waypoint.y = wp.value("y", 0.0);
        waypoint.z = wp.value("z", 0.0);
        waypoint.yaw = wp.value("yaw", 0.0);
        waypoint.velocity = wp.value("velocity", -1.0);
        waypoint.acceleration = wp.value("acceleration", 0.0);
        waypoint.curvature = wp.value("curvature", 0.0);
        waypoint.time_from_start = wp.value("time_from_start", 0.0);
        waypoint.waypoint_type = wp.value("type", 0);
        waypoint.lane_id = wp.value("lane_id", 0);

        fms_path.waypoints.push_back(waypoint);
      }
    }

    // Parse bounds if available
    if (json.contains("left_bound") && json["left_bound"].is_array()) {
      for (const auto & pt : json["left_bound"]) {
        geometry_msgs::msg::Point point;
        point.x = pt.value("x", 0.0);
        point.y = pt.value("y", 0.0);
        point.z = pt.value("z", 0.0);
        fms_path.left_bound.push_back(point);
      }
    }

    if (json.contains("right_bound") && json["right_bound"].is_array()) {
      for (const auto & pt : json["right_bound"]) {
        geometry_msgs::msg::Point point;
        point.x = pt.value("x", 0.0);
        point.y = pt.value("y", 0.0);
        point.z = pt.value("z", 0.0);
        fms_path.right_bound.push_back(point);
      }
    }

    return fms_path;

  } catch (const nlohmann::json::exception & e) {
    RCLCPP_ERROR(get_logger(), "Failed to parse JSON path: %s", e.what());
    last_error_ = std::string("JSON parse error: ") + e.what();
    return std::nullopt;
  }
}

void FMSPathConverterNode::odometryCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(mutex_);
  current_odom_ = msg;
}

void FMSPathConverterNode::timerCallback()
{
  std::lock_guard<std::mutex> lock(mutex_);

  // Check if FMS data is stale
  const double time_since_last = (this->now() - last_fms_message_time_).seconds();
  if (time_since_last > stale_threshold_) {
    fms_connected_ = false;
  }

  // Publish a fresh ego-relative view of the cached reference path. Geometry is
  // only regenerated by route-window replanning; traversed points are removed
  // every timer tick.
  if (last_reference_path_ && fms_connected_) {
    publishPathFromReference();
  }

  // Publish status
  publishStatus();

  // Uplink reporting at 1Hz (divide by publish_rate to get 1Hz)
  timer_counter_++;
  int uplink_interval = std::max(1, static_cast<int>(publish_rate_));
  if (timer_counter_ % uplink_interval == 0) {
    reportVehicleStatusToFMS();
    reportTrajectoryToFMS();
    checkArrivalAndReport();
    publishAdapterStatus();
  }
}

void FMSPathConverterNode::prependEgoProjection(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2 || !current_odom_) {
    return;
  }

  const auto & ego_pos = current_odom_->pose.pose.position;

  // Find projection onto first segment only (for simplicity and stability)
  const auto & p0 = path.points[0].pose.position;
  const auto & p1 = path.points[1].pose.position;

  const double dx = p1.x - p0.x;
  const double dy = p1.y - p0.y;
  const double seg_len_sq = dx * dx + dy * dy;

  if (seg_len_sq < 1e-6) {
    return;
  }

  // Project ego onto segment (allow extension beyond segment start)
  double t = ((ego_pos.x - p0.x) * dx + (ego_pos.y - p0.y) * dy) / seg_len_sq;
  // Clamp to prevent going beyond segment end, but allow negative (before segment start)
  t = std::min(t, 1.0);

  // Only prepend if ego is before or at the segment start (t <= 0)
  // or if ego is close to segment start (t < 0.3 and distance to p0 > 0.5m)
  const double dist_to_p0 = std::hypot(ego_pos.x - p0.x, ego_pos.y - p0.y);

  if (t > 0.3 || dist_to_p0 < 0.3) {
    // Ego is well inside the path or very close to first point, no need to prepend
    return;
  }

  // Calculate projection point
  const double proj_x = p0.x + t * dx;
  const double proj_y = p0.y + t * dy;
  const double proj_z = p0.z + t * (p1.z - p0.z);

  // Create projection point
  autoware_planning_msgs::msg::PathPoint proj_point;
  proj_point.pose.position.x = proj_x;
  proj_point.pose.position.y = proj_y;
  proj_point.pose.position.z = proj_z;

  // Interpolate yaw
  const double yaw0 = tf2::getYaw(path.points[0].pose.orientation);
  const double yaw1 = tf2::getYaw(path.points[1].pose.orientation);
  double yaw_diff = yaw1 - yaw0;
  while (yaw_diff > M_PI) yaw_diff -= 2.0 * M_PI;
  while (yaw_diff < -M_PI) yaw_diff += 2.0 * M_PI;
  const double t_clamped = std::clamp(t, 0.0, 1.0);
  const double interp_yaw = yaw0 + t_clamped * yaw_diff;
  proj_point.pose.orientation = createQuaternionFromYaw(interp_yaw);

  // Copy velocity from first point
  proj_point.longitudinal_velocity_mps = path.points[0].longitudinal_velocity_mps;
  proj_point.lateral_velocity_mps = 0.0;
  proj_point.heading_rate_rps = 0.0;
  proj_point.is_final = false;

  // Prepend the projection point
  path.points.insert(path.points.begin(), proj_point);
}

void FMSPathConverterNode::extendPathToEgo(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2 || !current_odom_) {
    return;
  }

  const auto & ego_pose = current_odom_->pose.pose;
  const auto & ego_pos = ego_pose.position;

  // Find nearest segment to ego and compute projection
  size_t nearest_seg_idx = 0;
  double min_dist = std::numeric_limits<double>::max();
  double best_proj_ratio = 0.0;
  double best_proj_x = 0.0, best_proj_y = 0.0, best_proj_z = 0.0;

  for (size_t i = 0; i + 1 < path.points.size(); ++i) {
    const auto & p0 = path.points[i].pose.position;
    const auto & p1 = path.points[i + 1].pose.position;

    // Project ego onto segment
    const double dx = p1.x - p0.x;
    const double dy = p1.y - p0.y;
    const double seg_len_sq = dx * dx + dy * dy;

    if (seg_len_sq < 1e-6) continue;

    double t = ((ego_pos.x - p0.x) * dx + (ego_pos.y - p0.y) * dy) / seg_len_sq;
    t = std::clamp(t, 0.0, 1.0);

    const double proj_x = p0.x + t * dx;
    const double proj_y = p0.y + t * dy;
    const double proj_z = p0.z + t * (p1.z - p0.z);
    const double dist = std::hypot(ego_pos.x - proj_x, ego_pos.y - proj_y);

    if (dist < min_dist) {
      min_dist = dist;
      nearest_seg_idx = i;
      best_proj_ratio = t;
      best_proj_x = proj_x;
      best_proj_y = proj_y;
      best_proj_z = proj_z;
    }
  }

  // Get the two points of the nearest segment
  const auto & seg_start = path.points[nearest_seg_idx];
  const auto & seg_end = path.points[nearest_seg_idx + 1];

  // Determine if reverse driving
  const bool is_reverse = (seg_start.longitudinal_velocity_mps < -0.01);

  // Create interpolated point ON THE PATH (not at ego position)
  // This avoids creating kinks that cause elastic band smoother to fail
  autoware_planning_msgs::msg::PathPoint proj_point;
  proj_point.pose.position.x = best_proj_x;
  proj_point.pose.position.y = best_proj_y;
  proj_point.pose.position.z = best_proj_z;

  // Interpolate yaw from segment
  const double yaw_start = tf2::getYaw(seg_start.pose.orientation);
  const double yaw_end = tf2::getYaw(seg_end.pose.orientation);
  double yaw_diff = yaw_end - yaw_start;
  while (yaw_diff > M_PI) yaw_diff -= 2.0 * M_PI;
  while (yaw_diff < -M_PI) yaw_diff += 2.0 * M_PI;
  const double interp_yaw = yaw_start + best_proj_ratio * yaw_diff;
  proj_point.pose.orientation = createQuaternionFromYaw(interp_yaw);

  // Interpolate velocity
  proj_point.longitudinal_velocity_mps = seg_start.longitudinal_velocity_mps +
    best_proj_ratio * (seg_end.longitudinal_velocity_mps - seg_start.longitudinal_velocity_mps);
  proj_point.lateral_velocity_mps = 0.0;
  proj_point.heading_rate_rps = 0.0;
  proj_point.is_final = false;

  // Only modify path if projection point is not too close to existing points
  constexpr double min_point_dist = 0.3;  // Minimum distance between points
  const double dist_to_seg_start = std::hypot(
    best_proj_x - seg_start.pose.position.x,
    best_proj_y - seg_start.pose.position.y);
  const double dist_to_seg_end = std::hypot(
    best_proj_x - seg_end.pose.position.x,
    best_proj_y - seg_end.pose.position.y);

  if (is_reverse) {
    // Reverse: crop path to keep only points from start to projection
    if (nearest_seg_idx + 2 < path.points.size()) {
      path.points.erase(path.points.begin() + nearest_seg_idx + 2, path.points.end());
    }
    // Add projection point at end if far enough from last point
    if (dist_to_seg_end > min_point_dist) {
      path.points.push_back(proj_point);
    }
  } else {
    // Forward: crop path to remove points behind projection
    if (nearest_seg_idx > 0) {
      path.points.erase(path.points.begin(), path.points.begin() + nearest_seg_idx);
    }
    // Insert projection point at front if far enough from first point
    if (dist_to_seg_start > min_point_dist) {
      path.points.insert(path.points.begin(), proj_point);
    }
  }

  RCLCPP_DEBUG(get_logger(),
    "[extendPathToEgo] ego=(%.2f,%.2f), proj=(%.2f,%.2f), lateral_err=%.2fm, is_reverse=%d, path_size=%zu",
    ego_pos.x, ego_pos.y, best_proj_x, best_proj_y, min_dist, is_reverse, path.points.size());
}

autoware_planning_msgs::msg::Path FMSPathConverterNode::convertFMSPathToAutowarePath(
  const igv_planning_msgs::msg::FMSPath & fms_path)
{
  autoware_planning_msgs::msg::Path autoware_path;
  autoware_path.header.stamp = this->now();
  autoware_path.header.frame_id = frame_id_;

  if (fms_path.waypoints.empty()) {
    RCLCPP_WARN(get_logger(), "FMS path has no waypoints");
    return autoware_path;
  }

  // First, detect if this is a reverse driving path by checking for negative velocities
  bool is_reverse_path = false;
  for (const auto & wp : fms_path.waypoints) {
    if (wp.velocity < -0.01) {
      is_reverse_path = true;
      break;
    }
  }

  // Determine the default velocity sign based on driving direction
  const float signed_default_velocity = is_reverse_path ? -default_velocity_ : default_velocity_;

  // Convert FMS waypoints to basic path points
  std::vector<autoware_planning_msgs::msg::PathPoint> sparse_points;
  std::vector<uint8_t> lane_change_types;  // Track lane change type for each waypoint

  // DEBUG: Log input FMS waypoints (commented out - high frequency)
  // RCLCPP_INFO(get_logger(), "[DEBUG] FMS waypoints count: %zu", fms_path.waypoints.size());
  // for (size_t i = 0; i < fms_path.waypoints.size(); ++i) {
  //   const auto & wp = fms_path.waypoints[i];
  //   RCLCPP_INFO(get_logger(),
  //     "[DEBUG] FMS wp[%zu]: pos=(%.2f,%.2f), yaw=%.2f, vel=%.2f, lane_change_type=%d",
  //     i, wp.x, wp.y, wp.yaw, wp.velocity, wp.lane_change_type);
  // }

  for (size_t i = 0; i < fms_path.waypoints.size(); ++i) {
    const auto & wp = fms_path.waypoints[i];

    autoware_planning_msgs::msg::PathPoint point;

    // Position
    point.pose.position.x = wp.x;
    point.pose.position.y = wp.y;
    point.pose.position.z = wp.z;

    // Orientation - use the yaw provided by FMS
    // Note: We trust the FMS waypoint yaw values for proper lane change detection
    // Recalculating yaw from direction to next point would break lane change detection
    double yaw = wp.yaw;
    point.pose.orientation = createQuaternionFromYaw(yaw);

    // Velocity
    // Handle negative velocity for reverse driving
    if (wp.velocity > 0.01) {
      point.longitudinal_velocity_mps = std::clamp(wp.velocity, min_velocity_, max_velocity_);
    } else if (wp.velocity < -0.01) {
      // Negative velocity indicates reverse driving - preserve the sign
      point.longitudinal_velocity_mps = std::clamp(wp.velocity, -max_velocity_, -min_velocity_);
    } else {
      // Use signed default velocity based on detected path direction
      point.longitudinal_velocity_mps = signed_default_velocity;
    }

    // Handle stop points
    if (wp.waypoint_type == igv_planning_msgs::msg::FMSWaypoint::TYPE_STOP ||
        wp.waypoint_type == igv_planning_msgs::msg::FMSWaypoint::TYPE_GOAL)
    {
      point.longitudinal_velocity_mps = 0.0;
    } else if (wp.waypoint_type == igv_planning_msgs::msg::FMSWaypoint::TYPE_SLOW) {
      // Limit speed while preserving direction sign
      if (is_reverse_path) {
        // For reverse, limit absolute value (more negative is faster)
        point.longitudinal_velocity_mps = std::max(
          point.longitudinal_velocity_mps, static_cast<float>(-min_velocity_));
      } else {
        point.longitudinal_velocity_mps = std::min(
          point.longitudinal_velocity_mps, static_cast<float>(min_velocity_));
      }
    }

    // Calculate lateral velocity for 4WS support
    // By allowing small v_y, the controller will automatically use counter-phase 4WS
    // which keeps the rear axle on the path and reduces swept area
    double curvature = wp.curvature;
    if (enable_4ws_ && std::abs(curvature) > curvature_threshold_ &&
        std::abs(point.longitudinal_velocity_mps) > 0.1)
    {
      const double v_x = static_cast<double>(point.longitudinal_velocity_mps);
      // Use gain factor for lateral velocity calculation: v_y = curvature * v_x * gain
      double lat_vel = curvature * v_x * lateral_velocity_gain_;
      lat_vel = std::clamp(lat_vel, -max_lateral_velocity_, max_lateral_velocity_);
      point.lateral_velocity_mps = static_cast<float>(lat_vel);
    } else {
      point.lateral_velocity_mps = 0.0;
    }

    point.heading_rate_rps = 0.0;
    point.is_final = (i == fms_path.waypoints.size() - 1);

    sparse_points.push_back(point);
    // Store lane change type for path generator
    lane_change_types.push_back(wp.lane_change_type);
  }

  // DEBUG: Log sparse_points after creation (commented out - high frequency)
  // RCLCPP_INFO(get_logger(), "[DEBUG] sparse_points count: %zu", sparse_points.size());
  // for (size_t i = 0; i < sparse_points.size(); ++i) {
  //   RCLCPP_INFO(get_logger(),
  //     "[DEBUG] sparse[%zu]: vel=%.2f m/s, lat_vel=%.4f, lane_change_type=%d",
  //     i, sparse_points[i].longitudinal_velocity_mps,
  //     sparse_points[i].lateral_velocity_mps,
  //     lane_change_types[i]);
  // }

  // DEBUG: Log path generation decision (commented out - high frequency)
  // RCLCPP_INFO(get_logger(),
  //   "[DEBUG] Path gen decision: enable_intelligent=%d, has_path_gen=%d, sparse_size=%zu",
  //   enable_intelligent_path_generation_, (path_generator_ != nullptr), sparse_points.size());

  // Use intelligent path generation if enabled (handles lane changes, turns, curves)
  if (enable_intelligent_path_generation_ && path_generator_ && sparse_points.size() >= 2) {
    RCLCPP_DEBUG(get_logger(), "Using intelligent path generation for %zu sparse waypoints",
      sparse_points.size());
    // Pass lane change types to path generator for proper lane change detection
    autoware_path.points = path_generator_->generatePath(sparse_points, lane_change_types);
  } else {
    // Fallback to simple linear interpolation
    autoware_path.points = sparse_points;
    interpolatePath(autoware_path);

    // Apply 4WS lateral velocity based on curvature (since FMSWaypoints may not have curvature set)
    if (enable_4ws_ && path_generator_) {
      path_generator_->apply4WSLateralVelocity(autoware_path.points);
    }
  }

  // DEBUG: Log after path generation (commented out - high frequency)
  // RCLCPP_INFO(get_logger(),
  //   "[DEBUG] After path gen: points=%zu, used_intelligent=%d",
  //   autoware_path.points.size(),
  //   (enable_intelligent_path_generation_ && path_generator_ && sparse_points.size() >= 2));

  // Log first few points with lateral velocity (commented out - high frequency)
  // {
  //   int count = 0;
  //   for (size_t i = 0; i < autoware_path.points.size() && count < 10; ++i) {
  //     if (std::abs(autoware_path.points[i].lateral_velocity_mps) > 0.001) {
  //       RCLCPP_INFO(get_logger(),
  //         "[DEBUG] Point[%zu]: lon_vel=%.2f, lat_vel=%.4f",
  //         i, autoware_path.points[i].longitudinal_velocity_mps,
  //         autoware_path.points[i].lateral_velocity_mps);
  //       count++;
  //     }
  //   }
  // }

  // Debug: Log lateral_velocity statistics after path generation
  if (enable_4ws_) {
    double max_lat_vel = 0.0;
    int nonzero_count = 0;
    for (const auto & pt : autoware_path.points) {
      const double lat_vel = static_cast<double>(pt.lateral_velocity_mps);
      if (std::abs(lat_vel) > 0.001) {
        nonzero_count++;
        max_lat_vel = std::max(max_lat_vel, std::abs(lat_vel));
      }
    }
    // RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 5000,
    //   "[4WS] After path gen: %d/%zu points have nonzero lateral_velocity (max=%.3f)",
    //   nonzero_count, autoware_path.points.size(), max_lat_vel);
  }

  // Copy bounds if available
  autoware_path.left_bound = fms_path.left_bound;
  autoware_path.right_bound = fms_path.right_bound;

  return autoware_path;
}

geometry_msgs::msg::Quaternion FMSPathConverterNode::createQuaternionFromYaw(double yaw)
{
  geometry_msgs::msg::Quaternion q;
  q.w = std::cos(yaw / 2.0);
  q.x = 0.0;
  q.y = 0.0;
  q.z = std::sin(yaw / 2.0);
  return q;
}

double FMSPathConverterNode::computeLateralDeviationFromCachedPath() const
{
  if (!last_reference_path_ || last_reference_path_->points.size() < 2 || !current_odom_) {
    return std::numeric_limits<double>::infinity();
  }
  return std::abs(autoware::motion_utils::calcLateralOffset(
    last_reference_path_->points, current_odom_->pose.pose.position));
}

void FMSPathConverterNode::truncatePathFromEgo(autoware_planning_msgs::msg::Path & path)
{
  if (!current_odom_) return;
  truncatePathFromEgoPose(
    path, current_odom_->pose.pose, ego_nearest_dist_threshold_, ego_nearest_yaw_threshold_,
    backward_path_length_);
}

void FMSPathConverterNode::cropPathFromEgo(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2 || !current_odom_) {
    return;
  }

  const auto & current_pose = current_odom_->pose.pose;

  // Use the same approach as behavior planner:
  // 1. Find ego segment index with soft constraints
  // 2. Crop using standard autoware::motion_utils::cropPoints

  // Find ego segment index (the segment that ego is closest to)
  const size_t ego_seg_idx = autoware::motion_utils::findFirstNearestSegmentIndexWithSoftConstraints(
    path.points, current_pose, ego_nearest_dist_threshold_, ego_nearest_yaw_threshold_);

  // Crop path using standard Autoware function
  // This keeps forward_path_length ahead and backward_path_length behind ego
  path.points = autoware::motion_utils::cropPoints(
    path.points, current_pose.position, ego_seg_idx,
    forward_path_length_, backward_path_length_ + 1.0);  // +1.0 for margin like behavior planner

  // FIX: Insert ego projection point if path doesn't have backward points
  // The planning_validator requires trajectory first point within 1.0m longitudinal distance from ego
  if (path.points.size() >= 2) {
    // Find ego segment index on the cropped path
    const size_t new_ego_seg_idx = autoware::motion_utils::findFirstNearestSegmentIndexWithSoftConstraints(
      path.points, current_pose, ego_nearest_dist_threshold_, ego_nearest_yaw_threshold_);

    // Check if ego is before the first point (idx == 0 means ego is ahead of path start)
    if (new_ego_seg_idx == 0) {
      const auto & p0 = path.points[0];
      const auto & p1 = path.points[1];

      // Calculate direction vector of first segment
      const double dx = p1.pose.position.x - p0.pose.position.x;
      const double dy = p1.pose.position.y - p0.pose.position.y;
      const double seg_len_sq = dx * dx + dy * dy;

      if (seg_len_sq > 1e-6) {
        // Project ego onto the line extending backward from first segment
        const double ex = current_pose.position.x - p0.pose.position.x;
        const double ey = current_pose.position.y - p0.pose.position.y;
        const double t = (ex * dx + ey * dy) / seg_len_sq;

        // Only insert if ego projects behind the first point (t < 0)
        if (t < -0.1) {  // Small threshold to avoid unnecessary insertion
          autoware_planning_msgs::msg::PathPoint ego_point = p0;  // Copy structure

          // Position at ego projection (extend backward from p0)
          // Clamp t to reasonable backward extension (max ~5m backward)
          const double t_clamped = std::max(t, -5.0 / std::sqrt(seg_len_sq));
          ego_point.pose.position.x = p0.pose.position.x + t_clamped * dx;
          ego_point.pose.position.y = p0.pose.position.y + t_clamped * dy;
          ego_point.pose.position.z = p0.pose.position.z;

          // Keep same orientation and velocity as first point
          ego_point.pose.orientation = p0.pose.orientation;
          ego_point.longitudinal_velocity_mps = p0.longitudinal_velocity_mps;
          ego_point.lateral_velocity_mps = p0.lateral_velocity_mps;
          ego_point.heading_rate_rps = p0.heading_rate_rps;

          // Insert at beginning
          path.points.insert(path.points.begin(), ego_point);

          RCLCPP_DEBUG(get_logger(),
            "[cropPathFromEgo] Inserted ego projection point: ego=(%.2f,%.2f), new_first=(%.2f,%.2f), t=%.2f",
            current_pose.position.x, current_pose.position.y,
            ego_point.pose.position.x, ego_point.pose.position.y, t_clamped);
        }
      }
    }
  }
}

void FMSPathConverterNode::interpolatePath(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2) {
    return;
  }

  std::vector<autoware_planning_msgs::msg::PathPoint> interpolated_points;

  for (size_t i = 0; i + 1 < path.points.size(); ++i) {
    const auto & p0 = path.points[i];
    const auto & p1 = path.points[i + 1];

    interpolated_points.push_back(p0);

    const double dist = calcDistance2D(p0.pose.position, p1.pose.position);
    const int num_intermediate = static_cast<int>(dist / path_interval_);

    for (int j = 1; j < num_intermediate; ++j) {
      const double ratio = static_cast<double>(j) / num_intermediate;

      autoware_planning_msgs::msg::PathPoint interp_point;

      // Interpolate position
      interp_point.pose.position.x = p0.pose.position.x + ratio * (p1.pose.position.x - p0.pose.position.x);
      interp_point.pose.position.y = p0.pose.position.y + ratio * (p1.pose.position.y - p0.pose.position.y);
      interp_point.pose.position.z = p0.pose.position.z + ratio * (p1.pose.position.z - p0.pose.position.z);

      // Interpolate yaw using SLERP (simplified)
      const double yaw0 = tf2::getYaw(p0.pose.orientation);
      const double yaw1 = tf2::getYaw(p1.pose.orientation);
      double yaw_diff = yaw1 - yaw0;

      // Normalize angle difference
      while (yaw_diff > M_PI) yaw_diff -= 2.0 * M_PI;
      while (yaw_diff < -M_PI) yaw_diff += 2.0 * M_PI;

      const double interp_yaw = yaw0 + ratio * yaw_diff;
      interp_point.pose.orientation = createQuaternionFromYaw(interp_yaw);

      // Interpolate velocity
      interp_point.longitudinal_velocity_mps =
        p0.longitudinal_velocity_mps + ratio * (p1.longitudinal_velocity_mps - p0.longitudinal_velocity_mps);
      // Interpolate lateral velocity for 4WS continuity
      interp_point.lateral_velocity_mps =
        p0.lateral_velocity_mps + ratio * (p1.lateral_velocity_mps - p0.lateral_velocity_mps);
      interp_point.heading_rate_rps = 0.0;
      interp_point.is_final = false;

      interpolated_points.push_back(interp_point);
    }
  }

  // Add last point
  interpolated_points.push_back(path.points.back());
  path.points = interpolated_points;
}

void FMSPathConverterNode::addVelocityProfile(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 2) {
    return;
  }

  // Store original velocities for lateral velocity scaling
  // This is needed to maintain crab angle when velocity profiling changes longitudinal_velocity
  // crab_angle = atan2(lat_vel, lon_vel) should remain constant
  std::vector<std::pair<float, float>> original_velocities;
  original_velocities.reserve(path.points.size());
  for (const auto & pt : path.points) {
    original_velocities.emplace_back(
      pt.longitudinal_velocity_mps,
      pt.lateral_velocity_mps);
  }

  // Detect if this is a reverse driving path by checking first non-goal point velocity
  bool is_reverse = false;
  for (const auto & pt : path.points) {
    if (std::abs(pt.longitudinal_velocity_mps) > 0.1) {
      is_reverse = (pt.longitudinal_velocity_mps < 0);
      break;
    }
  }

  // Get base velocity with correct sign for reverse
  const double base_velocity = is_reverse ? -default_velocity_ : default_velocity_;

  // First, ensure all points have a valid base velocity
  for (auto & pt : path.points) {
    double abs_vel = std::abs(pt.longitudinal_velocity_mps);
    if (abs_vel < 0.5 && abs_vel > 0.01) {
      // Very low velocity - use base velocity
      pt.longitudinal_velocity_mps = static_cast<float>(base_velocity);
    } else if (abs_vel < 0.01) {
      // Near zero - this is likely a goal point, keep it
    }
  }

  // Use original goal position for deceleration calculation
  // This ensures proper deceleration even when goal point is cropped from path
  if (!has_original_goal_) {
    RCLCPP_DEBUG(get_logger(), "Velocity profile: no goal at end, skipping deceleration profile");
    return;
  }

  // Calculate distance from each path point to the original goal
  // Apply deceleration based on distance to original goal, not just path end
  const double decel_distance = 10.0;  // meters - start decelerating 10m from goal

  for (size_t i = 0; i < path.points.size(); ++i) {
    const double dist_to_goal = calcDistance2D(
      path.points[i].pose.position, original_goal_position_);

    if (dist_to_goal < decel_distance) {
      // Apply deceleration profile based on distance to original goal
      const double ratio = dist_to_goal / decel_distance;
      const double min_approach_vel = is_reverse ? -1.0 : 1.0;
      const double target_vel = min_approach_vel + ratio * (base_velocity - min_approach_vel);

      // For forward: use min of current and target
      // For reverse: use max of current and target (since both are negative)
      if (is_reverse) {
        path.points[i].longitudinal_velocity_mps = std::max(
          path.points[i].longitudinal_velocity_mps,
          static_cast<float>(target_vel));
      } else {
        path.points[i].longitudinal_velocity_mps = std::min(
          path.points[i].longitudinal_velocity_mps,
          static_cast<float>(target_vel));
      }

      RCLCPP_DEBUG(get_logger(),
        "[VelProfile] point %zu: dist_to_goal=%.2fm, ratio=%.2f, vel=%.2fm/s",
        i, dist_to_goal, ratio, path.points[i].longitudinal_velocity_mps);
    }
  }

  // Check if goal point is in the path (last point close to original goal)
  const double last_point_dist_to_goal = calcDistance2D(
    path.points.back().pose.position, original_goal_position_);
  if (last_point_dist_to_goal < 2.0) {
    // Goal is in the path, set zero velocity at the last point
    path.points.back().longitudinal_velocity_mps = 0.0;
  }

  // Ensure first point has sufficient velocity to keep vehicle moving
  // (but only if not too close to goal)
  const double first_point_dist_to_goal = calcDistance2D(
    path.points.front().pose.position, original_goal_position_);
  if (!path.points.empty() && std::abs(path.points.front().longitudinal_velocity_mps) < 1.0 &&
      first_point_dist_to_goal > 3.0) {
    path.points.front().longitudinal_velocity_mps = static_cast<float>(base_velocity);
  }

  // Scale lateral velocity proportionally to maintain crab angle
  // This is critical for oblique lane changes (4WS crab motion):
  // When longitudinal_velocity is reduced (e.g., during ramp-up/decel profile),
  // lateral_velocity must also be scaled by the same ratio to maintain:
  //   crab_angle = atan2(lat_vel, lon_vel) = constant
  // Without this, a path designed for 5 m/s with lat_vel=-0.23 (crab=-2.6°)
  // would have crab=-42° when lon_vel is ramped down to 0.25 m/s
  for (size_t i = 0; i < path.points.size() && i < original_velocities.size(); ++i) {
    const float original_lon_vel = original_velocities[i].first;
    const float original_lat_vel = original_velocities[i].second;

    // Only scale if there was meaningful lateral velocity and longitudinal velocity
    if (std::abs(original_lon_vel) > 0.1f && std::abs(original_lat_vel) > 0.001f) {
      const float new_lon_vel = path.points[i].longitudinal_velocity_mps;

      // Skip if new velocity is near zero (goal point)
      if (std::abs(new_lon_vel) < 0.05f) {
        path.points[i].lateral_velocity_mps = 0.0f;
        continue;
      }

      // Scale lateral velocity: new_lat = original_lat * (new_lon / original_lon)
      const float scale = new_lon_vel / original_lon_vel;
      path.points[i].lateral_velocity_mps = original_lat_vel * scale;

      RCLCPP_DEBUG(get_logger(),
        "[VelProfile-4WS] point %zu: lon %.2f->%.2f, lat %.4f->%.4f (scale=%.3f)",
        i, original_lon_vel, new_lon_vel, original_lat_vel,
        path.points[i].lateral_velocity_mps, scale);
    }
  }

  RCLCPP_DEBUG(get_logger(),
    "Velocity profile: goal=(%.2f,%.2f), last_pt_dist=%.1fm, is_reverse=%d, start_vel=%.1fm/s",
    original_goal_position_.x, original_goal_position_.y, last_point_dist_to_goal,
    is_reverse, path.points.front().longitudinal_velocity_mps);
}

void FMSPathConverterNode::smoothPath(autoware_planning_msgs::msg::Path & path)
{
  if (path.points.size() < 3) {
    return;
  }

  // Simple moving average smoothing for positions
  const int window_size = 3;
  std::vector<autoware_planning_msgs::msg::PathPoint> smoothed_points = path.points;

  for (size_t i = 1; i + 1 < path.points.size(); ++i) {
    int count = 0;
    double sum_x = 0.0, sum_y = 0.0, sum_z = 0.0;

    for (int j = -window_size / 2; j <= window_size / 2; ++j) {
      const int idx = static_cast<int>(i) + j;
      if (idx >= 0 && idx < static_cast<int>(path.points.size())) {
        sum_x += path.points[idx].pose.position.x;
        sum_y += path.points[idx].pose.position.y;
        sum_z += path.points[idx].pose.position.z;
        count++;
      }
    }

    if (count > 0) {
      smoothed_points[i].pose.position.x = sum_x / count;
      smoothed_points[i].pose.position.y = sum_y / count;
      smoothed_points[i].pose.position.z = sum_z / count;
    }
  }

  // Recalculate orientations based on smoothed positions
  // Check if this is reverse driving (negative velocity)
  bool is_reverse = false;
  for (const auto & pt : smoothed_points) {
    if (pt.longitudinal_velocity_mps < -0.01) {
      is_reverse = true;
      break;
    }
  }

  for (size_t i = 0; i + 1 < smoothed_points.size(); ++i) {
    const double dx = smoothed_points[i + 1].pose.position.x - smoothed_points[i].pose.position.x;
    const double dy = smoothed_points[i + 1].pose.position.y - smoothed_points[i].pose.position.y;
    double yaw = std::atan2(dy, dx);

    // For reverse driving: vehicle faces opposite to travel direction
    // Flip yaw by 180 degrees so it matches vehicle facing direction
    if (is_reverse) {
      yaw += M_PI;
      // Normalize to [-pi, pi]
      while (yaw > M_PI) yaw -= 2.0 * M_PI;
      while (yaw < -M_PI) yaw += 2.0 * M_PI;
    }

    smoothed_points[i].pose.orientation = createQuaternionFromYaw(yaw);
  }

  // Last point keeps orientation of second-to-last
  if (smoothed_points.size() >= 2) {
    smoothed_points.back().pose.orientation = smoothed_points[smoothed_points.size() - 2].pose.orientation;
  }

  path.points = smoothed_points;
}

void FMSPathConverterNode::generateDrivableBounds(autoware_planning_msgs::msg::Path & path)
{
  if (!generate_drivable_area_ || path.points.size() < 2) {
    return;
  }

  // Check if FMS already provided bounds
  if (!path.left_bound.empty() && !path.right_bound.empty()) {
    RCLCPP_DEBUG(get_logger(), "Using drivable bounds from FMS");
    return;
  }

  // Generate bounds based on path and lane width, with curvature-based expansion
  path.left_bound.clear();
  path.right_bound.clear();

  double max_half_width = left_bound_offset_;  // Track max for logging
  std::vector<double> half_widths;  // Store widths for post-processing
  half_widths.reserve(path.points.size());

  // First pass: calculate half widths for all points
  for (size_t i = 0; i < path.points.size(); ++i) {
    double half_width;
    if (enable_curvature_expansion_) {
      double curvature = computeCurvatureAtIndex(path.points, i);
      double min_lane_width = calculateMinimumLaneWidth(curvature);
      half_width = std::max(min_lane_width / 2.0, left_bound_offset_);
      max_half_width = std::max(max_half_width, half_width);
    } else {
      half_width = left_bound_offset_;
    }
    half_widths.push_back(half_width);
  }

  // Ensure the last few points don't shrink abruptly - extend the width
  // to maintain consistent bounds at path end
  if (half_widths.size() >= 5) {
    // Use the maximum width from the last 10 points for the final 5 points
    size_t look_back = std::min(size_t(10), half_widths.size());
    double max_end_width = half_widths.back();
    for (size_t i = half_widths.size() - look_back; i < half_widths.size(); ++i) {
      max_end_width = std::max(max_end_width, half_widths[i]);
    }
    for (size_t i = half_widths.size() - 5; i < half_widths.size(); ++i) {
      half_widths[i] = std::max(half_widths[i], max_end_width);
    }
  }

  // Second pass: generate bounds using validated yaw
  for (size_t i = 0; i < path.points.size(); ++i) {
    const auto & pt = path.points[i];
    double half_width = half_widths[i];

    // Calculate yaw from path geometry (more reliable than stored orientation)
    double yaw;
    if (i + 1 < path.points.size()) {
      // Use direction to next point
      const auto & next_pt = path.points[i + 1];
      double dx = next_pt.pose.position.x - pt.pose.position.x;
      double dy = next_pt.pose.position.y - pt.pose.position.y;
      if (std::hypot(dx, dy) > 0.01) {  // Avoid degenerate case
        yaw = std::atan2(dy, dx);
      } else {
        yaw = tf2::getYaw(pt.pose.orientation);
      }
    } else if (i > 0) {
      // Last point: use direction from previous point
      const auto & prev_pt = path.points[i - 1];
      double dx = pt.pose.position.x - prev_pt.pose.position.x;
      double dy = pt.pose.position.y - prev_pt.pose.position.y;
      if (std::hypot(dx, dy) > 0.01) {
        yaw = std::atan2(dy, dx);
      } else {
        yaw = tf2::getYaw(pt.pose.orientation);
      }
    } else {
      yaw = tf2::getYaw(pt.pose.orientation);
    }

    // Calculate perpendicular direction (left is +90 degrees)
    const double left_angle = yaw + M_PI / 2.0;
    const double right_angle = yaw - M_PI / 2.0;

    // Left bound point
    geometry_msgs::msg::Point left_pt;
    left_pt.x = pt.pose.position.x + half_width * std::cos(left_angle);
    left_pt.y = pt.pose.position.y + half_width * std::sin(left_angle);
    left_pt.z = pt.pose.position.z;
    path.left_bound.push_back(left_pt);

    // Right bound point
    geometry_msgs::msg::Point right_pt;
    right_pt.x = pt.pose.position.x + half_width * std::cos(right_angle);
    right_pt.y = pt.pose.position.y + half_width * std::sin(right_angle);
    right_pt.z = pt.pose.position.z;
    path.right_bound.push_back(right_pt);
  }

  // Apply smoothing to avoid jagged bounds
  smoothDrivableBounds(path);

  RCLCPP_DEBUG(get_logger(),
    "Generated drivable bounds: %zu points, max_half_width=%.2fm (base=%.2fm)",
    path.left_bound.size(), max_half_width, left_bound_offset_);
}

double FMSPathConverterNode::computeCurvatureAtIndex(
  const std::vector<autoware_planning_msgs::msg::PathPoint> & points,
  size_t index) const
{
  // Use Menger curvature formula: k = 4 * Area(triangle) / (|AB| * |BC| * |CA|)
  // For endpoints, use the nearest interior calculation
  if (points.size() < 3) {
    return 0.0;
  }

  size_t i0, i1, i2;
  if (index == 0) {
    i0 = 0; i1 = 1; i2 = 2;
  } else if (index >= points.size() - 1) {
    i0 = points.size() - 3;
    i1 = points.size() - 2;
    i2 = points.size() - 1;
  } else {
    i0 = index - 1;
    i1 = index;
    i2 = index + 1;
  }

  const auto & p0 = points[i0].pose.position;
  const auto & p1 = points[i1].pose.position;
  const auto & p2 = points[i2].pose.position;

  // Calculate side lengths
  const double a = std::hypot(p1.x - p0.x, p1.y - p0.y);  // |AB|
  const double b = std::hypot(p2.x - p1.x, p2.y - p1.y);  // |BC|
  const double c = std::hypot(p2.x - p0.x, p2.y - p0.y);  // |CA|

  // Avoid division by zero for collinear or coincident points
  if (a < 1e-6 || b < 1e-6 || c < 1e-6) {
    return 0.0;
  }

  // Calculate area using cross product: Area = 0.5 * |AB x AC|
  const double cross = (p1.x - p0.x) * (p2.y - p0.y) - (p1.y - p0.y) * (p2.x - p0.x);
  const double area = 0.5 * std::abs(cross);

  // Menger curvature: k = 4 * Area / (a * b * c)
  const double curvature = 4.0 * area / (a * b * c);

  return curvature;
}

double FMSPathConverterNode::calculateMinimumLaneWidth(double curvature) const
{
  // For straight paths (very small curvature), use vehicle width + margin
  if (std::abs(curvature) < 1e-6) {
    return vehicle_width_ + 2.0 * min_bound_margin_;
  }

  // Formula accounts for BOTH front and rear overhang sweep during turns
  // For Ackermann steering:
  // - Front outer corner sweeps outward
  // - Rear inner corner cuts inward
  // Both need space within the drivable bounds

  const double R = 1.0 / std::abs(curvature);  // Turn radius at vehicle center
  const double a = vehicle_front_overhang_;     // Front overhang (4.5m for IGV)
  const double b = vehicle_length_ - vehicle_front_overhang_ - vehicle_wheel_base_;  // Rear overhang
  const double w = vehicle_width_;              // Vehicle width (3m for IGV)
  const double L = vehicle_wheel_base_;         // Wheelbase (6m for IGV)

  // Front outer corner radius: sqrt((R + w/2)^2 + (L + a)^2)
  const double R_front_outer = std::sqrt(
    std::pow(R + w / 2.0, 2) + std::pow(L + a, 2));

  // Rear inner corner radius: sqrt((R - w/2)^2 + b^2)
  // But we need the outer sweep of rear: sqrt((R + w/2)^2 + b^2)
  const double R_rear_outer = std::sqrt(
    std::pow(R + w / 2.0, 2) + std::pow(b, 2));

  // Maximum radius determines the outer sweep
  const double R_max = std::max(R_front_outer, R_rear_outer);

  // The additional width needed beyond the turn center
  // Total width = 2 * (R_max - R) = width swept beyond the vehicle's center path
  double min_width = 2.0 * (R_max - R) + w;

  // Add safety margin on both sides
  min_width += 2.0 * min_bound_margin_;

  // Cap the maximum expansion to prevent unreasonably wide bounds
  const double max_width = 12.0;  // meters (increased for large vehicles)
  min_width = std::min(min_width, max_width);

  RCLCPP_DEBUG(rclcpp::get_logger("fms_path_converter"),
    "Curvature %.4f -> R=%.1fm, R_front=%.1fm, R_rear=%.1fm, min_width=%.2fm",
    curvature, R, R_front_outer, R_rear_outer, min_width);

  return min_width;
}

void FMSPathConverterNode::smoothDrivableBounds(autoware_planning_msgs::msg::Path & path)
{
  if (path.left_bound.size() < 3 || path.right_bound.size() < 3) {
    return;
  }

  // Apply moving average smoothing to bound positions
  // Use adaptive window that handles endpoints properly
  auto smooth_bounds = [&](std::vector<geometry_msgs::msg::Point> & bounds) {
    std::vector<geometry_msgs::msg::Point> smoothed = bounds;
    const size_t n = bounds.size();

    for (size_t i = 0; i < n; ++i) {
      // Adaptive window: use smaller window near endpoints
      size_t window_start = (i >= 2) ? (i - 2) : 0;
      size_t window_end = (i + 2 < n) ? (i + 2) : (n - 1);

      double sum_x = 0.0, sum_y = 0.0, sum_z = 0.0;
      size_t count = 0;

      for (size_t j = window_start; j <= window_end; ++j) {
        sum_x += bounds[j].x;
        sum_y += bounds[j].y;
        sum_z += bounds[j].z;
        count++;
      }

      if (count > 0) {
        smoothed[i].x = sum_x / count;
        smoothed[i].y = sum_y / count;
        smoothed[i].z = sum_z / count;
      }
    }

    bounds = smoothed;
  };

  smooth_bounds(path.left_bound);
  smooth_bounds(path.right_bound);

  // Apply rate limiting to prevent sudden width changes
  // Max change rate: 0.5 m per path point (assuming ~1m interval)
  const double max_rate = 0.5;

  auto apply_rate_limit = [&](
    std::vector<geometry_msgs::msg::Point> & bounds,
    const std::vector<autoware_planning_msgs::msg::PathPoint> & path_points) {

    if (bounds.size() != path_points.size()) return;

    for (size_t i = 1; i < bounds.size(); ++i) {
      // Calculate current distance from path centerline
      const double dx_curr = bounds[i].x - path_points[i].pose.position.x;
      const double dy_curr = bounds[i].y - path_points[i].pose.position.y;
      const double dist_curr = std::hypot(dx_curr, dy_curr);

      const double dx_prev = bounds[i-1].x - path_points[i-1].pose.position.x;
      const double dy_prev = bounds[i-1].y - path_points[i-1].pose.position.y;
      const double dist_prev = std::hypot(dx_prev, dy_prev);

      // Limit the rate of change
      const double change = dist_curr - dist_prev;
      if (std::abs(change) > max_rate) {
        const double limited_dist = dist_prev + std::copysign(max_rate, change);
        const double scale = (dist_curr > 1e-6) ? (limited_dist / dist_curr) : 1.0;

        // Re-position the bound point at the limited distance
        bounds[i].x = path_points[i].pose.position.x + dx_curr * scale;
        bounds[i].y = path_points[i].pose.position.y + dy_curr * scale;
      }
    }
  };

  apply_rate_limit(path.left_bound, path.points);
  apply_rate_limit(path.right_bound, path.points);
}

void FMSPathConverterNode::cropDrivableBounds(autoware_planning_msgs::msg::Path & path)
{
  // Drivable bounds should match path points after cropping
  // This function is called after cropPathFromEgo to sync bounds with path

  if (path.left_bound.empty() || path.right_bound.empty()) {
    return;  // No bounds to crop
  }

  // If bounds size doesn't match path size, regenerate them
  if (path.left_bound.size() != path.points.size() ||
      path.right_bound.size() != path.points.size()) {
    // Clear and regenerate
    path.left_bound.clear();
    path.right_bound.clear();
    generateDrivableBounds(path);
  }
}

size_t FMSPathConverterNode::findNearestIndex(
  const autoware_planning_msgs::msg::Path & path,
  const geometry_msgs::msg::Point & point)
{
  size_t nearest_idx = 0;
  double min_dist = std::numeric_limits<double>::max();

  for (size_t i = 0; i < path.points.size(); ++i) {
    const double dist = calcDistance2D(path.points[i].pose.position, point);
    if (dist < min_dist) {
      min_dist = dist;
      nearest_idx = i;
    }
  }

  return nearest_idx;
}

double FMSPathConverterNode::calcDistance2D(
  const geometry_msgs::msg::Point & p1,
  const geometry_msgs::msg::Point & p2)
{
  return std::hypot(p2.x - p1.x, p2.y - p1.y);
}

void FMSPathConverterNode::publishStatus()
{
  igv_planning_msgs::msg::FMSStatus status;
  status.header.stamp = this->now();
  status.header.frame_id = frame_id_;

  status.fms_connected = fms_connected_;
  status.last_message_time = (this->now() - last_fms_message_time_).seconds();

  if (last_fms_path_) {
    status.current_trajectory_id = last_fms_path_->path_id;
    status.current_task_id = last_fms_path_->task_id;
    status.waypoints_remaining = last_fms_path_->waypoints.size();
  }

  status.current_mode = igv_planning_msgs::msg::FMSStatus::MODE_FMS_WITH_SAFETY;
  status.trajectory_valid = (last_output_path_ != nullptr && !last_output_path_->points.empty());
  status.trajectory_stale = !fms_connected_;
  status.last_error = last_error_;

  // Calculate distance to goal
  if (last_output_path_ && !last_output_path_->points.empty() && current_odom_) {
    status.distance_to_goal = calcDistance2D(
      current_odom_->pose.pose.position,
      last_output_path_->points.back().pose.position);
  }

  status_pub_->publish(status);
}

unique_identifier_msgs::msg::UUID FMSPathConverterNode::generateUUID()
{
  unique_identifier_msgs::msg::UUID uuid;
  // Generate a simple UUID based on current time
  auto now = this->now();
  uint64_t time_value = now.nanoseconds();
  std::memcpy(uuid.uuid.data(), &time_value, sizeof(time_value));

  // Fill rest with random-ish values
  for (size_t i = sizeof(time_value); i < uuid.uuid.size(); ++i) {
    uuid.uuid[i] = static_cast<uint8_t>(i + time_value % 256);
  }
  return uuid;
}

void FMSPathConverterNode::publishRouteFromFMSPath(const igv_planning_msgs::msg::FMSPath & fms_path)
{
  if (fms_path.waypoints.size() < 2) {
    RCLCPP_WARN(get_logger(), "Cannot create route from FMS path with less than 2 waypoints");
    return;
  }

  autoware_planning_msgs::msg::LaneletRoute route;
  route.header.stamp = this->now();
  route.header.frame_id = frame_id_;

  // Set start pose from first waypoint
  const auto & start_wp = fms_path.waypoints.front();
  route.start_pose.position.x = start_wp.x;
  route.start_pose.position.y = start_wp.y;
  route.start_pose.position.z = start_wp.z;
  route.start_pose.orientation = createQuaternionFromYaw(start_wp.yaw);

  // Set goal pose from last waypoint
  const auto & goal_wp = fms_path.waypoints.back();
  route.goal_pose.position.x = goal_wp.x;
  route.goal_pose.position.y = goal_wp.y;
  route.goal_pose.position.z = goal_wp.z;
  route.goal_pose.orientation = createQuaternionFromYaw(goal_wp.yaw);

  // Generate UUID
  route.uuid = generateUUID();

  // Allow modification by downstream planners
  route.allow_modification = true;

  // Leave segments empty - scenario selector doesn't strictly require them
  // for lane_driving scenario selection

  RCLCPP_DEBUG(get_logger(),
    "Publishing route: start=(%.2f, %.2f), goal=(%.2f, %.2f)",
    route.start_pose.position.x, route.start_pose.position.y,
    route.goal_pose.position.x, route.goal_pose.position.y);

  route_pub_->publish(route);
}

bool FMSPathConverterNode::detectReverseFromFMSPath(const igv_planning_msgs::msg::FMSPath & fms_path)
{
  if (fms_path.waypoints.empty()) {
    return false;
  }

  // Method 1: Check explicit is_reverse flag in waypoints
  int reverse_count = 0;
  int forward_count = 0;
  for (const auto & wp : fms_path.waypoints) {
    if (wp.is_reverse) {
      reverse_count++;
    } else {
      forward_count++;
    }
  }

  // If majority of waypoints have is_reverse flag set, it's reverse driving
  if (reverse_count > forward_count) {
    RCLCPP_INFO(get_logger(), "Detected REVERSE driving from FMS waypoint flags (%d/%zu)",
      reverse_count, fms_path.waypoints.size());
    return true;
  }

  // Method 2: Check for negative velocity (convention for reverse)
  int negative_vel_count = 0;
  for (const auto & wp : fms_path.waypoints) {
    if (wp.velocity < -0.1) {  // Small threshold to avoid float comparison issues
      negative_vel_count++;
    }
  }

  if (negative_vel_count > static_cast<int>(fms_path.waypoints.size() / 2)) {
    RCLCPP_INFO(get_logger(), "Detected REVERSE driving from negative velocity (%d/%zu)",
      negative_vel_count, fms_path.waypoints.size());
    return true;
  }

  // NOTE: Removed Method 3 (path direction vs vehicle heading comparison)
  // This method caused false positives when vehicle was facing opposite to travel direction
  // (e.g., vehicle facing -X but path goes +X for forward driving)
  // Trust the is_reverse flag and velocity sign from FMS waypoints instead

  return false;
}

void FMSPathConverterNode::updateReverseState(bool is_reverse, bool force_publish)
{
  current_reverse_state_ = is_reverse;

  // Sync the path generator so oblique (crab) generation builds its local
  // frame around motion direction when reversing. Mirrors /planning/reverse_state.
  if (path_generator_) {
    path_generator_->setReverseState(current_reverse_state_);
  }

  // Publish on state changes, or when an explicit service request asks to
  // refresh the current state for late subscribers.
  if (force_publish || current_reverse_state_ != last_reverse_state_) {
    if (current_reverse_state_ != last_reverse_state_) {
      RCLCPP_INFO(get_logger(), "Reverse state changed: %s -> %s",
        last_reverse_state_ ? "REVERSE" : "FORWARD",
        current_reverse_state_ ? "REVERSE" : "FORWARD");
    } else {
      RCLCPP_INFO(get_logger(), "Reverse state refreshed: %s",
        current_reverse_state_ ? "REVERSE" : "FORWARD");
    }

    publishReverseState();
    last_reverse_state_ = current_reverse_state_;
  }
}

void FMSPathConverterNode::publishReverseState()
{
  reverse_vehicle_msg::msg::VehicleReversed state_msg;
  state_msg.is_reversed = current_reverse_state_;
  reverse_state_pub_->publish(state_msg);
}

void FMSPathConverterNode::handleReverseStateService(
  const std::shared_ptr<reverse_vehicle_msg::srv::SetVehicleReverseState::Request> request,
  std::shared_ptr<reverse_vehicle_msg::srv::SetVehicleReverseState::Response> response)
{
  std::lock_guard<std::mutex> lock(mutex_);
  updateReverseState(request->is_reversed, true);
  response->success = true;
}

// ============================================================
// A* Local Path Planning (for POINT_LOCAL_PLAN_START/END zones)
// ============================================================

void FMSPathConverterNode::initAstarPlanner()
{
  using namespace autoware::freespace_planning_algorithms;

  vehicle_max_steer_angle_ = declare_parameter<double>("vehicle_max_steer_angle", 0.436);
  astar_costmap_resolution_ = declare_parameter<double>("astar.costmap_resolution", 0.2);
  astar_costmap_margin_ = declare_parameter<double>("astar.costmap_margin", 30.0);

  // Build PlannerCommonParam
  PlannerCommonParam common_param;
  common_param.time_limit = declare_parameter<double>("astar.time_limit", 30000.0);
  common_param.theta_size = declare_parameter<int>("astar.theta_size", 120);
  common_param.curve_weight = declare_parameter<double>("astar.curve_weight", 0.5);
  common_param.reverse_weight = declare_parameter<double>("astar.reverse_weight", 0.7);
  common_param.direction_change_weight = declare_parameter<double>("astar.direction_change_weight", 2.0);
  common_param.lateral_goal_range = declare_parameter<double>("astar.lateral_goal_range", 0.5);
  common_param.longitudinal_goal_range = declare_parameter<double>("astar.longitudinal_goal_range", 1.0);
  common_param.angle_goal_range = declare_parameter<double>("astar.angle_goal_range", 6.0);
  common_param.max_turning_ratio = declare_parameter<double>("astar.max_turning_ratio", 0.5);
  common_param.turning_steps = declare_parameter<int>("astar.turning_steps", 1);
  common_param.obstacle_threshold = declare_parameter<int>("astar.obstacle_threshold", 100);

  // Build VehicleShape
  const double rear_overhang = vehicle_length_ - vehicle_front_overhang_ - vehicle_wheel_base_;
  VehicleShape vehicle_shape(
    vehicle_length_,           // length
    vehicle_width_,            // width
    vehicle_wheel_base_,       // base_length (wheelbase)
    vehicle_max_steer_angle_,  // max_steering
    rear_overhang);            // base2back

  // Build AstarParam
  AstarParam astar_param;
  astar_param.search_method = declare_parameter<std::string>("astar.search_method", "forward");
  astar_param.only_behind_solutions = declare_parameter<bool>("astar.only_behind_solutions", false);
  astar_param.use_back = declare_parameter<bool>("astar.use_back", true);
  astar_param.adapt_expansion_distance = declare_parameter<bool>("astar.adapt_expansion_distance", true);
  astar_param.expansion_distance = declare_parameter<double>("astar.expansion_distance", 0.5);
  astar_param.near_goal_distance = declare_parameter<double>("astar.near_goal_distance", 3.0);
  astar_param.distance_heuristic_weight = declare_parameter<double>("astar.distance_heuristic_weight", 2.0);
  astar_param.smoothness_weight = declare_parameter<double>("astar.smoothness_weight", 0.5);
  astar_param.obstacle_distance_weight = declare_parameter<double>("astar.obstacle_distance_weight", 1.75);
  astar_param.goal_lat_distance_weight = declare_parameter<double>("astar.goal_lat_distance_weight", 5.0);

  astar_planner_ = std::make_unique<AstarSearch>(common_param, vehicle_shape, astar_param);

  RCLCPP_INFO(get_logger(),
    "A* local planner initialized (vehicle: %.1fm x %.1fm, wheelbase=%.1fm, steer=%.2frad, use_back=%s)",
    vehicle_length_, vehicle_width_, vehicle_wheel_base_, vehicle_max_steer_angle_,
    astar_param.use_back ? "true" : "false");
}

nav_msgs::msg::OccupancyGrid FMSPathConverterNode::createSyntheticCostmap(
  const geometry_msgs::msg::Pose & start,
  const geometry_msgs::msg::Pose & goal,
  double margin) const
{
  // Compute bounding box of start/goal with margin
  const double min_x = std::min(start.position.x, goal.position.x) - margin;
  const double max_x = std::max(start.position.x, goal.position.x) + margin;
  const double min_y = std::min(start.position.y, goal.position.y) - margin;
  const double max_y = std::max(start.position.y, goal.position.y) + margin;

  nav_msgs::msg::OccupancyGrid grid;
  grid.header.stamp = this->now();
  grid.header.frame_id = frame_id_;
  grid.info.resolution = static_cast<float>(astar_costmap_resolution_);
  grid.info.width = static_cast<uint32_t>(std::ceil((max_x - min_x) / astar_costmap_resolution_));
  grid.info.height = static_cast<uint32_t>(std::ceil((max_y - min_y) / astar_costmap_resolution_));
  grid.info.origin.position.x = min_x;
  grid.info.origin.position.y = min_y;
  grid.info.origin.position.z = 0.0;
  grid.info.origin.orientation.w = 1.0;

  // All cells free (value = 0)
  grid.data.assign(grid.info.width * grid.info.height, 0);

  return grid;
}

std::vector<autoware_planning_msgs::msg::PathPoint> FMSPathConverterNode::planLocalPath(
  const geometry_msgs::msg::Pose & start,
  const geometry_msgs::msg::Pose & goal,
  double forward_vel,
  double reverse_vel)
{
  std::vector<autoware_planning_msgs::msg::PathPoint> result;

  if (!astar_planner_) {
    RCLCPP_WARN(get_logger(), "[A*] Planner not initialized");
    return result;
  }

  // Create synthetic costmap and set it
  auto costmap = createSyntheticCostmap(start, goal, astar_costmap_margin_);
  astar_planner_->setMap(costmap);

  RCLCPP_INFO(get_logger(),
    "[A*] Planning local path: start=(%.2f,%.2f), goal=(%.2f,%.2f), grid=%ux%u",
    start.position.x, start.position.y,
    goal.position.x, goal.position.y,
    costmap.info.width, costmap.info.height);

  // Run A* search
  if (!astar_planner_->makePlan(start, goal)) {
    RCLCPP_WARN(get_logger(), "[A*] Failed to find path — falling back to Bezier interpolation");
    return result;
  }

  const auto & waypoints = astar_planner_->getWaypoints();
  if (waypoints.waypoints.empty()) {
    RCLCPP_WARN(get_logger(), "[A*] Planner returned empty waypoints");
    return result;
  }

  RCLCPP_INFO(get_logger(), "[A*] Found path with %zu waypoints (length=%.1fm)",
    waypoints.waypoints.size(), waypoints.compute_length());

  // Convert PlannerWaypoints to PathPoints
  bool prev_is_back = waypoints.waypoints.front().is_back;
  for (size_t i = 0; i < waypoints.waypoints.size(); ++i) {
    const auto & wp = waypoints.waypoints[i];

    // Insert zero-velocity stop point at direction change boundaries
    if (i > 0 && wp.is_back != prev_is_back) {
      // Set previous point velocity to zero (stop before direction change)
      if (!result.empty()) {
        result.back().longitudinal_velocity_mps = 0.0f;
      }
    }
    prev_is_back = wp.is_back;

    autoware_planning_msgs::msg::PathPoint pt;
    pt.pose = wp.pose.pose;
    pt.longitudinal_velocity_mps = static_cast<float>(wp.is_back ? reverse_vel : forward_vel);
    pt.lateral_velocity_mps = 0.0f;
    pt.heading_rate_rps = 0.0f;
    pt.is_final = (i == waypoints.waypoints.size() - 1);

    result.push_back(pt);
  }

  // Set last point velocity to zero (destination)
  if (!result.empty()) {
    result.back().longitudinal_velocity_mps = 0.0f;
  }

  // Log direction change summary
  int num_direction_changes = 0;
  for (size_t i = 1; i < waypoints.waypoints.size(); ++i) {
    if (waypoints.waypoints[i].is_back != waypoints.waypoints[i - 1].is_back) {
      ++num_direction_changes;
    }
  }
  RCLCPP_INFO(get_logger(), "[A*] Path has %d direction change(s)", num_direction_changes);

  return result;
}

void FMSPathConverterNode::resolveLocalPlanZones(
  std::vector<autoware_planning_msgs::msg::PathPoint> & sparse_points,
  std::vector<uint8_t> & lane_change_types,
  std::vector<uint8_t> & point_types,
  std::vector<std::pair<size_t, size_t>> * resolved_ranges)
{
  if (!astar_planner_ || point_types.size() != sparse_points.size()) {
    return;
  }

  // Find LOCAL_PLAN_START/END pairs
  std::vector<std::pair<size_t, size_t>> zones;
  size_t start_idx = std::numeric_limits<size_t>::max();

  for (size_t i = 0; i < point_types.size(); ++i) {
    if (point_types[i] == igv_planning_msgs::msg::SegmentWaypoint::POINT_LOCAL_PLAN_START) {
      start_idx = i;
    } else if (point_types[i] == igv_planning_msgs::msg::SegmentWaypoint::POINT_LOCAL_PLAN_END &&
               start_idx != std::numeric_limits<size_t>::max())
    {
      zones.push_back({start_idx, i});
      start_idx = std::numeric_limits<size_t>::max();
    }
  }

  if (zones.empty()) {
    return;
  }

  RCLCPP_INFO(get_logger(), "[A*] Found %zu LOCAL_PLAN zone(s) to resolve", zones.size());

  // Process zones in reverse order to preserve earlier indices
  for (auto it = zones.rbegin(); it != zones.rend(); ++it) {
    const size_t i_start = it->first;
    const size_t i_end = it->second;

    const auto & start_pose = sparse_points[i_start].pose;
    const auto & goal_pose = sparse_points[i_end].pose;

    // Direction of the zone is carried by the FMS waypoint velocity sign at the
    // boundaries (the sparse-points construction loop above sets
    // longitudinal_velocity_mps = ±speed per segment.orientation). A LOCAL_PLAN
    // zone can sit at a goal — destination override zeroes the velocity there —
    // so prefer the start; fall back to the end.
    bool zone_is_reverse = (sparse_points[i_start].longitudinal_velocity_mps < -0.01f);
    if (!zone_is_reverse && std::abs(sparse_points[i_start].longitudinal_velocity_mps) < 0.01f) {
      zone_is_reverse = (sparse_points[i_end].longitudinal_velocity_mps < -0.01f);
    }

    // generateQTurnSegment reads PathGenerator::is_reverse_ to align its local
    // frame on motion_yaw = start_yaw + π — without this the dx_local
    // projection comes out negative for reverse zones and qturn silently falls
    // back to a Bezier turn with motion-direction yaw. The window-level
    // setReverseState() in updateReverseStateFromPath() only fires AFTER path
    // generation, so set it here before qturn runs.
    if (path_generator_) {
      path_generator_->setReverseState(zone_is_reverse);
    }

    const double signed_default_vel =
      zone_is_reverse ? -default_velocity_ : default_velocity_;

    // Try Q_TURN first (Fresnel clothoid for ~90° elbows).
    std::vector<autoware_planning_msgs::msg::PathPoint> local_path;
    bool used_qturn = false;
    if (path_generator_) {
      const double sy = tf2::getYaw(start_pose.orientation);
      const double ey = tf2::getYaw(goal_pose.orientation);
      double yaw_diff = ey - sy;
      while (yaw_diff > M_PI) yaw_diff -= 2.0 * M_PI;
      while (yaw_diff < -M_PI) yaw_diff += 2.0 * M_PI;
      const double ayd = std::abs(yaw_diff);
      const auto & qp = path_generator_->getParameters();
      RCLCPP_INFO(get_logger(),
        "[Q_TURN?] Zone [%zu,%zu]: start_yaw=%.3f goal_yaw=%.3f |diff|=%.3f window=[%.3f,%.3f] is_reverse=%d",
        i_start, i_end, sy, ey, ayd, qp.qturn_yaw_min_threshold, qp.qturn_yaw_max_threshold,
        zone_is_reverse ? 1 : 0);
      if (ayd > qp.qturn_yaw_min_threshold && ayd < qp.qturn_yaw_max_threshold) {
        autoware_planning_msgs::msg::PathPoint s_pt = sparse_points[i_start];
        autoware_planning_msgs::msg::PathPoint e_pt = sparse_points[i_end];
        s_pt.pose = start_pose;
        e_pt.pose = goal_pose;
        s_pt.longitudinal_velocity_mps = static_cast<float>(signed_default_vel);
        // Preserve the FMS-assigned exit velocity (already 0 when LOCAL_PLAN_END
        // coincides with a destination via the construction-loop override).
        // Hard-coding 0 here would stop the vehicle at the elbow even when a
        // forward/reverse segment follows, since the next segment interpolates
        // between two zero-velocity endpoints. generateQTurnSegment treats a
        // non-zero end velocity as "continue at qturn_vel" via its end_is_goal
        // check, so this still produces the correct in-clothoid speed profile.
        e_pt.longitudinal_velocity_mps =
          sparse_points[i_end].longitudinal_velocity_mps;
        auto qpath = path_generator_->generateQTurnSegment(s_pt, e_pt);
        const bool fell_back = path_generator_->lastQTurnFellBack();
        if (!qpath.empty() && !fell_back) {
          local_path = std::move(qpath);
          used_qturn = true;
          RCLCPP_INFO(get_logger(),
            "[Q_TURN] Zone [%zu,%zu]: generated %zu clothoid points (yaw_diff=%.1f°)",
            i_start, i_end, local_path.size(), ayd * 180.0 / M_PI);
        } else {
          RCLCPP_WARN(get_logger(),
            "[Q_TURN] Zone [%zu,%zu]: empty=%d fell_back=%d — using A*",
            i_start, i_end, qpath.empty() ? 1 : 0, fell_back ? 1 : 0);
        }
      }
    }

    if (local_path.empty()) {
      // For A*: forward_vel and reverse_vel are body-frame magnitudes carrying
      // the body-frame sign. A* decides per-waypoint motion via its own is_back
      // flag, so we always pass +default_velocity_ for forward and
      // -default_velocity_ for reverse regardless of zone direction.
      local_path = planLocalPath(start_pose, goal_pose,
        default_velocity_, -default_velocity_);
    }

    if (local_path.empty()) {
      RCLCPP_WARN(get_logger(), "[A*] Zone [%zu,%zu] failed — keeping original points", i_start, i_end);
      continue;
    }

    // Replace the zone range with A* result
    const size_t old_count = i_end - i_start + 1;
    const size_t new_count = local_path.size();
    const auto delta =
      static_cast<std::ptrdiff_t>(new_count) - static_cast<std::ptrdiff_t>(old_count);

    sparse_points.erase(sparse_points.begin() + i_start, sparse_points.begin() + i_end + 1);
    sparse_points.insert(sparse_points.begin() + i_start, local_path.begin(), local_path.end());

    lane_change_types.erase(lane_change_types.begin() + i_start, lane_change_types.begin() + i_end + 1);
    lane_change_types.insert(lane_change_types.begin() + i_start, new_count, 0);

    point_types.erase(point_types.begin() + i_start, point_types.begin() + i_end + 1);
    point_types.insert(point_types.begin() + i_start, new_count, igv_planning_msgs::msg::SegmentWaypoint::POINT_NORMAL);

    if (resolved_ranges) {
      shiftResolvedRangesAfterReplacement(*resolved_ranges, i_end, delta);
      resolved_ranges->emplace_back(i_start, i_start + new_count - 1);
    }

    RCLCPP_INFO(get_logger(),
      "[%s] Zone [%zu,%zu]: replaced %zu points with %zu %s points",
      used_qturn ? "Q_TURN" : "A*",
      i_start, i_end, old_count, new_count,
      used_qturn ? "clothoid" : "A*");
  }

  if (resolved_ranges) {
    // Zones were processed in reverse order; return ascending for callers.
    std::sort(resolved_ranges->begin(), resolved_ranges->end(),
              [](const auto & a, const auto & b) { return a.first < b.first; });
  }
}

void FMSPathConverterNode::updateReverseStateFromPath(
  const autoware_planning_msgs::msg::Path & path)
{
  if (!current_odom_ || path.points.empty()) {
    return;
  }

  // Find nearest path point to ego
  const auto & ego_pos = current_odom_->pose.pose.position;
  size_t nearest_idx = findNearestIndex(path, ego_pos);

  // Get velocity at nearest point
  float velocity = path.points[nearest_idx].longitudinal_velocity_mps;

  // If at a stop point (velocity near zero), look ahead for the upcoming direction
  if (std::abs(velocity) < 0.1f) {
    for (size_t i = nearest_idx + 1; i < path.points.size(); ++i) {
      float v = path.points[i].longitudinal_velocity_mps;
      if (std::abs(v) > 0.1f) {
        velocity = v;
        break;
      }
    }
  }

  // Update reverse state based on velocity sign
  if (velocity < -0.01f) {
    updateReverseState(true);
  } else if (velocity > 0.01f) {
    updateReverseState(false);
  }
  // If still zero (all remaining points are zero), keep current state
}

}  // namespace igv_path_planner

#include <rclcpp_components/register_node_macro.hpp>
RCLCPP_COMPONENTS_REGISTER_NODE(igv_path_planner::FMSPathConverterNode)
